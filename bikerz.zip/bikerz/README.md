# Bikerz

A classic-styled motorcycle & scooter catalogue: **brands → models → versions**, with **images, prices and full specifications**.

Brands: **Royal Enfield, Jawa, Yezdi, TVS, Apache, Yamaha, Bajaj, KTM, Avenis** (27 models, 69 versions).

It is packaged with Docker and deploys with a Jenkins pipeline (same style as the RouteIQ pipeline: clone → build → swap → health check → automatic rollback), with an optional QA-automation trigger at the end.

```
Browser ──► nginx (web container, :8090) ──► /api, /health ──► Node API (api container, :3000)
                     │
                     └── serves the classic-style website + bike images
```

---

## 0. What is in the project

```
bikerz/
├── Jenkinsfile                  # Jenkins pipeline (deploy + optional QA trigger)
├── docker-compose.yml           # web + api containers
├── api/
│   ├── server.js                # REST API (no npm dependencies)
│   ├── package.json
│   ├── Dockerfile
│   └── data/bikes.json          # ALL brands, models, versions, specs, prices  <-- edit this
├── web/
│   ├── index.html               # the website
│   ├── css/style.css            # classic (parchment / burgundy / gold) design
│   ├── js/app.js
│   ├── images/bikes/*.svg       # one image per model
│   ├── nginx.conf
│   └── Dockerfile
└── scripts/
    ├── generate-images.js       # regenerates the SVG bike images
    └── setup-server.sh          # one-time server setup (Docker, git, GitHub host key)
```

### API endpoints

| Endpoint | Returns |
|----------|---------|
| `GET /health` | `{"status":"ok"}` – used by the pipeline health check |
| `GET /api/brands` | all brands with model counts |
| `GET /api/bikes?brand=ktm&q=duke&category=Naked&sort=price-asc` | model list (`sort`: `name`, `price-asc`, `price-desc`, `cc`) |
| `GET /api/bikes/<id>` | one model with all versions, colours, specs |

---

## 1. Prerequisites

On your laptop (for local testing):
- Node.js 18+ (or only Docker, see 2B)
- Git

On the deploy server (Ubuntu, `3.133.28.120`):
- Docker + Docker Compose plugin + git (installed by `scripts/setup-server.sh`, step 6)

In Jenkins (already used for RouteIQ):
- SSH Agent plugin, Pipeline plugin
- SSH credential with ID **`routeiq-backend`** (the same one the RouteIQ pipeline uses)

---

## 2. Run it on your laptop first

### 2A. Without Docker (fastest)

```bash
cd bikerz/api
STATIC_DIR=../web node server.js
```

Open **http://localhost:3000**.
(`STATIC_DIR` makes the API also serve the website, so no nginx is needed locally.)

### 2B. With Docker (exactly like the server)

```bash
cd bikerz
docker compose up -d --build
```

Open **http://localhost:8090** and check **http://localhost:8090/health**.

Stop it with `docker compose down`.

---

## 3. Customise the data (prices, specs, versions, images)

Everything shown on the site comes from **`api/data/bikes.json`**.

> **Important:** the prices and specifications in the file are approximate, indicative ex-showroom figures (INR) entered as a starting point. They were **not** verified against the manufacturers' current price lists. Please check them against official brand websites / dealers before publishing.

### 3.1 Edit a price
Open `api/data/bikes.json`, find the model, change `"price"` of the version (number in rupees, no commas).

### 3.2 Add a new version
Inside the model's `"versions"` array add:

```json
{ "name": "Black Edition", "price": 195000,
  "colours": ["Matte Black"], "highlights": "Blacked-out styling, dual-channel ABS" }
```

### 3.3 Add a new model
Copy an existing model block in `"bikes"`, then change:
- `id` (unique, lowercase, dashes only, e.g. `ktm-250-duke`)
- `brand` (must match a brand `id` in the `"brands"` list)
- `name`, `category`, `tagline`, `cc`
- `specs` (any key/value pairs you want shown)
- `versions`
- `image` → `/images/bikes/<id>.svg`

### 3.4 Add a new brand
Add to the `"brands"` array: `id`, `name`, `country`, `founded`, `accent` (hex colour used on its illustrations) and `blurb`.

### 3.5 Images
The images are **vintage-style illustrations** (generated, so there are no copyright problems). To (re)generate the illustrations for every model after editing the data:

```bash
node scripts/generate-images.js
```

To use **real photos** instead:
1. Get photos you have the right to use (e.g. from the manufacturer's press/media kit or your own).
2. Save them as `web/images/bikes/<id>.jpg` (about 1200×750 px works well).
3. In `bikes.json` change the model's `"image"` to `"/images/bikes/<id>.jpg"`.

### 3.6 After any change
- Local: restart `node server.js` (data is read at start-up).
- Server: commit + push, then run the Jenkins job (step 9).

---

## 4. Put the project in GitHub

1. On GitHub create an **empty private repo** named `bikerz` (no README / .gitignore).
2. In your project folder:

   ```bash
   cd bikerz
   git init
   git add .
   git commit -m "Bikerz: initial version"
   git branch -M main
   git remote add origin git@github.com:<YOUR-GITHUB-ORG>/bikerz.git
   git push -u origin main
   ```
3. Open `Jenkinsfile` and replace the placeholder in:

   ```groovy
   REPO = 'git@github.com:<YOUR-GITHUB-ORG>/bikerz.git'
   ```

   Commit and push again:

   ```bash
   git commit -am "Set repo URL" && git push
   ```

---

## 5. Let Jenkins / the server read the new repo

The pipeline logs in to the server with Jenkins credential `routeiq-backend` and **forwards that SSH key** so the server can `git clone` your repo. So that key must have read access to `bikerz`.

1. Get the public key of the credential `routeiq-backend` (the `.pub` file of the private key you stored in Jenkins).
2. GitHub → repo `bikerz` → **Settings → Deploy keys → Add deploy key** → paste the key → leave "Allow write access" **unticked** → Add.
3. If GitHub says **"Key is already in use"** (a deploy key can only belong to one repo), choose one of:
   - add the key to a GitHub user/machine account that has read access to both repos (**Settings → SSH keys** of that account), **or**
   - create a new key (`ssh-keygen -t ed25519 -f bikerz_deploy`), add it as the deploy key of `bikerz`, create a new Jenkins credential for it (e.g. ID `bikerz-deploy`), and change `sshagent(['routeiq-backend'])` to `sshagent(['bikerz-deploy'])` in the Jenkinsfile (both stages). The key must also be allowed to log in to the server (`~/.ssh/authorized_keys` of the `ubuntu` user).

---

## 6. Prepare the server (one time)

1. Log in:

   ```bash
   ssh ubuntu@3.133.28.120
   ```
2. Copy `scripts/setup-server.sh` to the server (or paste it) and run:

   ```bash
   bash setup-server.sh
   ```

   It installs Docker, the Compose plugin and git, adds `ubuntu` to the `docker` group and trusts GitHub's host key.
3. **Log out and log in again** so the docker group takes effect, then test:

   ```bash
   docker ps
   ```
   (no `permission denied` = OK. Skip this whole step if Docker is already installed for RouteIQ.)
4. **Open the port.** AWS Console → EC2 → your instance → **Security** → security group → **Edit inbound rules** → add:

   | Type | Port | Source |
   |------|------|--------|
   | Custom TCP | **8090** | `0.0.0.0/0` (or your office IP range) |

5. **Port clash check.** RouteIQ's gateway uses port 8080 on the same server. Bikerz therefore uses **8090** (see `docker-compose.yml` and `HEALTH_URL`). Check it is free:

   ```bash
   sudo ss -ltnp | grep 8090 || echo "8090 is free"
   ```
   To use another port, change `BIKERZ_PORT` default in `docker-compose.yml`, the `HEALTH_URL` default in the Jenkinsfile and the security-group rule.

---

## 7. Prepare Jenkins (one time)

1. **Server host key** – on the machine that runs Jenkins (as the user that runs Jenkins):

   ```bash
   ssh-keyscan -H 3.133.28.120 >> ~/.ssh/known_hosts
   ```
   (The Jenkinsfile uses `StrictHostKeyChecking=yes`. If the RouteIQ pipeline already works, this is done.)
2. **Credential** `routeiq-backend` must exist: Manage Jenkins → Credentials → (global) → *SSH Username with private key*, username `ubuntu`. (Or your new `bikerz-deploy` from step 5.)
3. **Create the job**
   1. Jenkins home → **New Item** → name `bikerz-deploy` → **Pipeline** → OK.
   2. Under **Pipeline** choose **Pipeline script from SCM**.
   3. SCM: **Git**, Repository URL `git@github.com:<YOUR-GITHUB-ORG>/bikerz.git`, Credentials: a credential that can read the repo (the same SSH key), Branch: `*/main`.
   4. Script Path: `Jenkinsfile`.
   5. **Save**.

---

## 8. First deployment

1. Open the job → **Build Now** (the first run only registers the parameters; it works with defaults).
2. Then **Build with Parameters**:

   | Parameter | Value |
   |-----------|-------|
   | `BRANCH` | `main` |
   | `HEALTH_URL` | `http://localhost:8090/health` |
   | `TRIGGER_QA` | leave **unticked** for now (see step 11) |

3. Click **Build**. The pipeline does:

   | Stage | What happens on the server |
   |-------|----------------------------|
   | **Clone new release** | clones the branch into `/home/ubuntu/bikerz_new` and checks the files exist |
   | **Build and switch** | `docker compose config` + `docker compose build` (new version is built **before** touching the live one), stops the old stack, moves folders (`bikerz` → `bikerz_old`, `bikerz_new` → `bikerz`), starts the new stack, then calls `/health` for up to ~60 s |
   | **Health check failed?** | automatic **rollback**: stops the new stack, restores `bikerz_old`, rebuilds and starts it, and fails the build |
   | **Trigger QA Automation** | optional, only if `TRIGGER_QA` is ticked |

---

## 9. Verify

- Browser: **http://3.133.28.120:8090** → the Bikerz catalogue.
- Health: **http://3.133.28.120:8090/health** → `{"status":"ok", ...}`
- API: **http://3.133.28.120:8090/api/bikes?brand=ktm**
- On the server:

  ```bash
  cd /home/ubuntu/bikerz
  docker compose ps
  docker compose logs --tail=50
  ```

### Every later change
Edit → `git commit` → `git push` → Jenkins **Build with Parameters** → done (≈1–2 minutes).

---

## 10. Manual rollback

The previous release is kept in `/home/ubuntu/bikerz_old` (until the next deploy).

```bash
ssh ubuntu@3.133.28.120
cd /home/ubuntu/bikerz && docker compose down
mv /home/ubuntu/bikerz /home/ubuntu/bikerz_bad
mv /home/ubuntu/bikerz_old /home/ubuntu/bikerz
cd /home/ubuntu/bikerz && docker compose up -d --build
```

---

## 11. Add the QA automation trigger (optional)

After the deploy succeeds, the pipeline can start the `Sample-QA-Automation-Job` on the QA Jenkins server.

1. Complete the setup in the **QA Jenkins integration README** (QA service account + API token, network access from this Jenkins to QA Jenkins, credential `qa-jenkins-api` on this Jenkins).
2. In the job → **Build with Parameters**:
   - `QA_JENKINS_URL` = real QA Jenkins URL from IT (not `localhost`)
   - `QA_JOB_NAME` = `Sample-QA-Automation-Job`
   - `TRIGGER_QA` = ticked
3. Expected log lines:

   ```
   Triggering QA job: https://<qa-jenkins>/job/Sample-QA-Automation-Job/build
   QA Jenkins responded with HTTP 201
   QA trigger request submitted.
   ```
4. If the trigger fails the build is marked **UNSTABLE** (the site stays deployed). QA's application URL should be `http://3.133.28.120:8090` (or your domain).

---

## 12. Troubleshooting

| Problem | Fix |
|---------|-----|
| `Host key verification failed` (Jenkins → server) | run `ssh-keyscan -H 3.133.28.120 >> ~/.ssh/known_hosts` on the Jenkins machine |
| `Permission denied (publickey)` while cloning | the forwarded key has no access to the `bikerz` repo – see step 5 |
| `permission denied ... docker.sock` | `sudo usermod -aG docker ubuntu`, then log out/in |
| `docker: 'compose' is not a command` | `sudo apt-get install -y docker-compose-plugin` |
| `port is already allocated` | something else uses 8090 – see step 6.5 |
| Pipeline fails at *Health check* and rolls back | on the server: `cd /home/ubuntu/bikerz_new` is gone after rollback, so run the stack locally with `docker compose up --build` and read the logs; also confirm `HEALTH_URL` |
| Site opens but is empty / "Could not reach the Bikerz API" | `docker compose logs api`; check `curl localhost:8090/api/bikes` on the server |
| Cannot open `http://3.133.28.120:8090` from your browser | security-group rule for 8090 missing (step 6.4) |
| Fonts look plain | the site loads Google Fonts; offline it falls back to Georgia/Times (still classic) |
| Changes to `bikes.json` not visible | you must redeploy (data is baked into the API image) |
| QA trigger 401 / 403 / 404 / timeout | see the QA integration README troubleshooting table |

---

## 13. Notes

- No npm packages are needed: the API uses only Node's built-in modules, so builds are fast and there is nothing to patch.
- "Apache" is TVS's performance range and "Avenis" is Suzuki's scooter; they are listed as their own brands as requested.
- Prices change often (taxes, new model years). Treat the supplied prices as placeholders to verify.
- Brand names belong to their owners; the illustrations are generic drawings, not manufacturer artwork.
