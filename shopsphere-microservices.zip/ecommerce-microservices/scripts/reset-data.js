#!/usr/bin/env node
'use strict';
/** Deletes ./data so the next start re-seeds users and the product catalog. Stop the stack first. */
const fs = require('fs');
const path = require('path');

const dir = path.resolve(process.env.DATA_DIR || path.join(__dirname, '..', 'data'));
fs.rmSync(dir, { recursive: true, force: true });
console.log(`Removed ${dir}. Data will be re-seeded on next start.`);
