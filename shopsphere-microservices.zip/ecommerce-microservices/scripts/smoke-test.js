#!/usr/bin/env node
'use strict';
/**
 * End-to-end smoke test of the whole platform through the API gateway.
 *
 *   npm test                          boots an isolated stack (temp data, ports 18080+) and tests it
 *   BASE_URL=http://localhost:8080 node scripts/smoke-test.js
 *                                     tests an already running stack (e.g. docker compose up)
 *
 * Note: when testing a running stack, the demo accounts must exist (SEED_DEMO_DATA=true).
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const { startStack } = require('./start-all');

let passed = 0;
let failed = 0;
function check(name, cond, extra = '') {
  if (cond) {
    passed += 1;
    console.log(`  \x1b[32mPASS\x1b[0m ${name}`);
  } else {
    failed += 1;
    console.log(`  \x1b[31mFAIL\x1b[0m ${name} ${extra}`);
  }
}

async function main() {
  let stack;
  let base = process.env.BASE_URL;
  let tmp;
  if (!base) {
    tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'shopsphere-test-'));
    const p = 18080;
    const env = {
      DATA_DIR: tmp,
      LOG_REQUESTS: 'false',
      SEED_DEMO_DATA: 'true',
      API_GATEWAY_PORT: String(p),
      USER_SERVICE_PORT: String(p + 1),
      PRODUCT_SERVICE_PORT: String(p + 2),
      CART_SERVICE_PORT: String(p + 3),
      ORDER_SERVICE_PORT: String(p + 4),
      PAYMENT_SERVICE_PORT: String(p + 5),
      NOTIFICATION_SERVICE_PORT: String(p + 6),
      AUTH_RATE_LIMIT_MAX: '1000',
    };
    stack = startStack({ env, quiet: true });
    base = `http://127.0.0.1:${p}`;
    console.log(`Booting isolated stack on ${base} (data: ${tmp})`);
  }

  const api = async (method, url, { body, token, headers = {} } = {}) => {
    const res = await fetch(base + '/api' + url, {
      method,
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
        ...headers,
      },
      body: body ? JSON.stringify(body) : undefined,
    });
    let data = null;
    try {
      data = await res.json();
    } catch {
      /* empty */
    }
    return { status: res.status, data };
  };

  try {
    // wait for health
    let healthy = false;
    for (let i = 0; i < 60 && !healthy; i++) {
      await new Promise((r) => setTimeout(r, 500));
      try {
        healthy = (await fetch(`${base}/api/health`)).ok;
      } catch {
        /* starting */
      }
    }
    check('all services healthy via gateway /api/health', healthy);
    if (!healthy) throw new Error('stack never became healthy');

    console.log('\nCatalog');
    let r = await api('GET', '/categories');
    check('8 categories', r.data.items.length === 8);
    r = await api('GET', '/products?limit=48');
    check('25 products seeded', r.data.total === 25 && r.data.items.length === 25);
    r = await api('GET', '/products?q=sony');
    check('search "sony" finds WH-1000XM5', r.data.items.some((p) => p.id === 'sony-wh-1000xm5'));
    r = await api('GET', '/products?category=books&sort=price_asc');
    check('category filter + sort', r.data.items.length === 3 && r.data.items[0].price <= r.data.items[1].price);
    r = await api('GET', '/products/iphone-15-128gb');
    check('product detail', r.status === 200 && r.data.product.brand === 'Apple');
    r = await api('GET', '/products/nope');
    check('unknown product -> 404', r.status === 404);

    console.log('\nSecurity');
    r = await api('GET', '/cart');
    check('cart without token -> 401', r.status === 401);
    r = await api('GET', '/internal/products?ids=iphone-15-128gb');
    check('/api/internal is not routable -> 404', r.status === 404);
    r = await api('GET', '/products?limit=1', { headers: { 'X-Internal-Key': 'x' } });
    check('client-supplied internal key is harmless', r.status === 200);

    console.log('\nAccounts');
    const email = `test${Date.now()}@example.com`;
    r = await api('POST', '/auth/register', { body: { email, password: 'weak', name: 'T' } });
    check('weak password rejected -> 400', r.status === 400);
    r = await api('POST', '/auth/register', { body: { email, password: 'Passw0rd!!', name: 'Test Buyer', phone: '9123456780' } });
    check('register -> 201 + token', r.status === 201 && !!r.data.token);
    const token = r.data.token;
    r = await api('POST', '/auth/register', { body: { email, password: 'Passw0rd!!', name: 'Test Buyer' } });
    check('duplicate email -> 409', r.status === 409);
    r = await api('POST', '/auth/login', { body: { email, password: 'wrong-pass-1' } });
    check('bad password -> 401', r.status === 401);
    r = await api('POST', '/auth/login', { body: { email, password: 'Passw0rd!!' } });
    check('login ok', r.status === 200 && !!r.data.token);
    r = await api('GET', '/users/me', { token });
    check('GET /users/me', r.data.user.email === email && !r.data.user.passwordHash);
    r = await api('POST', '/users/me/addresses', {
      token,
      body: { fullName: 'Test Buyer', phone: '9123456780', line1: '12 Park Street', city: 'Kolkata', state: 'West Bengal', pincode: '700016' },
    });
    check('add address (first becomes default)', r.status === 201 && r.data.address.isDefault === true);
    const addressId = r.data.address.id;
    r = await api('POST', '/users/me/addresses', { token, body: { fullName: 'X Y', phone: '123', line1: 'a', city: 'b', state: 'c', pincode: '1' } });
    check('invalid address -> 400', r.status === 400);

    console.log('\nCart');
    r = await api('POST', '/cart/items', { token, body: { productId: 'boat-rockerz-450', quantity: 2 } });
    check('add 2 x boAt Rockerz 450', r.status === 201 && r.data.subtotal === 2998);
    r = await api('POST', '/cart/items', { token, body: { productId: 'atomic-habits-james-clear', quantity: 1 } });
    check('add Atomic Habits', r.data.itemCount === 3 && r.data.subtotal === 3397);
    r = await api('POST', '/cart/items', { token, body: { productId: 'samsung-galaxy-watch6-44mm', quantity: 1 } });
    check('out-of-stock item -> 409', r.status === 409);
    r = await api('POST', '/cart/items', { token, body: { productId: 'google-pixel-8a-128gb', quantity: 5 } });
    check('more than stock (3) -> 409', r.status === 409);
    r = await api('PUT', '/cart/items/atomic-habits-james-clear', { token, body: { quantity: 3 } });
    check('update quantity', r.data.subtotal === 2998 + 399 * 3);
    r = await api('DELETE', '/cart/items/atomic-habits-james-clear', { token });
    check('remove item', r.data.items.length === 1 && r.data.subtotal === 2998);

    console.log('\nCheckout');
    r = await api('POST', '/orders/quote', { token, body: { couponCode: 'WELCOME10' } });
    check('quote with WELCOME10 (10% off, free shipping >= 999)', r.data.pricing.discount === 300 && r.data.pricing.shipping === 0 && r.data.pricing.total === 2698);
    r = await api('POST', '/orders/quote', { token, body: { couponCode: 'NOPE' } });
    check('invalid coupon -> 400', r.status === 400);

    const stockOf = async (id) => (await api('GET', `/products/${id}`)).data.product.stock;
    const stockBefore = await stockOf('boat-rockerz-450');

    const declined = {
      type: 'card', cardNumber: '4000 0000 0000 0002', expiry: '12/30', cvv: '123', cardName: 'Test Buyer',
    };
    r = await api('POST', '/orders', { token, body: { addressId, paymentMethod: declined } });
    check('declined card -> 402 PAYMENT_FAILED', r.status === 402 && r.data.error.code === 'PAYMENT_FAILED');
    check('stock restored after failed payment', (await stockOf('boat-rockerz-450')) === stockBefore);
    r = await api('GET', '/cart', { token });
    check('cart kept after failed payment', r.data.itemCount === 2);

    r = await api('POST', '/orders', { token, body: { addressId, paymentMethod: { type: 'card', cardNumber: '1234', expiry: '12/30', cvv: '123', cardName: 'T B' } } });
    check('invalid card number -> 400', r.status === 400);
    check('stock restored after invalid card', (await stockOf('boat-rockerz-450')) === stockBefore);

    const good = { type: 'card', cardNumber: '4111 1111 1111 1111', expiry: '12/30', cvv: '123', cardName: 'Test Buyer' };
    const idem = `idem-${Date.now()}`;
    r = await api('POST', '/orders', { token, headers: { 'Idempotency-Key': idem }, body: { addressId, paymentMethod: good, couponCode: 'WELCOME10' } });
    check('successful checkout -> 201 CONFIRMED', r.status === 201 && r.data.order.status === 'CONFIRMED');
    const order = r.data.order;
    check('order totals correct (2998 - 300 + 0)', order.pricing.total === 2698);
    check('payment stored with last4 only', order.payment.status === 'SUCCEEDED' && order.payment.last4 === '1111' && !JSON.stringify(order).includes('4111111111111111'));
    check('stock decreased by 2', (await stockOf('boat-rockerz-450')) === stockBefore - 2);
    r = await api('GET', '/cart', { token });
    check('cart cleared after order', r.data.itemCount === 0);
    r = await api('POST', '/orders', { token, headers: { 'Idempotency-Key': idem }, body: { addressId, paymentMethod: good } });
    check('idempotent replay returns same order', r.status === 200 && r.data.order.id === order.id && r.data.replay === true);
    r = await api('GET', '/orders', { token });
    check(
      'order history: 1 failed attempt + 1 confirmed (replay and invalid-card did not add orders)',
      r.data.items.length === 2 &&
        r.data.items.filter((o) => o.status === 'CONFIRMED').length === 1 &&
        r.data.items.filter((o) => o.status === 'PAYMENT_FAILED').length === 1
    );
    r = await api('GET', `/orders/${order.id}`, { token });
    check('order detail', r.status === 200 && r.data.order.timeline.length >= 2);

    await new Promise((res) => setTimeout(res, 300));
    r = await api('GET', '/notifications', { token });
    check('confirmation notification delivered', r.data.items.some((n) => n.type === 'order_confirmed' && n.body.includes(order.id)));

    console.log('\nCash on delivery, cancel + refund');
    r = await api('POST', '/cart/items', { token, body: { productId: 'jbl-flip-6', quantity: 1 } });
    const jblBefore = await stockOf('jbl-flip-6');
    r = await api('POST', '/orders', { token, body: { addressId, paymentMethod: { type: 'cod' } } });
    check('COD order confirmed with PENDING_COD payment', r.status === 201 && r.data.order.payment.status === 'PENDING_COD' && r.data.order.pricing.shipping === 0);
    const codOrder = r.data.order;
    check('COD stock reserved', (await stockOf('jbl-flip-6')) === jblBefore - 1);
    r = await api('POST', `/orders/${codOrder.id}/cancel`, { token });
    check('cancel COD order', r.status === 200 && r.data.order.status === 'CANCELLED');
    check('stock restored after cancel', (await stockOf('jbl-flip-6')) === jblBefore);
    r = await api('POST', `/orders/${codOrder.id}/cancel`, { token });
    check('cancelling twice -> 409', r.status === 409);

    // refund of a paid order
    await api('POST', '/cart/items', { token, body: { productId: 'puma-essentials-logo-tee', quantity: 1 } });
    r = await api('POST', '/orders', { token, body: { addressId, paymentMethod: { type: 'upi', upiId: 'buyer@okhdfcbank' } } });
    check('UPI checkout succeeds (+Rs 49 shipping under 999)', r.status === 201 && r.data.order.pricing.total === 948 && r.data.order.payment.status === 'SUCCEEDED');
    r = await api('POST', `/orders/${r.data.order.id}/cancel`, { token });
    check('cancel paid order -> payment REFUNDED', r.status === 200 && r.data.order.payment.status === 'REFUNDED');

    console.log('\nAdmin fulfilment');
    r = await api('POST', '/auth/login', { body: { email: 'admin@shopsphere.test', password: 'Admin@12345' } });
    const adminToken = r.data.token;
    check('admin login', r.status === 200 && r.data.user.role === 'admin');
    r = await api('POST', `/orders/${order.id}/advance`, { token });
    check('customer cannot advance orders -> 403', r.status === 403);
    r = await api('POST', `/orders/${order.id}/advance`, { token: adminToken });
    check('admin: CONFIRMED -> SHIPPED', r.data.order.status === 'SHIPPED');
    r = await api('POST', `/orders/${order.id}/advance`, { token: adminToken });
    check('admin: SHIPPED -> DELIVERED', r.data.order.status === 'DELIVERED');
    r = await api('POST', `/orders/${order.id}/cancel`, { token });
    check('delivered order cannot be cancelled -> 409', r.status === 409);
    r = await api('PATCH', '/products/pixel/stock', { token, body: { stock: 1 } });
    check('customer cannot edit stock -> 403', r.status === 403);
    r = await api('PATCH', '/products/google-pixel-8a-128gb/stock', { token: adminToken, body: { stock: 10 } });
    check('admin can edit stock', r.status === 200 && r.data.product.stock === 10);

    console.log('\nIsolation');
    r = await api('POST', '/auth/login', { body: { email: 'demo@shopsphere.test', password: 'Demo@12345' } });
    r = await api('GET', `/orders/${order.id}`, { token: r.data.token });
    check("another customer cannot read someone else's order -> 403", r.status === 403);
  } finally {
    if (stack) stack.stop();
    if (tmp) setTimeout(() => fs.rmSync(tmp, { recursive: true, force: true }), 500);
  }

  console.log(`\n${passed} passed, ${failed} failed`);
  process.exit(failed ? 1 : 0);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
