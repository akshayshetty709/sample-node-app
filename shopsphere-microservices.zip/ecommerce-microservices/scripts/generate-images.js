#!/usr/bin/env node
'use strict';
/**
 * Generates one product illustration (SVG) per catalog item into frontend/images/products/.
 *
 * These are drawn illustrations, not photographs. To use real product photos:
 *   1. drop your JPG/PNG/WEBP files into frontend/images/products/
 *   2. change the "image" field of the product in
 *      services/product-service/seed/catalog.json  (e.g. "/images/products/iphone-15.jpg")
 *   3. reset the data (npm run reset) so the catalog is re-seeded
 * (or update a live product via PUT /api/products/:id as an admin).
 */
const fs = require('fs');
const path = require('path');

const OUT = path.join(__dirname, '..', 'frontend', 'images', 'products');
fs.mkdirSync(OUT, { recursive: true });

const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const FONT = "font-family=\"Segoe UI, Helvetica, Arial, sans-serif\"";

// ---------- shape drawers (600 x 600 canvas, centred on x = 300) ----------------------
const shapes = {
  phone: (a, b) => `
    <defs><linearGradient id="scr" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${a}"/><stop offset="1" stop-color="${b}"/></linearGradient></defs>
    <rect x="193" y="58" width="214" height="424" rx="40" fill="${b}"/>
    <rect x="202" y="67" width="196" height="406" rx="33" fill="#0a0d14"/>
    <rect x="208" y="73" width="184" height="394" rx="28" fill="url(#scr)"/>
    <circle cx="270" cy="300" r="90" fill="#fff" opacity=".12"/><circle cx="340" cy="380" r="70" fill="#fff" opacity=".1"/>
    <rect x="270" y="85" width="60" height="17" rx="8.5" fill="#05070b"/>
    <text x="300" y="190" text-anchor="middle" ${FONT} font-size="60" font-weight="300" fill="#fff">9:41</text>
    <rect x="404" y="170" width="5" height="60" rx="2.5" fill="${b}"/>`,

  laptop: (a, b) => `
    <defs><linearGradient id="scr" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${b}"/><stop offset="1" stop-color="${a}"/></linearGradient></defs>
    <rect x="118" y="112" width="364" height="240" rx="16" fill="#1b1f2a"/>
    <rect x="128" y="122" width="344" height="220" rx="8" fill="url(#scr)"/>
    <circle cx="260" cy="250" r="80" fill="#fff" opacity=".13"/><circle cx="360" cy="215" r="60" fill="#fff" opacity=".1"/>
    <path d="M62 352 H538 L514 384 Q508 392 498 392 H102 Q92 392 86 384 Z" fill="${a}"/>
    <rect x="252" y="352" width="96" height="9" rx="4.5" fill="#000" opacity=".16"/>`,

  headphones: (a, b) => `
    <path d="M168 330 C168 96 432 96 432 330" fill="none" stroke="${b}" stroke-width="30" stroke-linecap="round"/>
    <path d="M168 330 C168 96 432 96 432 330" fill="none" stroke="${a}" stroke-width="12" stroke-linecap="round"/>
    <rect x="128" y="290" width="92" height="170" rx="44" fill="${a}"/>
    <rect x="380" y="290" width="92" height="170" rx="44" fill="${a}"/>
    <rect x="198" y="306" width="34" height="138" rx="17" fill="${b}"/>
    <rect x="368" y="306" width="34" height="138" rx="17" fill="${b}"/>
    <circle cx="160" cy="375" r="18" fill="${b}" opacity=".5"/><circle cx="440" cy="375" r="18" fill="${b}" opacity=".5"/>`,

  earbuds: (a, b) => `
    <rect x="172" y="268" width="256" height="190" rx="64" fill="${a}"/>
    <path d="M172 340 H428" stroke="${b}" stroke-width="5" opacity=".45"/>
    <circle cx="300" cy="396" r="9" fill="${b}" opacity=".55"/>
    <g fill="${a}" stroke="${b}" stroke-width="3">
      <ellipse cx="238" cy="196" rx="38" ry="44"/><rect x="258" y="196" width="22" height="78" rx="11"/>
      <ellipse cx="362" cy="196" rx="38" ry="44"/><rect x="320" y="196" width="22" height="78" rx="11"/>
    </g>
    <circle cx="228" cy="196" r="11" fill="${b}" opacity=".6"/><circle cx="372" cy="196" r="11" fill="${b}" opacity=".6"/>`,

  speaker: (a, b) => `
    <path d="M470 270 q56 14 28 100" fill="none" stroke="${b}" stroke-width="14" stroke-linecap="round"/>
    <rect x="104" y="218" width="392" height="204" rx="102" fill="${a}"/>
    <g fill="${b}" opacity=".55">${Array.from({ length: 4 }, (_, r) => Array.from({ length: 14 }, (_, c) => `<circle cx="${150 + c * 22}" cy="${252 + r * 22}" r="5"/>`).join('')).join('')}</g>
    <rect x="104" y="346" width="392" height="24" fill="${b}" opacity=".35"/>
    <circle cx="300" cy="358" r="9" fill="#fff"/>`,

  watch: (a, b) => `
    <rect x="236" y="30" width="128" height="140" rx="30" fill="${b}"/>
    <rect x="236" y="410" width="128" height="100" rx="30" fill="${b}"/>
    <rect x="394" y="226" width="16" height="50" rx="7" fill="${a}"/>
    <rect x="186" y="128" width="218" height="290" rx="64" fill="${a}"/>
    <rect x="199" y="141" width="192" height="264" rx="52" fill="#05070c"/>
    <circle cx="295" cy="273" r="72" fill="none" stroke="${b}" stroke-width="10" opacity=".9"/>
    <path d="M295 273 m-72 0 a72 72 0 0 1 120 -54" fill="none" stroke="#34d399" stroke-width="10" stroke-linecap="round"/>
    <text x="295" y="288" text-anchor="middle" ${FONT} font-size="42" font-weight="300" fill="#fff">10:09</text>`,

  sneaker: (a, b) => `
    <path d="M92 408 C92 388 106 380 124 380 L506 380 C534 380 540 402 530 416 C520 430 498 436 474 436 L128 436 C106 436 92 426 92 408 Z" fill="${b}"/>
    <path d="M124 380 L124 302 C124 282 140 270 160 270 L212 270 C236 320 282 332 340 336 L452 346 C506 352 536 366 538 380 Z" fill="${a}" stroke="#9ca3af" stroke-opacity=".55" stroke-width="3"/>
    <path d="M200 276 C198 246 218 232 244 236 L272 246 L256 296 Z" fill="${a}" stroke="#9ca3af" stroke-opacity=".55" stroke-width="3"/>
    <path d="M262 286 L296 308 M282 274 L316 298 M302 266 L336 292" stroke="${b}" stroke-width="7" stroke-linecap="round"/>
    <path d="M214 360 C260 340 330 344 420 366" fill="none" stroke="${b}" stroke-width="12" stroke-linecap="round"/>
    <path d="M92 408 H530" stroke="#000" stroke-opacity=".12" stroke-width="3"/>`,

  tee: (a, b) => `
    <path d="M206 100 L120 160 L162 232 L206 206 V470 H394 V206 L438 232 L480 160 L394 100 Q300 160 206 100 Z" fill="${a}"/>
    <path d="M206 100 Q300 160 394 100 Q300 122 206 100 Z" fill="${b}" opacity=".5"/>
    <path d="M250 300 h100 M250 326 h70" stroke="${b}" stroke-width="12" stroke-linecap="round" opacity=".85"/>
    <path d="M206 206 V470 M394 206 V470" stroke="#000" stroke-opacity=".08" stroke-width="4"/>`,

  jeans: (a, b) => `
    <path d="M190 84 H410 L426 470 H316 L300 220 L284 470 H174 Z" fill="${a}"/>
    <rect x="190" y="84" width="220" height="34" fill="${b}" opacity=".55"/>
    <g fill="${b}"><rect x="200" y="86" width="14" height="30" rx="3"/><rect x="293" y="86" width="14" height="30" rx="3"/><rect x="386" y="86" width="14" height="30" rx="3"/></g>
    <circle cx="300" cy="138" r="9" fill="#d6a756"/>
    <path d="M300 150 V220" stroke="${b}" stroke-width="4"/>
    <path d="M204 150 Q240 178 276 150 M396 150 Q360 178 324 150" fill="none" stroke="${b}" stroke-width="4" opacity=".8"/>
    <path d="M180 440 H284 M320 440 H420" stroke="${b}" stroke-width="3" opacity=".6"/>`,

  airfryer: (a, b) => `
    <rect x="150" y="90" width="300" height="370" rx="56" fill="${a}"/>
    <rect x="150" y="90" width="300" height="110" rx="56" fill="${b}"/>
    <rect x="150" y="150" width="300" height="50" fill="${b}"/>
    <circle cx="228" cy="150" r="30" fill="#e5e7eb"/><circle cx="372" cy="150" r="30" fill="#e5e7eb"/>
    <path d="M228 150 l0 -22 M372 150 l16 -16" stroke="#374151" stroke-width="5" stroke-linecap="round"/>
    <rect x="186" y="232" width="228" height="190" rx="28" fill="#0f172a"/>
    <rect x="236" y="262" width="128" height="14" rx="7" fill="${b}" opacity=".7"/>
    <path d="M236 330 h128" stroke="#1f2937" stroke-width="3"/>`,

  mixer: (a, b) => `
    <path d="M214 120 H386 L408 330 H192 Z" fill="#cbd5e1" opacity=".75" stroke="#94a3b8" stroke-width="4"/>
    <rect x="220" y="96" width="160" height="30" rx="12" fill="${b}"/>
    <rect x="288" y="78" width="24" height="24" rx="8" fill="${b}"/>
    <path d="M410 150 q52 30 6 110" fill="none" stroke="${b}" stroke-width="16" stroke-linecap="round"/>
    <rect x="166" y="330" width="268" height="140" rx="36" fill="${a}"/>
    <circle cx="300" cy="400" r="34" fill="${b}"/><circle cx="300" cy="400" r="14" fill="#fff" opacity=".7"/>
    <rect x="196" y="360" width="46" height="12" rx="6" fill="#fff" opacity=".6"/>`,

  flask: (a, b) => `
    <rect x="232" y="66" width="136" height="64" rx="22" fill="${b}"/>
    <rect x="248" y="40" width="104" height="36" rx="14" fill="${b}"/>
    <rect x="212" y="122" width="176" height="352" rx="54" fill="${a}"/>
    <rect x="212" y="270" width="176" height="52" fill="${b}" opacity=".85"/>
    <rect x="236" y="140" width="22" height="316" rx="11" fill="#fff" opacity=".25"/>`,

  book: (a, b, t) => `
    <rect x="168" y="62" width="276" height="400" rx="6" fill="#000" opacity=".15" transform="translate(10 8)"/>
    <rect x="160" y="54" width="276" height="400" rx="6" fill="${a}"/>
    <rect x="160" y="54" width="22" height="400" rx="4" fill="${b}" opacity=".5"/>
    <rect x="436" y="62" width="12" height="384" fill="#f8fafc"/>
    ${(t || [])
      .map((line, i) => `<text x="298" y="${156 + i * 44}" text-anchor="middle" ${FONT} font-size="${i === 0 ? 40 : 34}" font-weight="800" fill="#fff" letter-spacing="1">${esc(line)}</text>`)
      .join('')}
    <rect x="218" y="${170 + (t || []).length * 36}" width="160" height="5" rx="2.5" fill="#fff" opacity=".7"/>`,

  shuttle: (a, b) => `
    <g stroke="${b}" stroke-width="3">
      ${Array.from({ length: 11 }, (_, i) => `<path d="M${300 + (i - 5) * 6} 330 L${300 + (i - 5) * 28} 70"/>`).join('')}
    </g>
    <path d="M160 70 Q300 20 440 70 L396 90 Q300 62 204 90 Z" fill="${a}"/>
    <path d="M205 140 Q300 120 395 140 M190 205 Q300 182 410 205 M178 268 Q300 244 422 268" fill="none" stroke="${b}" stroke-width="4" opacity=".7"/>
    <path d="M262 330 Q300 316 338 330 Q354 400 300 430 Q246 400 262 330 Z" fill="#e8c9a0"/>
    <path d="M262 330 Q300 316 338 330" fill="none" stroke="#c89b66" stroke-width="5"/>`,

  mat: (a, b) => `
    <rect x="86" y="420" width="428" height="34" rx="17" fill="${a}" opacity=".92"/>
    <path d="M86 436 h428" stroke="${b}" stroke-width="3" opacity=".4"/>
    <circle cx="190" cy="300" r="116" fill="${a}"/>
    <circle cx="190" cy="300" r="84" fill="none" stroke="${b}" stroke-width="12" opacity=".55"/>
    <circle cx="190" cy="300" r="52" fill="none" stroke="${b}" stroke-width="12" opacity=".55"/>
    <circle cx="190" cy="300" r="20" fill="${b}"/>
    <rect x="190" y="184" width="326" height="232" rx="14" fill="${a}" opacity=".18"/>
    <path d="M190 184 H500 Q516 184 516 200 V400 Q516 416 500 416 H190 Z" fill="${a}"/>
    <path d="M230 230 H480 M230 270 H480 M230 310 H480 M230 350 H480 M230 390 H480" stroke="${b}" stroke-width="2" opacity=".35"/>`,

  football: (a, b) => `
    <circle cx="300" cy="280" r="190" fill="${a}" stroke="#d1d5db" stroke-width="4"/>
    <g fill="${b}">
      <polygon points="300,186 346,219 328,272 272,272 254,219"/>
      <polygon points="200,254 232,238 252,272 232,310 196,302"/>
      <polygon points="400,254 368,238 348,272 368,310 404,302"/>
      <polygon points="262,368 300,350 338,368 330,404 270,404"/>
    </g>
    <g stroke="${b}" stroke-width="5" fill="none">
      <path d="M300 186 V110 M254 219 L196 190 M346 219 L404 190 M272 272 L252 272 M328 272 L348 272 M270 404 L240 440 M330 404 L360 440"/>
    </g>
    <ellipse cx="248" cy="170" rx="70" ry="38" fill="#fff" opacity=".35" transform="rotate(-30 248 170)"/>`,
};

// ---------- catalog -> picture mapping ------------------------------------------------
// [id, shape, mainColour, accentColour, backgroundFrom, backgroundTo, brandLine, modelLine, bookTitleLines]
const ITEMS = [
  ['iphone-15-128gb', 'phone', '#9fc5e8', '#4b6a88', '#e0f0ff', '#c9ddf5', 'Apple', 'iPhone 15'],
  ['samsung-galaxy-s24-256gb', 'phone', '#8a8f98', '#3a3f48', '#f3f4f6', '#dfe3ea', 'Samsung', 'Galaxy S24'],
  ['oneplus-12r-256gb', 'phone', '#2f6db5', '#12263f', '#fde8e8', '#f7cfcf', 'OnePlus', '12R'],
  ['google-pixel-8a-128gb', 'phone', '#59b7a5', '#27424a', '#e6f7f3', '#cdeee6', 'Google', 'Pixel 8a'],
  ['macbook-air-13-m3', 'laptop', '#c9ced6', '#3b6fd8', '#eef2f7', '#dbe3ee', 'Apple', 'MacBook Air 13" M3'],
  ['lenovo-ideapad-slim-3-15', 'laptop', '#8d97a6', '#7c3aed', '#eef0ff', '#dcdffb', 'Lenovo', 'IdeaPad Slim 3'],
  ['sony-wh-1000xm5', 'headphones', '#d7d9de', '#2b2e36', '#eceff4', '#d9dfe9', 'Sony', 'WH-1000XM5'],
  ['airpods-pro-2-usbc', 'earbuds', '#f6f7f9', '#9aa3b2', '#eef1f6', '#dce2ec', 'Apple', 'AirPods Pro (2nd gen)'],
  ['boat-rockerz-450', 'headphones', '#d62b3b', '#171a21', '#fff0f1', '#ffd9dc', 'boAt', 'Rockerz 450'],
  ['jbl-flip-6', 'speaker', '#ff7a1a', '#1a1a1a', '#fff3e6', '#ffe0c2', 'JBL', 'Flip 6'],
  ['apple-watch-se-2-40mm', 'watch', '#d9dde3', '#e8503a', '#f1f4f8', '#dde4ee', 'Apple', 'Watch SE (2nd gen)'],
  ['samsung-galaxy-watch6-44mm', 'watch', '#2b2f3a', '#6b7280', '#eceef2', '#d6dae3', 'Samsung', 'Galaxy Watch6'],
  ['nike-air-force-1-07', 'sneaker', '#fafafa', '#e5e7eb', '#f1f5f9', '#e2e8f0', 'Nike', "Air Force 1 '07"],
  ['adidas-samba-og', 'sneaker', '#16181d', '#f5f5f5', '#eef2ee', '#dce6dc', 'adidas', 'Samba OG'],
  ['levis-511-slim-jeans', 'jeans', '#2c4a7c', '#16294a', '#eaf0fa', '#d3def2', "Levi's", '511 Slim Fit Jeans'],
  ['puma-essentials-logo-tee', 'tee', '#1c1f26', '#f5f5f5', '#f3f4f6', '#e3e6ec', 'PUMA', 'Essentials Logo Tee'],
  ['philips-air-fryer-hd9252', 'airfryer', '#1f2937', '#0b63ce', '#e8f1fc', '#d0e2f8', 'Philips', 'Air Fryer HD9252'],
  ['prestige-iris-750w-mixer', 'mixer', '#7a1f2b', '#d1d5db', '#fbeff0', '#f3d9dc', 'Prestige', 'Iris 750 W Mixer Grinder'],
  ['milton-thermosteel-1l-flask', 'flask', '#9aa3ad', '#d62839', '#f2f5f8', '#dfe5ec', 'Milton', 'Thermosteel Flask 1 L'],
  ['atomic-habits-james-clear', 'book', '#f4b400', '#a77700', '#fff8e0', '#ffeeb0', 'James Clear', 'Atomic Habits', ['ATOMIC', 'HABITS']],
  ['psychology-of-money-morgan-housel', 'book', '#1f6f5c', '#0d3d33', '#e7f6f1', '#cfeee3', 'Morgan Housel', 'The Psychology of Money', ['THE', 'PSYCHOLOGY', 'OF MONEY']],
  ['deep-work-cal-newport', 'book', '#243b6b', '#0f1c38', '#e9eef8', '#d3dcf0', 'Cal Newport', 'Deep Work', ['DEEP', 'WORK']],
  ['yonex-mavis-350-shuttlecocks', 'shuttle', '#f2d21b', '#cfcfcf', '#fffbe0', '#fff3a8', 'Yonex', 'Mavis 350 (Pack of 6)'],
  ['domyos-yoga-mat-8mm', 'mat', '#6d5bd0', '#3b2f8f', '#efeafd', '#ddd5f8', 'Decathlon', 'Domyos Yoga Mat 8 mm'],
  ['nivia-storm-football-size-5', 'football', '#ffffff', '#1f2430', '#e8f6ec', '#cfeedb', 'Nivia', 'Storm Football (Size 5)'],
];

function render([id, shape, a, b, bg1, bg2, brand, model, bookLines]) {
  const drawer = shapes[shape];
  if (!drawer) throw new Error(`Unknown shape ${shape} for ${id}`);
  const inner = drawer(a, b, bookLines);
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 600" role="img" aria-label="${esc(`${brand} ${model}`)}">
  <defs>
    <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${bg1}"/><stop offset="1" stop-color="${bg2}"/></linearGradient>
    <radialGradient id="sh" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#000" stop-opacity=".28"/><stop offset="1" stop-color="#000" stop-opacity="0"/></radialGradient>
  </defs>
  <rect width="600" height="600" fill="url(#bg)"/>
  <ellipse cx="300" cy="486" rx="200" ry="20" fill="url(#sh)"/>
  ${inner}
  <text x="300" y="540" text-anchor="middle" ${FONT} font-size="21" font-weight="700" fill="#1f2937" letter-spacing="2">${esc(brand.toUpperCase())}</text>
  <text x="300" y="570" text-anchor="middle" ${FONT} font-size="17" fill="#4b5563">${esc(model)}</text>
</svg>
`;
}

for (const item of ITEMS) fs.writeFileSync(path.join(OUT, `${item[0]}.svg`), render(item));

// generic fallback + logo
fs.writeFileSync(
  path.join(__dirname, '..', 'frontend', 'images', 'placeholder.svg'),
  `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 600"><rect width="600" height="600" fill="#eef0f5"/><g fill="none" stroke="#9aa3b2" stroke-width="10" stroke-linejoin="round"><rect x="170" y="190" width="260" height="220" rx="24"/><circle cx="262" cy="270" r="26"/><path d="M170 380 L250 316 L316 366 L360 330 L430 390"/></g><text x="300" y="470" text-anchor="middle" font-family="Segoe UI, Arial, sans-serif" font-size="22" fill="#6b7280">Image coming soon</text></svg>\n`
);
fs.writeFileSync(
  path.join(__dirname, '..', 'frontend', 'images', 'logo.svg'),
  `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#6366f1"/><stop offset="1" stop-color="#4338ca"/></linearGradient></defs><rect width="64" height="64" rx="16" fill="url(#g)"/><circle cx="32" cy="32" r="16" fill="none" stroke="#fff" stroke-width="4"/><path d="M16 32 H48 M32 16 C24 24 24 40 32 48 C40 40 40 24 32 16" fill="none" stroke="#fff" stroke-width="3"/></svg>\n`
);

console.log(`Wrote ${ITEMS.length} product images to ${OUT}`);
