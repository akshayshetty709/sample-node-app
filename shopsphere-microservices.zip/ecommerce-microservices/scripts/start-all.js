#!/usr/bin/env node
'use strict';
/**
 * Starts every microservice as a child process with colour-prefixed logs.
 *   node scripts/start-all.js            normal
 *   node scripts/start-all.js --watch    restart a service when its files change (Node >= 18.11)
 *
 * Also exported as startStack() so the smoke test can boot an isolated copy.
 */
const { spawn } = require('child_process');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
// start order: leaves first, gateway last
const SERVICES = [
  'notification-service',
  'payment-service',
  'user-service',
  'product-service',
  'cart-service',
  'order-service',
  'api-gateway',
];
const COLORS = [36, 33, 35, 32, 34, 31, 96];

function startStack({ env = {}, watch = false, quiet = false } = {}) {
  const children = [];
  let stopping = false;

  SERVICES.forEach((name, i) => {
    const args = [];
    if (watch) args.push('--watch');
    args.push(path.join(ROOT, 'services', name, 'src', 'server.js'));
    const child = spawn(process.execPath, args, {
      cwd: ROOT,
      env: { ...process.env, ...env },
      stdio: ['ignore', 'pipe', 'pipe'],
    });
    const tag = `\x1b[${COLORS[i]}m${name.padEnd(21)}\x1b[0m|`;
    const pipe = (stream, out) =>
      stream.on('data', (buf) => {
        if (quiet) return;
        for (const line of buf.toString().split('\n')) if (line.trim()) out.write(`${tag} ${line}\n`);
      });
    pipe(child.stdout, process.stdout);
    pipe(child.stderr, process.stderr);
    child.on('exit', (code, signal) => {
      if (stopping) return;
      console.error(`\n${name} exited (${signal || code}). Stopping the stack.`);
      stop();
      process.exitCode = 1;
    });
    children.push(child);
  });

  function stop() {
    if (stopping) return;
    stopping = true;
    for (const c of children) if (!c.killed) c.kill('SIGTERM');
  }
  return { stop, children };
}

module.exports = { startStack, SERVICES };

if (require.main === module) {
  const stack = startStack({ watch: process.argv.includes('--watch') });
  const shutdown = () => stack.stop();
  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);

  const base = `http://127.0.0.1:${process.env.API_GATEWAY_PORT || 8080}`;
  (async () => {
    for (let i = 0; i < 60; i++) {
      await new Promise((r) => setTimeout(r, 500));
      try {
        const r = await fetch(`${base}/api/health`);
        if (r.ok) {
          console.log(`\n  ShopSphere is ready  ->  ${base}\n  demo login: demo@shopsphere.test / Demo@12345\n  admin login: admin@shopsphere.test / Admin@12345\n`);
          return;
        }
      } catch {
        /* still starting */
      }
    }
    console.error('Stack did not become healthy within 30 seconds - check the logs above.');
  })();
}
