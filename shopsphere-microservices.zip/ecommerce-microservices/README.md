# ShopSphere - E-commerce Microservices

A complete e-commerce platform built as **7 independent Node.js microservices** plus a web storefront.
Real products (iPhone 15, Sony WH-1000XM5, MacBook Air M3, Atomic Habits ...), product images, and a
full shopping flow: browse -> search -> cart -> checkout -> payment -> order tracking -> e-mail notification.

**Zero npm dependencies.** Only Node.js (version 20 or newer) is needed. No `npm install`, no database to set up.

---

## 1. Quick start (3 steps)

```bash
# 1. Check Node (must print v20 or higher)
node -v

# 2. Unzip and enter the folder
unzip shopsphere-microservices.zip && cd ecommerce-microservices

# 3. Start all 7 services
npm start
```

Open **http://localhost:8080**.

| Account  | Email                    | Password     |
|----------|--------------------------|--------------|
| Customer | demo@shopsphere.test     | Demo@12345   |
| Admin    | admin@shopsphere.test    | Admin@12345  |

Stop with `Ctrl+C`. Run `npm test` any time to run the end-to-end test (55 checks, uses a throw-away database).

### Run with Docker instead

```bash
cp .env.example .env        # then edit the secrets (section 5)
docker compose up --build
```
Open http://localhost:8080. Data lives in Docker volumes (`docker compose down -v` wipes it).
Note: the Docker setup was written to the same config as the local run but could not be executed in the environment this project was generated in, so run it once and check `docker compose ps` shows all services `healthy`.

---

## 2. Architecture

```
                      Browser
                         |
                  API GATEWAY :8080     <- only public entry point; serves the storefront
        ┌────────┬───────┼────────┬──────────┬──────────────┐
   user-service  product  cart   order     payment      notification
      :4001      :4002   :4003   :4004      :4005          :4006
```

| Service | Port | Owns (own data folder) | Responsibility |
|---|---|---|---|
| api-gateway | 8080 | - | routing, rate limiting, security headers, static frontend, aggregated `/api/health` |
| user-service | 4001 | users | register, login (JWT), profile, delivery addresses |
| product-service | 4002 | products, categories, reservations | catalog, search/filter/sort, stock reservation |
| cart-service | 4003 | carts | per-user cart, live price + stock from product-service |
| order-service | 4004 | orders | checkout orchestration, coupons, cancel, fulfilment |
| payment-service | 4005 | payments | **sandbox** payment gateway (card / UPI / COD, refunds) |
| notification-service | 4006 | outbox | order e-mails (simulated, shown in the Inbox page) |

Each service has its own data folder under `data/<service>/` (database-per-service). Services never read each
other's files; they only talk over HTTP.

**Security model**
- Clients only reach the gateway. `/internal/*` endpoints exist on services but are protected by a shared
  `X-Internal-Key`; the gateway never routes `/internal` and strips that header from client requests.
- Passwords are hashed with scrypt. Login tokens are HS256 JWTs. Cards: only the last 4 digits are stored.
- Prices are always re-read from the catalog at checkout, never trusted from the browser.

---

## 3. The checkout flow (order-service)

1. Read the user's cart -> 2. re-price every line from the catalog -> 3. snapshot the delivery address ->
4. **reserve stock** (all-or-nothing) -> 5. create order `PENDING_PAYMENT` -> 6. charge the payment.

- Payment declined -> stock is **released**, order becomes `PAYMENT_FAILED`, **cart is kept** so the customer can retry (HTTP 402).
- Payment OK -> order `CONFIRMED`, cart cleared, confirmation e-mail sent.
- Cancel (only while `CONFIRMED`) -> refund + stock restored. Admin can advance `CONFIRMED -> SHIPPED -> DELIVERED`
  (COD cash is marked collected on delivery).
- Sending an `Idempotency-Key` header on `POST /orders` makes a double-click / retry return the same order.

Pricing: shipping Rs 49, free at Rs 999+. Coupons: `WELCOME10` (10% up to Rs 500, min Rs 500),
`SAVE200` (Rs 200 off, min Rs 2000), `FREESHIP`.

**Sandbox payment test values**

| Method | Value | Result |
|---|---|---|
| Card | 4111 1111 1111 1111 | success |
| Card | 4000 0000 0000 0002 | declined |
| Card | 4000 0000 0000 9995 | insufficient funds |
| Card | any future expiry (MM/YY), any 3-digit CVV | |
| UPI | `anyname@okhdfcbank` | success; an ID containing `fail` is declined |
| COD | - | allowed up to Rs 50,000 |

---

## 4. Project structure

```
ecommerce-microservices/
├── common/                 shared code used by every service
│   ├── config.js           loads .env + environment variables, ports, URLs, production safety check
│   ├── http.js             tiny HTTP framework (routing, JSON body, errors, request ids, logging)
│   ├── auth.js             JWT authentication, role check, internal-key guard
│   ├── jwt.js  password.js HS256 tokens, scrypt hashing
│   ├── store.js            JSON-file data store (one folder per service)
│   ├── client.js           service-to-service HTTP client: timeout, retry, circuit breaker
│   ├── validate.js         input validation (email, phone, PIN code ...)
│   └── errors.js
├── services/<name>/src/server.js     one file per microservice (api-gateway, user, product, cart, order, payment, notification)
├── services/product-service/seed/catalog.json   the 25 real products + 8 categories
├── frontend/               storefront (index.html, app.js, styles.css, images/)
├── scripts/
│   ├── start-all.js        starts all services (`npm start`, `npm run dev` for auto-restart)
│   ├── smoke-test.js       end-to-end test (`npm test`)
│   ├── generate-images.js  regenerates the product images (`npm run images`)
│   └── reset-data.js       wipes ./data (`npm run reset`)
├── Dockerfile  docker-compose.yml  .env.example
```

---

## 5. Configuration reference

Copy `.env.example` to `.env` and edit. Real environment variables override `.env`.

| Variable | Default | Meaning |
|---|---|---|
| `NODE_ENV` | development | `production` makes services refuse to start with weak secrets |
| `JWT_SECRET` | dev value | signs login tokens. Use `openssl rand -hex 32` |
| `INTERNAL_API_KEY` | dev value | service-to-service secret. Use `openssl rand -hex 32` |
| `SEED_DEMO_DATA` | true | create demo users on first start (set false in production) |
| `JWT_TTL_SECONDS` | 28800 | login lifetime |
| `RATE_LIMIT_MAX` / `AUTH_RATE_LIMIT_MAX` | 300 / 20 | requests per minute per IP (general / login+register) |
| `TRUST_PROXY` | false | set true behind nginx/ALB so real client IPs are used |
| `CORS_ORIGIN` | (none) | only if the frontend is hosted on another origin |
| `DATA_DIR` | ./data | where service data is stored |
| `<SERVICE>_PORT` | see table in section 2 | e.g. `USER_SERVICE_PORT=4001`, `API_GATEWAY_PORT=8080` |
| `<NAME>_SERVICE_URL` | http://127.0.0.1:<port> | where a service finds another (compose sets these to container names) |
| `GATEWAY_PORT` | 8080 | host port for Docker |

### Running each service by hand (to see how it works)
Open 7 terminals in the project folder and run, in this order:
```bash
node services/notification-service/src/server.js
node services/payment-service/src/server.js
node services/user-service/src/server.js
node services/product-service/src/server.js
node services/cart-service/src/server.js
node services/order-service/src/server.js
node services/api-gateway/src/server.js
```
Check everything: `curl http://localhost:8080/api/health`

### Create your own admin (when `SEED_DEMO_DATA=false`)
1. Register normally in the storefront.
2. Stop the stack, open `data/user-service/users.json`, change that user's `"role": "customer"` to `"admin"`, save.
3. Start again and log in. Admins can advance orders and edit products/stock.

---

## 6. API quick reference (all via the gateway, prefix `/api`)

```
POST /auth/register  /auth/login        GET|PUT /users/me      POST /users/me/addresses   DELETE /users/me/addresses/:id
GET  /products?q=&category=&sort=&page=&limit=&minPrice=&maxPrice=&inStock=true     GET /products/:id    GET /categories
POST /products  PUT /products/:id  PATCH /products/:id/stock                        (admin)
GET  /cart   POST /cart/items {productId,quantity}   PUT|DELETE /cart/items/:productId   DELETE /cart
POST /orders/quote {couponCode}          POST /orders {addressId, paymentMethod, couponCode}   (+ Idempotency-Key header)
GET  /orders   GET /orders/:id   POST /orders/:id/cancel   POST /orders/:id/advance (admin)
GET  /payments/order/:orderId            GET /notifications   POST /notifications/:id/read   POST /notifications/read-all
GET  /health
```
Authenticated calls need `Authorization: Bearer <token>` (returned by login/register).

Example:
```bash
TOKEN=$(curl -s localhost:8080/api/auth/login -H 'Content-Type: application/json' \
  -d '{"email":"demo@shopsphere.test","password":"Demo@12345"}' | node -pe 'JSON.parse(require("fs").readFileSync(0)).token')
curl -s localhost:8080/api/cart -H "Authorization: Bearer $TOKEN"
```

---

## 7. About the products and images

The 25 products are real product models with approximate Indian prices and specs. **Prices, ratings and
stock are demo values, not live data, and specs may not match the latest listings.** Samsung Galaxy Watch6 is deliberately out of stock and Pixel 8a is low
(3 units) so you can see those states.

The product images in `frontend/images/products/` are **drawn illustrations (SVG)** that show each product's
shape, colour and brand name - they are *not* photographs, because product photos are copyrighted by their owners
and could not be downloaded here. To use real photos:
1. Put your JPG/PNG/WEBP files in `frontend/images/products/`.
2. Edit the `"image"` field in `services/product-service/seed/catalog.json` (e.g. `"/images/products/iphone-15.jpg"`).
3. `npm run reset` and `npm start` (the catalog is re-seeded), or as admin call `PUT /api/products/:id`.

---

## 8. Going to production - what to change

This is a learning/demo-grade system. Before real customers:
- **Payments:** replace `payment-service` internals with a real provider (Razorpay / Stripe / PayU) using their hosted checkout, so card numbers never touch your servers (PCI-DSS).
- **Database:** replace `common/store.js` with PostgreSQL/MongoDB (the services use only `get/filter/insert/update/remove`). The JSON-file store runs one process per service and cannot be scaled horizontally.
- **Messaging:** order -> notification is a direct HTTP call; use a queue (RabbitMQ/Kafka/SQS) with retries. Replace `deliver()` in notification-service with SMTP/SES/SendGrid.
- **Secrets & TLS:** strong `JWT_SECRET`/`INTERNAL_API_KEY`, HTTPS in front of the gateway, `TRUST_PROXY=true`.
- **Rate limiting** is in memory per gateway process; use Redis if you run several gateways.
- **Stock-release failures** are logged (`STOCK RELEASE FAILED`) but not auto-retried; add a reconciliation job.

## 9. Troubleshooting

| Problem | Fix |
|---|---|
| `EADDRINUSE` | a port is taken; stop the other program or set e.g. `API_GATEWAY_PORT=9090` |
| `fetch is not defined` / syntax errors | Node is older than 20 - upgrade |
| Page shows no products | run `curl localhost:8080/api/health`; a service may have crashed (see its log line prefix) |
| Want a clean slate | stop the stack, `npm run reset`, start again |
| "Refusing to start in production" | set long random `JWT_SECRET` and `INTERNAL_API_KEY` |
