/* ShopSphere storefront - a dependency-free single page app.
   Talks to the API gateway on the same origin (/api/...). Hash-based routing. */
(() => {
  'use strict';

  // ---------- helpers ----------------------------------------------------------------
  const $ = (sel, el = document) => el.querySelector(sel);
  const esc = (s) =>
    String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const inr = (n) => '₹' + Number(n).toLocaleString('en-IN');
  const uuid = () =>
    window.crypto && crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`;
  const stars = (r) => '★'.repeat(Math.round(r)) + '☆'.repeat(5 - Math.round(r));
  const when = (iso) => new Date(iso).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' });

  const state = {
    token: localStorage.getItem('token'),
    user: JSON.parse(localStorage.getItem('user') || 'null'),
    cartCount: 0,
    unread: 0,
  };

  function toast(message, type = 'info') {
    const el = document.createElement('div');
    el.className = `toast ${type}`;
    el.textContent = message;
    $('#toast').append(el);
    setTimeout(() => el.remove(), 4000);
  }

  async function api(path, { method = 'GET', body, headers = {} } = {}) {
    const res = await fetch('/api' + path, {
      method,
      headers: {
        'Content-Type': 'application/json',
        ...(state.token ? { Authorization: `Bearer ${state.token}` } : {}),
        ...headers,
      },
      body: body ? JSON.stringify(body) : undefined,
    });
    let data = null;
    try {
      data = await res.json();
    } catch {
      /* empty body */
    }
    if (!res.ok) {
      if (res.status === 401 && state.token) setSession(null, null, true);
      const err = new Error((data && data.error && data.error.message) || res.statusText || 'Request failed');
      err.status = res.status;
      err.data = data;
      throw err;
    }
    return data;
  }

  function setSession(token, user, expired = false) {
    state.token = token;
    state.user = user;
    state.cartCount = 0;
    state.unread = 0;
    if (token) {
      localStorage.setItem('token', token);
      localStorage.setItem('user', JSON.stringify(user));
    } else {
      localStorage.removeItem('token');
      localStorage.removeItem('user');
    }
    if (expired) toast('Your session expired - please log in again', 'error');
    renderNav();
  }

  async function refreshBadges() {
    if (!state.token) return renderNav();
    try {
      const [cart, inbox] = await Promise.all([api('/cart'), api('/notifications')]);
      state.cartCount = cart.itemCount;
      state.unread = inbox.unread;
    } catch {
      /* ignore */
    }
    renderNav();
  }

  function renderNav() {
    const u = state.user;
    $('#nav').innerHTML = `
      <a href="#/orders">Orders</a>
      ${u ? `<a href="#/notifications">Inbox${state.unread ? `<span class="badge-count">${state.unread}</span>` : ''}</a>` : ''}
      <a href="#/cart">Cart<span class="badge-count">${state.cartCount}</span></a>
      ${
        u
          ? `<span class="muted">Hi, ${esc(u.name.split(' ')[0])}${u.role === 'admin' ? ' (admin)' : ''}</span>
             <button class="link" data-action="logout">Log out</button>`
          : '<a href="#/login">Log in</a>'
      }`;
  }

  function needLogin() {
    if (state.user) return false;
    location.hash = '#/login?next=' + encodeURIComponent(location.hash.slice(1) || '/');
    return true;
  }

  const STATUS = {
    PENDING_PAYMENT: ['Pending payment', 'low'],
    CONFIRMED: ['Confirmed', 'blue'],
    SHIPPED: ['Shipped', 'blue'],
    DELIVERED: ['Delivered', 'ok'],
    CANCELLED: ['Cancelled', 'out'],
    PAYMENT_FAILED: ['Payment failed', 'out'],
  };
  const statusPill = (s) => `<span class="pill ${(STATUS[s] || ['', 'blue'])[1]}">${esc((STATUS[s] || [s])[0])}</span>`;

  const paymentLabel = (p) => {
    if (!p) return '-';
    if (p.method === 'cod') return p.status === 'SUCCEEDED' ? 'Cash on delivery (collected)' : 'Cash on delivery';
    const what = p.method === 'card' ? `${p.brand || 'Card'} •••• ${p.last4}` : `UPI ${p.upiId}`;
    return `${what} - ${p.status.toLowerCase()}`;
  };
  const addressLabel = (a) =>
    `${a.fullName}, ${a.line1}${a.line2 ? ', ' + a.line2 : ''}, ${a.city}, ${a.state} ${a.pincode} · ${a.phone}`;

  // ---------- product card -------------------------------------------------------------
  const productCard = (p) => {
    const off = Math.round(((p.mrp - p.price) / p.mrp) * 100);
    const stock =
      p.stock === 0
        ? '<span class="pill out">Out of stock</span>'
        : p.stock <= 5
          ? `<span class="pill low">Only ${p.stock} left</span>`
          : '';
    return `
      <article class="card">
        <a class="card-img" href="#/product/${encodeURIComponent(p.id)}"><img loading="lazy" src="${esc(p.image)}" alt="${esc(p.name)}" /></a>
        <div class="card-body">
          <div class="brand-tag">${esc(p.brand)}</div>
          <a class="title" href="#/product/${encodeURIComponent(p.id)}">${esc(p.name)}</a>
          <div><span class="stars">${stars(p.rating)}</span> <span class="muted">${p.rating} (${p.ratingCount.toLocaleString('en-IN')})</span></div>
          <div class="price"><strong>${inr(p.price)}</strong><s>${inr(p.mrp)}</s><span class="off">${off}% off</span></div>
          ${stock}
          <button class="btn small" data-action="add" data-id="${esc(p.id)}" ${p.stock === 0 ? 'disabled' : ''}>Add to cart</button>
        </div>
      </article>`;
  };

  // ---------- views (each returns an HTML string, or null when it redirected) ------------
  async function viewHome(q) {
    const params = new URLSearchParams({ page: q.page || 1, limit: 12 });
    ['q', 'category', 'sort'].forEach((k) => q[k] && params.set(k, q[k]));
    const [cats, list] = await Promise.all([api('/categories'), api('/products?' + params)]);
    $('#search-input').value = q.q || '';

    const link = (patch) => {
      const next = { ...q, ...patch };
      Object.keys(next).forEach((k) => (next[k] === undefined || next[k] === '') && delete next[k]);
      const s = new URLSearchParams(next).toString();
      return '#/' + (s ? '?' + s : '');
    };
    const sorts = [
      ['relevance', 'Featured'], ['price_asc', 'Price: low to high'], ['price_desc', 'Price: high to low'],
      ['rating', 'Top rated'], ['discount', 'Biggest discount'],
    ];
    return `
      ${q.q ? `<h1>Results for “${esc(q.q)}”</h1>` : '<h1>Shop everything</h1>'}
      <div class="chips">
        <a class="chip ${q.category ? '' : 'active'}" href="${link({ category: undefined, page: undefined })}">All</a>
        ${cats.items
          .map((c) => `<a class="chip ${q.category === c.slug ? 'active' : ''}" href="${link({ category: c.slug, page: undefined })}">${c.icon} ${esc(c.name)} (${c.count})</a>`)
          .join('')}
      </div>
      <div class="toolbar">
        <span class="muted">${list.total} product${list.total === 1 ? '' : 's'}</span>
        <label class="muted" style="margin:0">Sort by
          <select data-sort>${sorts.map(([v, l]) => `<option value="${v}" ${(q.sort || 'relevance') === v ? 'selected' : ''}>${l}</option>`).join('')}</select>
        </label>
      </div>
      ${list.items.length ? `<div class="grid">${list.items.map(productCard).join('')}</div>` : '<div class="empty">No products matched your search.</div>'}
      ${
        list.totalPages > 1
          ? `<div class="pager">
               ${list.page > 1 ? `<a class="btn ghost small" href="${link({ page: list.page - 1 })}">Previous</a>` : ''}
               <span class="muted" style="align-self:center">Page ${list.page} of ${list.totalPages}</span>
               ${list.page < list.totalPages ? `<a class="btn ghost small" href="${link({ page: list.page + 1 })}">Next</a>` : ''}
             </div>`
          : ''
      }`;
  }

  async function viewProduct(_q, id) {
    const { product: p } = await api('/products/' + encodeURIComponent(id));
    const off = Math.round(((p.mrp - p.price) / p.mrp) * 100);
    const max = Math.min(10, p.stock);
    return `
      <p><a href="#/?category=${esc(p.category)}">&larr; Back to catalog</a></p>
      <div class="detail">
        <div class="hero"><img src="${esc(p.image)}" alt="${esc(p.name)}" /></div>
        <div>
          <div class="brand-tag">${esc(p.brand)}</div>
          <h1>${esc(p.name)}</h1>
          <div><span class="stars">${stars(p.rating)}</span> <span class="muted">${p.rating} · ${p.ratingCount.toLocaleString('en-IN')} ratings</span></div>
          <p class="price" style="margin:12px 0"><strong style="font-size:28px">${inr(p.price)}</strong><s>${inr(p.mrp)}</s><span class="off">${off}% off</span></p>
          <p>${esc(p.description)}</p>
          <table class="specs">${Object.entries(p.specs || {}).map(([k, v]) => `<tr><td>${esc(k)}</td><td>${esc(v)}</td></tr>`).join('')}</table>
          ${p.stock === 0 ? '<span class="pill out">Out of stock</span>' : p.stock <= 5 ? `<span class="pill low">Only ${p.stock} left in stock</span>` : '<span class="pill ok">In stock</span>'}
          <div class="actions">
            <div class="qty" data-max="${max}">
              <button type="button" data-action="qty-step" data-step="-1" aria-label="Decrease">&minus;</button>
              <span id="qty-val">1</span>
              <button type="button" data-action="qty-step" data-step="1" aria-label="Increase">+</button>
            </div>
            <button class="btn" data-action="add" data-id="${esc(p.id)}" data-qty-from="#qty-val" ${p.stock === 0 ? 'disabled' : ''}>Add to cart</button>
            <button class="btn ghost" data-action="buy-now" data-id="${esc(p.id)}" ${p.stock === 0 ? 'disabled' : ''}>Buy now</button>
          </div>
        </div>
      </div>`;
  }

  async function viewCart() {
    if (needLogin()) return null;
    const cart = await api('/cart');
    state.cartCount = cart.itemCount;
    renderNav();
    if (!cart.items.length) {
      return '<div class="panel empty"><h2>Your cart is empty</h2><p>Add something you like.</p><a class="btn" href="#/">Browse products</a></div>';
    }
    const blocked = cart.items.some((i) => i.unavailable || i.outOfStock);
    return `
      <h1>Your cart</h1>
      <div class="two-col">
        <div class="panel">
          ${cart.items
            .map(
              (i) => `
            <div class="line">
              <img src="${esc(i.image || '/images/placeholder.svg')}" alt="" />
              <div>
                <a class="name" href="#/product/${encodeURIComponent(i.productId)}">${esc(i.name)}</a>
                <div class="muted">${i.unavailable ? '' : inr(i.price) + ' each'}</div>
                ${i.outOfStock ? `<span class="pill out">Only ${i.stock} in stock - reduce quantity</span>` : ''}
              </div>
              <div class="line-end">
                <div class="qty">
                  <button data-action="cart-qty" data-id="${esc(i.productId)}" data-qty="${i.quantity - 1}" aria-label="Decrease">&minus;</button>
                  <span>${i.quantity}</span>
                  <button data-action="cart-qty" data-id="${esc(i.productId)}" data-qty="${i.quantity + 1}" aria-label="Increase">+</button>
                </div>
                <div style="margin-top:6px;text-align:right"><strong>${inr(i.lineTotal)}</strong><br />
                  <button class="chip" data-action="cart-qty" data-id="${esc(i.productId)}" data-qty="0">Remove</button></div>
              </div>
            </div>`
            )
            .join('')}
        </div>
        <div class="panel">
          <h2>Summary</h2>
          <div class="summary-row"><span>Subtotal (${cart.itemCount} items)</span><strong>${inr(cart.subtotal)}</strong></div>
          <p class="muted">Shipping and coupons are applied at checkout. Free shipping on orders of ${inr(999)}+.</p>
          <a class="btn block" href="#/checkout" ${blocked ? 'aria-disabled="true"' : ''}>Proceed to checkout</a>
        </div>
      </div>`;
  }

  async function viewCheckout(q) {
    if (needLogin()) return null;
    let quote;
    try {
      quote = await api('/orders/quote', { method: 'POST', body: { couponCode: q.coupon || undefined } });
    } catch (e) {
      if (e.status === 400 && /coupon/i.test(e.message)) {
        toast(e.message, 'error');
        location.hash = '#/checkout';
        return null;
      }
      if (e.status === 400 || e.status === 409) {
        return `<div class="panel empty"><h2>${esc(e.message)}</h2><a class="btn" href="#/cart">Back to cart</a></div>`;
      }
      throw e;
    }
    const me = (await api('/users/me')).user;
    const p = quote.pricing;
    const addrs = me.addresses;
    return `
      <h1>Checkout</h1>
      <div class="two-col">
        <div>
          <form data-form="checkout" class="panel" style="margin-bottom:20px">
            <h2>1. Delivery address</h2>
            ${
              addrs.length
                ? addrs
                    .map(
                      (a, i) => `<label class="radio-card ${a.isDefault || (i === 0 && !addrs.some((x) => x.isDefault)) ? 'selected' : ''}" style="font-weight:400;margin:0 0 10px">
                        <input type="radio" name="addressId" value="${esc(a.id)}" ${a.isDefault ? 'checked' : ''} required />
                        <span>${esc(addressLabel(a))}</span></label>`
                    )
                    .join('')
                : '<p class="muted">You have no saved address yet - add one below.</p>'
            }
            <h2 style="margin-top:20px">2. Payment method</h2>
            <div class="tabs">
              <label class="radio-card selected" style="margin:0"><input type="radio" name="pm" value="card" checked /> Card</label>
              <label class="radio-card" style="margin:0"><input type="radio" name="pm" value="upi" /> UPI</label>
              <label class="radio-card" style="margin:0"><input type="radio" name="pm" value="cod" /> Cash on delivery</label>
            </div>
            <div data-pm="card">
              <label>Card number<input type="text" name="cardNumber" inputmode="numeric" autocomplete="cc-number" placeholder="4111 1111 1111 1111" /></label>
              <label>Name on card<input type="text" name="cardName" autocomplete="cc-name" value="${esc(me.name)}" /></label>
              <div class="row">
                <label>Expiry (MM/YY)<input type="text" name="expiry" autocomplete="cc-exp" placeholder="12/30" /></label>
                <label>CVV<input type="password" name="cvv" inputmode="numeric" autocomplete="cc-csc" placeholder="123" maxlength="4" /></label>
              </div>
              <div class="hint">Sandbox cards - <strong>4111 1111 1111 1111</strong>: success &middot; <strong>4000 0000 0000 0002</strong>: declined &middot; <strong>4000 0000 0000 9995</strong>: insufficient funds. Any future expiry, any CVV.</div>
            </div>
            <div data-pm="upi" hidden>
              <label>UPI ID<input type="text" name="upiId" placeholder="name@okhdfcbank" /></label>
              <div class="hint">Any <strong>name@bank</strong> succeeds. An ID containing <strong>fail</strong> is declined.</div>
            </div>
            <div data-pm="cod" hidden><div class="hint">Pay in cash when the order arrives. Available for orders up to ${inr(50000)}.</div></div>
            <input type="hidden" name="coupon" value="${esc(q.coupon || '')}" />
            <button class="btn block" style="margin-top:18px" type="submit" ${addrs.length ? '' : 'disabled'}>Place order &middot; ${inr(p.total)}</button>
          </form>

          <details class="panel">
            <summary><strong>Add a new delivery address</strong></summary>
            <form data-form="address">
              <div class="row"><label>Full name<input type="text" name="fullName" required /></label><label>Mobile number<input type="tel" name="phone" placeholder="9876543210" required /></label></div>
              <label>Address line 1<input type="text" name="line1" required /></label>
              <label>Address line 2 (optional)<input type="text" name="line2" /></label>
              <div class="row"><label>City<input type="text" name="city" required /></label><label>State<input type="text" name="state" required /></label></div>
              <label>PIN code<input type="text" name="pincode" inputmode="numeric" maxlength="6" placeholder="560001" required /></label>
              <button class="btn" style="margin-top:14px" type="submit">Save address</button>
            </form>
          </details>
        </div>

        <aside class="panel">
          <h2>Order summary</h2>
          ${quote.items.map((i) => `<div class="summary-row"><span>${i.quantity} × ${esc(i.name)}</span><span>${inr(i.lineTotal)}</span></div>`).join('')}
          <hr style="border:0;border-top:1px solid var(--line)" />
          <div class="summary-row"><span>Subtotal</span><span>${inr(p.subtotal)}</span></div>
          ${p.discount ? `<div class="summary-row" style="color:var(--green)"><span>Coupon ${esc(p.couponCode)}</span><span>−${inr(p.discount)}</span></div>` : ''}
          <div class="summary-row"><span>Shipping</span><span>${p.shipping ? inr(p.shipping) : 'FREE'}</span></div>
          <div class="summary-row total"><span>Total</span><span>${inr(p.total)}</span></div>
          <form data-form="coupon" style="margin-top:16px">
            <label>Coupon code</label>
            <div style="display:flex;gap:8px"><input type="text" name="coupon" value="${esc(q.coupon || '')}" placeholder="WELCOME10" /><button class="btn ghost small" type="submit">Apply</button></div>
            <p class="muted" style="font-size:12px;margin:6px 0 0">${quote.coupons.map((c) => `<strong>${esc(c.code)}</strong>: ${esc(c.description)}`).join('<br />')}</p>
          </form>
        </aside>
      </div>`;
  }

  async function viewOrders(q) {
    if (needLogin()) return null;
    const isAdmin = state.user.role === 'admin';
    const { items } = await api('/orders' + (isAdmin && q.all ? '?all=true' : ''));
    return `
      <div class="toolbar"><h1 style="margin:0">${isAdmin && q.all ? 'All orders (admin)' : 'Your orders'}</h1>
        ${isAdmin ? `<a class="btn ghost small" href="#/orders${q.all ? '' : '?all=1'}">${q.all ? 'Show only mine' : 'Show all customers'}</a>` : ''}</div>
      ${
        items.length
          ? items
              .map(
                (o) => `
          <a class="panel order-card" style="display:block;color:inherit" href="#/orders/${encodeURIComponent(o.id)}">
            <div class="order-head"><div><strong>${esc(o.id)}</strong><div class="muted">${when(o.createdAt)}${isAdmin && q.all ? ` · ${esc(o.customer.email)}` : ''}</div></div>
              <div style="text-align:right">${statusPill(o.status)}<div><strong>${inr(o.pricing.total)}</strong></div></div></div>
            <div class="thumbs">${o.items.slice(0, 6).map((i) => `<img src="${esc(i.image)}" alt="${esc(i.name)}" title="${esc(i.name)}" />`).join('')}</div>
          </a>`
              )
              .join('')
          : '<div class="panel empty"><h2>No orders yet</h2><a class="btn" href="#/">Start shopping</a></div>'
      }`;
  }

  async function viewOrder(q, id) {
    if (needLogin()) return null;
    const { order: o } = await api('/orders/' + encodeURIComponent(id));
    const admin = state.user.role === 'admin';
    const nextLabel = { CONFIRMED: 'Mark as shipped', SHIPPED: 'Mark as delivered' }[o.status];
    return `
      <p><a href="#/orders">&larr; All orders</a></p>
      ${q.placed ? `<div class="notice success"><strong>Thank you!</strong> Your order was placed. A confirmation was sent to your <a href="#/notifications">inbox</a>.</div>` : ''}
      <div class="toolbar"><h1 style="margin:0">${esc(o.id)} ${statusPill(o.status)}</h1>
        <div style="display:flex;gap:8px">
          ${o.status === 'CONFIRMED' ? `<button class="btn danger small" data-action="cancel-order" data-id="${esc(o.id)}">Cancel order</button>` : ''}
          ${admin && nextLabel ? `<button class="btn small" data-action="advance-order" data-id="${esc(o.id)}">${nextLabel}</button>` : ''}
        </div></div>
      <div class="two-col">
        <div>
          <div class="panel" style="margin-bottom:20px"><h2>Items</h2>
            ${o.items.map((i) => `<div class="line"><img src="${esc(i.image)}" alt="" /><div><a class="name" href="#/product/${encodeURIComponent(i.productId)}">${esc(i.name)}</a><div class="muted">${i.quantity} × ${inr(i.unitPrice)}</div></div><strong>${inr(i.lineTotal)}</strong></div>`).join('')}
          </div>
          <div class="panel"><h2>Tracking</h2>
            <ul class="timeline">${o.timeline.map((t) => `<li><strong>${esc((STATUS[t.status] || [t.status])[0])}</strong><div class="muted">${when(t.at)}${t.note ? ' · ' + esc(t.note) : ''}</div></li>`).join('')}</ul>
          </div>
        </div>
        <aside class="panel">
          <h2>Payment</h2>
          <div class="summary-row"><span>Subtotal</span><span>${inr(o.pricing.subtotal)}</span></div>
          ${o.pricing.discount ? `<div class="summary-row" style="color:var(--green)"><span>Coupon ${esc(o.pricing.couponCode)}</span><span>−${inr(o.pricing.discount)}</span></div>` : ''}
          <div class="summary-row"><span>Shipping</span><span>${o.pricing.shipping ? inr(o.pricing.shipping) : 'FREE'}</span></div>
          <div class="summary-row total"><span>Total</span><span>${inr(o.pricing.total)}</span></div>
          <p class="muted">${esc(paymentLabel(o.payment))}</p>
          <h2 style="margin-top:18px">Delivering to</h2>
          <p class="muted">${esc(addressLabel(o.address))}</p>
        </aside>
      </div>`;
  }

  async function viewNotifications() {
    if (needLogin()) return null;
    const { items, unread } = await api('/notifications');
    return `
      <div class="toolbar"><h1 style="margin:0">Inbox</h1>${unread ? '<button class="btn ghost small" data-action="read-all">Mark all as read</button>' : ''}</div>
      <p class="muted">Emails sent by the notification service (simulated - they appear here and in the service log).</p>
      ${
        items.length
          ? items
              .map(
                (n) => `<details class="panel" style="margin-bottom:12px" ${n.read ? '' : 'open'}>
                  <summary><strong>${esc(n.subject)}</strong> ${n.read ? '' : '<span class="pill blue">new</span>'} <span class="muted"> · ${when(n.createdAt)}</span></summary>
                  <div class="mail">${esc(n.body)}</div></details>`
              )
              .join('')
          : '<div class="panel empty">No messages yet. Place an order to receive one.</div>'
      }`;
  }

  async function viewLogin(q) {
    return `
      <div class="panel narrow">
        <h1>Log in</h1>
        <form data-form="login" data-next="${esc(q.next || '/')}">
          <label>Email<input type="email" name="email" autocomplete="username" required /></label>
          <label>Password<input type="password" name="password" autocomplete="current-password" required /></label>
          <button class="btn block" style="margin-top:16px" type="submit">Log in</button>
        </form>
        <div class="hint">Demo accounts - <a href="#" data-action="fill-demo" data-email="demo@shopsphere.test" data-password="Demo@12345">customer</a> &middot;
          <a href="#" data-action="fill-demo" data-email="admin@shopsphere.test" data-password="Admin@12345">admin</a></div>
        <p class="muted">New here? <a href="#/register">Create an account</a></p>
      </div>`;
  }

  async function viewRegister() {
    return `
      <div class="panel narrow">
        <h1>Create account</h1>
        <form data-form="register">
          <label>Full name<input type="text" name="name" autocomplete="name" required minlength="2" /></label>
          <label>Email<input type="email" name="email" autocomplete="email" required /></label>
          <label>Mobile (optional)<input type="tel" name="phone" autocomplete="tel" placeholder="9876543210" /></label>
          <label>Password<input type="password" name="password" autocomplete="new-password" required minlength="8" /></label>
          <p class="muted" style="font-size:13px">At least 8 characters, with a letter and a number.</p>
          <button class="btn block" type="submit">Sign up</button>
        </form>
        <p class="muted">Already registered? <a href="#/login">Log in</a></p>
      </div>`;
  }

  // ---------- router ------------------------------------------------------------------------
  const routes = [
    [/^\/$/, viewHome],
    [/^\/product\/([^/]+)$/, viewProduct],
    [/^\/cart$/, viewCart],
    [/^\/checkout$/, viewCheckout],
    [/^\/orders$/, viewOrders],
    [/^\/orders\/([^/]+)$/, viewOrder],
    [/^\/notifications$/, viewNotifications],
    [/^\/login$/, viewLogin],
    [/^\/register$/, viewRegister],
  ];
  let renderId = 0;

  async function render() {
    const id = ++renderId;
    const [path, qs = ''] = (location.hash.slice(1) || '/').split('?');
    const query = Object.fromEntries(new URLSearchParams(qs));
    const mount = $('#app');
    for (const [re, view] of routes) {
      const m = re.exec(path);
      if (!m) continue;
      mount.innerHTML = '<div class="loading">Loading…</div>';
      try {
        const html = await view(query, ...m.slice(1).map(decodeURIComponent));
        if (id !== renderId || html === null) return;
        mount.innerHTML = html;
      } catch (e) {
        if (id !== renderId) return;
        mount.innerHTML = `<div class="panel empty"><h2>Something went wrong</h2><p>${esc(e.message)}</p><a class="btn" href="#/">Back to the store</a></div>`;
      }
      window.scrollTo(0, 0);
      return;
    }
    mount.innerHTML = '<div class="panel empty"><h2>Page not found</h2><a class="btn" href="#/">Go home</a></div>';
  }

  // ---------- actions (event delegation) --------------------------------------------------
  const guard = (fn) => async (...a) => {
    try {
      await fn(...a);
    } catch (e) {
      toast(e.message, 'error');
    }
  };

  async function addToCart(id, qty) {
    if (!state.user) {
      location.hash = '#/login?next=' + encodeURIComponent(location.hash.slice(1) || '/');
      return false;
    }
    const cart = await api('/cart/items', { method: 'POST', body: { productId: id, quantity: qty } });
    state.cartCount = cart.itemCount;
    renderNav();
    toast('Added to cart', 'success');
    return true;
  }

  const actions = {
    logout: () => {
      setSession(null, null);
      location.hash = '#/';
      toast('Logged out');
    },
    add: guard(async (t) => {
      const qty = t.dataset.qtyFrom ? Number($(t.dataset.qtyFrom).textContent) : 1;
      await addToCart(t.dataset.id, qty);
    }),
    'buy-now': guard(async (t) => {
      const qty = Number($('#qty-val').textContent);
      if (await addToCart(t.dataset.id, qty)) location.hash = '#/checkout';
    }),
    'qty-step': (t) => {
      const el = $('#qty-val');
      const max = Number(t.closest('.qty').dataset.max) || 10;
      el.textContent = Math.min(max, Math.max(1, Number(el.textContent) + Number(t.dataset.step)));
    },
    'cart-qty': guard(async (t) => {
      const qty = Number(t.dataset.qty);
      const id = encodeURIComponent(t.dataset.id);
      if (qty <= 0) await api('/cart/items/' + id, { method: 'DELETE' });
      else await api('/cart/items/' + id, { method: 'PUT', body: { quantity: qty } });
      await render();
      refreshBadges();
    }),
    'cancel-order': guard(async (t) => {
      if (!confirm('Cancel this order? Any payment will be refunded.')) return;
      await api(`/orders/${encodeURIComponent(t.dataset.id)}/cancel`, { method: 'POST' });
      toast('Order cancelled', 'success');
      await render();
    }),
    'advance-order': guard(async (t) => {
      await api(`/orders/${encodeURIComponent(t.dataset.id)}/advance`, { method: 'POST' });
      await render();
    }),
    'read-all': guard(async () => {
      await api('/notifications/read-all', { method: 'POST' });
      state.unread = 0;
      await render();
      renderNav();
    }),
    'fill-demo': (t, e) => {
      e.preventDefault();
      const f = $('form[data-form="login"]');
      f.email.value = t.dataset.email;
      f.password.value = t.dataset.password;
    },
  };

  document.addEventListener('click', (e) => {
    const t = e.target.closest('[data-action]');
    if (t && actions[t.dataset.action]) actions[t.dataset.action](t, e);
  });

  document.addEventListener('change', (e) => {
    const t = e.target;
    if (t.matches('select[data-sort]')) {
      const [path, qs = ''] = (location.hash.slice(1) || '/').split('?');
      const params = new URLSearchParams(qs);
      params.set('sort', t.value);
      params.delete('page');
      location.hash = `#${path}?${params}`;
    }
    if (t.matches('input[name="pm"]')) {
      document.querySelectorAll('[data-pm]').forEach((el) => (el.hidden = el.dataset.pm !== t.value));
      document.querySelectorAll('input[name="pm"]').forEach((r) => r.closest('.radio-card').classList.toggle('selected', r.checked));
    }
    if (t.matches('input[name="addressId"]')) {
      document.querySelectorAll('input[name="addressId"]').forEach((r) => r.closest('.radio-card').classList.toggle('selected', r.checked));
    }
  });

  const forms = {
    search: (f) => {
      const q = f.q.value.trim();
      location.hash = q ? `#/?q=${encodeURIComponent(q)}` : '#/';
    },
    login: guard(async (f) => {
      const { token, user } = await api('/auth/login', { method: 'POST', body: { email: f.email.value, password: f.password.value } });
      setSession(token, user);
      toast(`Welcome back, ${user.name.split(' ')[0]}!`, 'success');
      location.hash = '#' + (f.dataset.next || '/');
      refreshBadges();
    }),
    register: guard(async (f) => {
      const body = { name: f.name.value, email: f.email.value, password: f.password.value };
      if (f.phone.value.trim()) body.phone = f.phone.value;
      const { token, user } = await api('/auth/register', { method: 'POST', body });
      setSession(token, user);
      toast('Account created', 'success');
      location.hash = '#/';
    }),
    address: guard(async (f) => {
      await api('/users/me/addresses', {
        method: 'POST',
        body: {
          fullName: f.fullName.value, phone: f.phone.value, line1: f.line1.value, line2: f.line2.value,
          city: f.city.value, state: f.state.value, pincode: f.pincode.value,
        },
      });
      toast('Address saved', 'success');
      await render();
    }),
    coupon: (f) => {
      const c = f.coupon.value.trim();
      location.hash = c ? `#/checkout?coupon=${encodeURIComponent(c)}` : '#/checkout';
    },
    checkout: guard(async (f) => {
      const btn = f.querySelector('button[type="submit"]');
      const type = f.pm.value;
      const paymentMethod = { type };
      if (type === 'card') {
        Object.assign(paymentMethod, { cardNumber: f.cardNumber.value, cardName: f.cardName.value, expiry: f.expiry.value, cvv: f.cvv.value });
      }
      if (type === 'upi') paymentMethod.upiId = f.upiId.value;

      btn.disabled = true;
      btn.textContent = 'Processing…';
      try {
        const { order } = await api('/orders', {
          method: 'POST',
          headers: { 'Idempotency-Key': uuid() },
          body: { addressId: f.addressId.value, paymentMethod, couponCode: f.coupon.value || undefined },
        });
        state.cartCount = 0;
        renderNav();
        location.hash = `#/orders/${encodeURIComponent(order.id)}?placed=1`;
        refreshBadges();
      } catch (e) {
        btn.disabled = false;
        btn.textContent = 'Place order';
        throw e;
      }
    }),
  };

  document.addEventListener('submit', (e) => {
    const f = e.target.closest('form[data-form]');
    if (!f || !forms[f.dataset.form]) return;
    e.preventDefault();
    forms[f.dataset.form](f, e);
  });

  // images that fail to load fall back to a placeholder (inline onerror is blocked by our CSP)
  document.addEventListener(
    'error',
    (e) => {
      const img = e.target;
      if (img.tagName === 'IMG' && !img.dataset.fallback) {
        img.dataset.fallback = '1';
        img.src = '/images/placeholder.svg';
      }
    },
    true
  );

  window.addEventListener('hashchange', render);
  renderNav();
  render();
  refreshBadges();
})();
