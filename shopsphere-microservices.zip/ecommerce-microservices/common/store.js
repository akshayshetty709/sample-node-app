'use strict';
/**
 * Tiny JSON-file document store.
 *
 * Each service owns its own data folder (database-per-service pattern).
 * Writes are synchronous + atomic (write temp file, then rename), and Node is
 * single-threaded, so read-modify-write sequences without an `await` in the
 * middle are race-free. This keeps the demo dependency-free.
 *
 * In production, replace this class with PostgreSQL/MongoDB access code - the
 * services only use the small interface below (see README "Going to production").
 */
const fs = require('fs');
const path = require('path');
const { randomBytes } = require('crypto');

const newId = (prefix) => `${prefix}_${randomBytes(6).toString('hex')}`;
const now = () => new Date().toISOString();

class Collection {
  constructor(dir, name) {
    fs.mkdirSync(dir, { recursive: true });
    this.file = path.join(dir, `${name}.json`);
    this.docs = [];
    if (fs.existsSync(this.file)) {
      try {
        this.docs = JSON.parse(fs.readFileSync(this.file, 'utf8'));
      } catch (e) {
        throw new Error(`Corrupt data file ${this.file}: ${e.message}`);
      }
    }
  }

  save() {
    const tmp = `${this.file}.${process.pid}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(this.docs, null, 2));
    fs.renameSync(tmp, this.file);
  }

  count(pred) {
    return pred ? this.docs.filter(pred).length : this.docs.length;
  }
  all() {
    return structuredClone(this.docs);
  }
  filter(pred) {
    return structuredClone(this.docs.filter(pred));
  }
  findOne(pred) {
    const d = this.docs.find(pred);
    return d ? structuredClone(d) : null;
  }
  get(id) {
    return this.findOne((d) => d.id === id);
  }

  insert(doc) {
    if (!doc.id) throw new Error('Document needs an id');
    this.docs.push(structuredClone(doc));
    this.save();
    return structuredClone(doc);
  }
  insertMany(docs) {
    for (const d of docs) this.docs.push(structuredClone(d));
    this.save();
  }

  /** patchOrFn: object (shallow merge) or function(doc) that mutates the live doc */
  update(id, patchOrFn) {
    const d = this.docs.find((x) => x.id === id);
    if (!d) return null;
    if (typeof patchOrFn === 'function') patchOrFn(d);
    else Object.assign(d, patchOrFn);
    this.save();
    return structuredClone(d);
  }

  remove(id) {
    const i = this.docs.findIndex((x) => x.id === id);
    if (i === -1) return false;
    this.docs.splice(i, 1);
    this.save();
    return true;
  }
}

module.exports = { Collection, newId, now };
