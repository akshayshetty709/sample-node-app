'use strict';
/**
 * HTTP client for service-to-service calls.
 *  - per-request timeout
 *  - retries (GET only, because they are idempotent)
 *  - a tiny circuit breaker per upstream: after 5 consecutive failures the circuit
 *    opens for 10 s and calls fail fast with 503 instead of piling up
 */
const { HttpError } = require('./errors');

const breakers = new Map(); // baseUrl -> { fails, openUntil }
const FAIL_THRESHOLD = 5;
const OPEN_MS = 10_000;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function breaker(baseUrl) {
  if (!breakers.has(baseUrl)) breakers.set(baseUrl, { fails: 0, openUntil: 0 });
  return breakers.get(baseUrl);
}

async function request(baseUrl, path, opts = {}) {
  const {
    method = 'GET',
    body,
    headers = {},
    timeoutMs = 5000,
    retries = method === 'GET' ? 2 : 0,
    requestId,
    internalKey,
  } = opts;

  const b = breaker(baseUrl);
  if (b.openUntil > Date.now()) {
    throw new HttpError(503, `Service temporarily unavailable (${baseUrl})`);
  }

  let attempt = 0;
  for (;;) {
    let res;
    try {
      res = await fetch(baseUrl + path, {
        method,
        headers: {
          'Content-Type': 'application/json',
          ...(requestId ? { 'X-Request-Id': requestId } : {}),
          ...(internalKey ? { 'X-Internal-Key': internalKey } : {}),
          ...headers,
        },
        body: body === undefined ? undefined : JSON.stringify(body),
        signal: AbortSignal.timeout(timeoutMs),
      });
    } catch (e) {
      b.fails += 1;
      if (b.fails >= FAIL_THRESHOLD) b.openUntil = Date.now() + OPEN_MS;
      if (attempt < retries) {
        attempt += 1;
        await sleep(100 * 2 ** attempt);
        continue;
      }
      throw new HttpError(503, `Service unavailable: ${baseUrl}${path} (${e.name})`);
    }

    const text = await res.text();
    let data = null;
    try {
      data = text ? JSON.parse(text) : null;
    } catch {
      data = text;
    }

    if (res.status >= 500) {
      b.fails += 1;
      if (b.fails >= FAIL_THRESHOLD) b.openUntil = Date.now() + OPEN_MS;
      if (attempt < retries) {
        attempt += 1;
        await sleep(100 * 2 ** attempt);
        continue;
      }
    } else {
      b.fails = 0;
    }

    if (!res.ok) {
      throw new HttpError(
        res.status,
        (data && data.error && data.error.message) || `Upstream error ${res.status}`,
        data && data.error ? data.error.details : undefined
      );
    }
    return data;
  }
}

/** Bind a base URL + internal key once: const users = bind(cfg.urls.user, cfg.internalKey) */
function bind(baseUrl, internalKey) {
  return (path, opts = {}) => request(baseUrl, path, { internalKey, ...opts });
}

module.exports = { request, bind };
