'use strict';
/** Minimal HS256 JSON Web Token implementation (no dependencies). */
const crypto = require('crypto');

const b64 = (input) => Buffer.from(input).toString('base64url');

function sign(payload, secret, expiresInSeconds = 3600) {
  const now = Math.floor(Date.now() / 1000);
  const header = { alg: 'HS256', typ: 'JWT' };
  const body = { ...payload, iat: now, exp: now + expiresInSeconds };
  const data = `${b64(JSON.stringify(header))}.${b64(JSON.stringify(body))}`;
  const sig = crypto.createHmac('sha256', secret).update(data).digest('base64url');
  return `${data}.${sig}`;
}

function verify(token, secret) {
  const parts = String(token).split('.');
  if (parts.length !== 3) throw new Error('jwt malformed');
  const [h, p, s] = parts;

  let header;
  try {
    header = JSON.parse(Buffer.from(h, 'base64url').toString('utf8'));
  } catch {
    throw new Error('jwt malformed');
  }
  if (header.alg !== 'HS256') throw new Error('jwt unsupported algorithm');

  const expected = crypto.createHmac('sha256', secret).update(`${h}.${p}`).digest();
  const given = Buffer.from(s, 'base64url');
  if (given.length !== expected.length || !crypto.timingSafeEqual(given, expected)) {
    throw new Error('jwt invalid signature');
  }

  let payload;
  try {
    payload = JSON.parse(Buffer.from(p, 'base64url').toString('utf8'));
  } catch {
    throw new Error('jwt malformed');
  }
  if (typeof payload.exp !== 'number' || payload.exp < Math.floor(Date.now() / 1000)) {
    throw new Error('jwt expired');
  }
  return payload;
}

module.exports = { sign, verify };
