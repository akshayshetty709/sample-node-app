'use strict';
/**
 * Central configuration loader shared by every service.
 *
 * Order of precedence (highest first):
 *   1. real environment variables (docker-compose `environment:`, shell exports)
 *   2. the .env file in the project root (only for local, non-Docker runs)
 *   3. the defaults below
 */
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');

const DEFAULT_PORTS = {
  'api-gateway': 8080,
  'user-service': 4001,
  'product-service': 4002,
  'cart-service': 4003,
  'order-service': 4004,
  'payment-service': 4005,
  'notification-service': 4006,
};

const DEV_JWT_SECRET = 'dev-only-jwt-secret';
const DEV_INTERNAL_KEY = 'dev-only-internal-key';

function loadDotEnv() {
  const file = path.join(ROOT, '.env');
  if (!fs.existsSync(file)) return;
  for (const line of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
    if (!line.trim() || line.trim().startsWith('#')) continue;
    const m = /^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/.exec(line);
    if (!m) continue;
    let value = m[2];
    if (
      (value.startsWith('"') && value.endsWith('"')) ||
      (value.startsWith("'") && value.endsWith("'"))
    ) {
      value = value.slice(1, -1);
    }
    if (process.env[m[1]] === undefined) process.env[m[1]] = value;
  }
}
loadDotEnv();

const str = (name, def) => {
  const v = process.env[name];
  return v === undefined || v === '' ? def : v;
};
const int = (name, def) => {
  const n = parseInt(process.env[name], 10);
  return Number.isFinite(n) ? n : def;
};
const bool = (name, def) => {
  const v = process.env[name];
  if (v === undefined || v === '') return def;
  return ['1', 'true', 'yes', 'on'].includes(v.toLowerCase());
};

/** e.g. "user-service" -> "USER_SERVICE_PORT" */
const portVar = (service) => `${service.toUpperCase().replace(/-/g, '_')}_PORT`;
const portOf = (service) => int(portVar(service), DEFAULT_PORTS[service]);

function load(service) {
  const cfg = {
    service,
    env: str('NODE_ENV', 'development'),
    port: portOf(service),
    // 127.0.0.1 locally (safe default). Docker images set BIND_HOST=0.0.0.0.
    bindHost: str('BIND_HOST', '127.0.0.1'),
    // every service gets its own sub-folder => "database per service"
    dataDir: path.resolve(str('DATA_DIR', path.join(ROOT, 'data')), service),
    jwtSecret: str('JWT_SECRET', DEV_JWT_SECRET),
    jwtTtlSeconds: int('JWT_TTL_SECONDS', 8 * 60 * 60),
    internalKey: str('INTERNAL_API_KEY', DEV_INTERNAL_KEY),
    seedDemoData: bool('SEED_DEMO_DATA', true),
    logRequests: bool('LOG_REQUESTS', true),
    frontendDir: path.resolve(str('FRONTEND_DIR', path.join(ROOT, 'frontend'))),
    corsOrigin: str('CORS_ORIGIN', ''),
    trustProxy: bool('TRUST_PROXY', false),
    rateLimitMax: int('RATE_LIMIT_MAX', 300), // requests / minute / IP
    authRateLimitMax: int('AUTH_RATE_LIMIT_MAX', 20), // login+register / minute / IP
    urls: {
      user: str('USER_SERVICE_URL', `http://127.0.0.1:${portOf('user-service')}`),
      product: str('PRODUCT_SERVICE_URL', `http://127.0.0.1:${portOf('product-service')}`),
      cart: str('CART_SERVICE_URL', `http://127.0.0.1:${portOf('cart-service')}`),
      order: str('ORDER_SERVICE_URL', `http://127.0.0.1:${portOf('order-service')}`),
      payment: str('PAYMENT_SERVICE_URL', `http://127.0.0.1:${portOf('payment-service')}`),
      notification: str(
        'NOTIFICATION_SERVICE_URL',
        `http://127.0.0.1:${portOf('notification-service')}`
      ),
    },
  };

  if (cfg.env === 'production') {
    const weak = (s) => s.length < 24 || /change-?me|dev-only|secret$/i.test(s);
    if (weak(cfg.jwtSecret) || weak(cfg.internalKey)) {
      throw new Error(
        'Refusing to start in production with weak/default secrets. ' +
          'Set JWT_SECRET and INTERNAL_API_KEY to long random values (openssl rand -hex 32).'
      );
    }
  }
  return cfg;
}

module.exports = { load, DEFAULT_PORTS, portVar, portOf, ROOT };
