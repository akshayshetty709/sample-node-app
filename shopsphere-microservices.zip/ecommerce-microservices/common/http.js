'use strict';
/**
 * A very small HTTP framework (Express-like) built on node:http.
 *
 *   const app = createApp(cfg);
 *   app.get('/things/:id', authenticate(cfg), async (req, res) => res.json({ id: req.params.id }));
 *   await app.listen();
 *
 * Handlers run in order; a handler may throw an HttpError (-> JSON error response)
 * or end the response itself. GET /health is provided automatically.
 */
const http = require('http');
const { randomUUID } = require('crypto');
const { HttpError } = require('./errors');

const MAX_BODY_BYTES = 1024 * 1024; // 1 MB
const BODY_METHODS = new Set(['POST', 'PUT', 'PATCH', 'DELETE']);

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (c) => {
      size += c.length;
      if (size <= MAX_BODY_BYTES) chunks.push(c);
    });
    req.on('end', () => {
      if (size > MAX_BODY_BYTES) return reject(new HttpError(413, 'Payload too large'));
      resolve(Buffer.concat(chunks).toString('utf8'));
    });
    req.on('error', reject);
  });
}

async function parseBody(req) {
  const raw = await readBody(req);
  if (!raw.trim()) return {};
  try {
    const parsed = JSON.parse(raw);
    return parsed !== null && typeof parsed === 'object' ? parsed : {};
  } catch {
    throw new HttpError(400, 'Request body must be valid JSON');
  }
}

function compile(pattern) {
  const keys = [];
  const source = pattern
    .split('/')
    .map((seg) => {
      if (seg.startsWith(':')) {
        keys.push(seg.slice(1));
        return '([^/]+)';
      }
      return seg.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    })
    .join('/');
  return { re: new RegExp(`^${source}/?$`), keys };
}

function createApp(cfg, options = {}) {
  const routes = [];
  const interceptors = [];
  let server;

  function sendError(req, res, err) {
    const known = err instanceof HttpError;
    const status = known ? err.status : 500;
    if (!known) {
      console.error(
        JSON.stringify({
          level: 'error',
          svc: cfg.service,
          id: req.id,
          message: err.message,
          stack: err.stack,
        })
      );
    }
    if (res.headersSent) {
      res.end();
      return;
    }
    res.json(
      {
        error: {
          status,
          message: known ? err.message : 'Internal server error',
          details: known ? err.details : undefined,
          requestId: req.id,
        },
      },
      status
    );
  }

  async function handle(req, res) {
    const started = Date.now();
    req.id = String(req.headers['x-request-id'] || randomUUID());
    res.setHeader('X-Request-Id', req.id);
    res.json = (data, status = 200) => {
      const body = JSON.stringify(data);
      res.writeHead(status, {
        'Content-Type': 'application/json; charset=utf-8',
        'Content-Length': Buffer.byteLength(body),
      });
      res.end(body);
    };

    const url = new URL(req.url, 'http://localhost');
    req.path = url.pathname;
    req.query = Object.fromEntries(url.searchParams.entries());
    req.params = {};
    req.body = {};

    if (cfg.logRequests) {
      res.on('finish', () => {
        console.log(
          JSON.stringify({
            time: new Date().toISOString(),
            svc: cfg.service,
            id: req.id,
            method: req.method,
            path: req.path,
            status: res.statusCode,
            ms: Date.now() - started,
          })
        );
      });
    }

    try {
      if (options.cors) {
        res.setHeader('Access-Control-Allow-Origin', options.cors);
        res.setHeader('Vary', 'Origin');
        res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, Idempotency-Key');
        res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,PATCH,DELETE,OPTIONS');
        if (req.method === 'OPTIONS') {
          res.writeHead(204);
          res.end();
          return;
        }
      }

      for (const fn of interceptors) {
        if (await fn(req, res)) return;
      }

      if (req.method === 'GET' && req.path === '/health') {
        res.json({ status: 'ok', service: cfg.service, uptime: Math.round(process.uptime()) });
        return;
      }

      const allowed = new Set();
      for (const route of routes) {
        const m = route.re.exec(req.path);
        if (!m) continue;
        if (route.method !== req.method) {
          allowed.add(route.method);
          continue;
        }
        route.keys.forEach((k, i) => {
          try {
            req.params[k] = decodeURIComponent(m[i + 1]);
          } catch {
            throw new HttpError(400, 'Malformed URL parameter');
          }
        });
        if (BODY_METHODS.has(req.method)) req.body = await parseBody(req);
        for (const handler of route.handlers) {
          await handler(req, res);
          if (res.writableEnded) return;
        }
        if (!res.writableEnded) res.json({ ok: true });
        return;
      }

      if (allowed.size) {
        res.setHeader('Allow', [...allowed].join(', '));
        throw new HttpError(405, 'Method not allowed');
      }
      throw new HttpError(404, `Route not found: ${req.method} ${req.path}`);
    } catch (err) {
      sendError(req, res, err);
    }
  }

  const app = {
    /** fn(req, res) -> true when it fully handled the request (runs before routing) */
    intercept(fn) {
      interceptors.push(fn);
    },
    route(method, pattern, ...handlers) {
      routes.push({ method, ...compile(pattern), handlers });
    },
    get: (p, ...h) => app.route('GET', p, ...h),
    post: (p, ...h) => app.route('POST', p, ...h),
    put: (p, ...h) => app.route('PUT', p, ...h),
    patch: (p, ...h) => app.route('PATCH', p, ...h),
    delete: (p, ...h) => app.route('DELETE', p, ...h),

    listen() {
      return new Promise((resolve, reject) => {
        server = http.createServer((req, res) => {
          handle(req, res).catch((e) => sendError(req, res, e));
        });
        server.on('error', reject);
        server.listen(cfg.port, cfg.bindHost, () => {
          console.log(
            `[${cfg.service}] listening on http://${cfg.bindHost}:${cfg.port} (${cfg.env})`
          );
          resolve(server);
        });
        const stop = (sig) => {
          console.log(`[${cfg.service}] ${sig} received, shutting down`);
          server.close(() => process.exit(0));
          if (server.closeIdleConnections) server.closeIdleConnections();
          setTimeout(() => process.exit(1), 5000).unref();
        };
        process.once('SIGTERM', () => stop('SIGTERM'));
        process.once('SIGINT', () => stop('SIGINT'));
      });
    },
  };
  return app;
}

module.exports = { createApp };
