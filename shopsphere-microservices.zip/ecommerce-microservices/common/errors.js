'use strict';

/**
 * An error that maps directly to an HTTP response.
 * Anything that is NOT an HttpError is treated as a 500 and its message is hidden from clients.
 */
class HttpError extends Error {
  constructor(status, message, details) {
    super(message);
    this.name = 'HttpError';
    this.status = status;
    this.details = details;
  }
}

const make = (status) => (message, details) => new HttpError(status, message, details);

module.exports = {
  HttpError,
  badRequest: make(400),
  unauthorized: make(401),
  forbidden: make(403),
  notFound: make(404),
  conflict: make(409),
  tooManyRequests: make(429),
  unavailable: make(503),
};
