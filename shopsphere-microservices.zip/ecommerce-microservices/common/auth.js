'use strict';
/** Route middleware: JWT authentication, role checks, and the service-to-service key. */
const crypto = require('crypto');
const { verify } = require('./jwt');
const { unauthorized, forbidden } = require('./errors');

/** Requires `Authorization: Bearer <jwt>`; sets req.user = { id, email, name, role } */
function authenticate(cfg) {
  return async (req) => {
    const m = /^Bearer\s+(.+)$/i.exec(req.headers.authorization || '');
    if (!m) throw unauthorized('Missing bearer token');
    try {
      const p = verify(m[1], cfg.jwtSecret);
      req.user = { id: p.sub, email: p.email, name: p.name, role: p.role };
    } catch (e) {
      throw unauthorized(e.message === 'jwt expired' ? 'Token expired' : 'Invalid token');
    }
  };
}

const requireRole =
  (...roles) =>
  async (req) => {
    if (!req.user || !roles.includes(req.user.role)) throw forbidden('Insufficient permissions');
  };

/**
 * Guards /internal/* endpoints. Only other services know INTERNAL_API_KEY; the API
 * gateway never forwards /internal paths and strips this header from client requests.
 */
function internalOnly(cfg) {
  const expected = Buffer.from(cfg.internalKey);
  return async (req) => {
    const got = Buffer.from(String(req.headers['x-internal-key'] || ''));
    if (got.length !== expected.length || !crypto.timingSafeEqual(got, expected)) {
      throw forbidden('Internal endpoint');
    }
  };
}

module.exports = { authenticate, requireRole, internalOnly };
