'use strict';
/** Small input-validation helpers. They return the cleaned value or throw a 400. */
const { badRequest } = require('./errors');

function string(val, name, { min = 1, max = 200, optional = false } = {}) {
  if (val === undefined || val === null || val === '') {
    if (optional) return undefined;
    throw badRequest(`${name} is required`);
  }
  if (typeof val !== 'string') throw badRequest(`${name} must be a string`);
  const s = val.trim();
  if (s.length < min || s.length > max) {
    throw badRequest(`${name} must be between ${min} and ${max} characters`);
  }
  return s;
}

function email(val) {
  const s = string(val, 'email', { max: 254 }).toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(s)) throw badRequest('email is not valid');
  return s;
}

function password(val) {
  if (typeof val !== 'string') throw badRequest('password is required');
  if (val.length < 8 || val.length > 72) throw badRequest('password must be 8-72 characters');
  if (!/[A-Za-z]/.test(val) || !/\d/.test(val)) {
    throw badRequest('password must contain at least one letter and one number');
  }
  return val;
}

/** Indian mobile number; accepts +91 / 91 / 0 prefixes. Returns the 10 digits. */
function phone(val, name = 'phone') {
  const raw = string(val, name, { max: 20 });
  const digits = raw.replace(/[\s-]/g, '').replace(/^(\+91|91|0)(?=\d{10}$)/, '');
  if (!/^[6-9]\d{9}$/.test(digits)) throw badRequest(`${name} must be a valid 10-digit mobile number`);
  return digits;
}

function pincode(val) {
  const s = string(val, 'pincode', { max: 6 });
  if (!/^[1-9]\d{5}$/.test(s)) throw badRequest('pincode must be a valid 6-digit PIN code');
  return s;
}

function integer(val, name, { min = -Infinity, max = Infinity, optional = false } = {}) {
  if (val === undefined || val === null || val === '') {
    if (optional) return undefined;
    throw badRequest(`${name} is required`);
  }
  const n = typeof val === 'number' ? val : Number(val);
  if (!Number.isInteger(n)) throw badRequest(`${name} must be a whole number`);
  if (n < min || n > max) throw badRequest(`${name} must be between ${min} and ${max}`);
  return n;
}

module.exports = { string, email, password, phone, pincode, integer };
