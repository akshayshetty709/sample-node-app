'use strict';
/**
 * NOTIFICATION SERVICE  (port 4006)
 * Receives "send this message" requests from other services, stores them in an outbox
 * (so the UI can show an inbox) and writes them to the log as a simulated e-mail.
 *
 * To send real e-mail/SMS, replace `deliver()` with a call to SMTP / SES / SendGrid / Twilio.
 *
 * Internal: POST /internal/notifications
 * Public:   GET /notifications   POST /notifications/:id/read   POST /notifications/read-all
 */
const config = require('../../../common/config');
const { createApp } = require('../../../common/http');
const { authenticate, internalOnly } = require('../../../common/auth');
const { Collection, newId, now } = require('../../../common/store');
const { notFound } = require('../../../common/errors');
const v = require('../../../common/validate');

const cfg = config.load('notification-service');
const outbox = new Collection(cfg.dataDir, 'outbox');
const app = createApp(cfg);
const auth = authenticate(cfg);
const internal = internalOnly(cfg);

/** Replace this function to integrate a real e-mail / SMS provider. */
async function deliver(n) {
  console.log(`[notification-service] EMAIL to=${n.to} subject="${n.subject}"`);
}

app.post('/internal/notifications', internal, async (req, res) => {
  const n = outbox.insert({
    id: newId('ntf'),
    userId: v.string(req.body.userId, 'userId', { max: 60 }),
    to: v.email(req.body.to),
    type: v.string(req.body.type, 'type', { max: 60 }),
    subject: v.string(req.body.subject, 'subject', { max: 200 }),
    body: v.string(req.body.body, 'body', { max: 5000 }),
    meta: req.body.meta && typeof req.body.meta === 'object' ? req.body.meta : {},
    read: false,
    createdAt: now(),
  });
  await deliver(n);
  res.json({ notification: n }, 201);
});

app.get('/notifications', auth, async (req, res) => {
  const items = outbox
    .filter((n) => n.userId === req.user.id)
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
    .slice(0, 100);
  res.json({ items, unread: items.filter((n) => !n.read).length });
});

app.post('/notifications/read-all', auth, async (req, res) => {
  outbox.docs.forEach((n) => {
    if (n.userId === req.user.id) n.read = true;
  });
  outbox.save();
  res.json({ ok: true });
});

app.post('/notifications/:id/read', auth, async (req, res) => {
  const n = outbox.get(req.params.id);
  if (!n || n.userId !== req.user.id) throw notFound('Notification not found');
  res.json({ notification: outbox.update(n.id, { read: true }) });
});

app.listen().catch((e) => {
  console.error(e);
  process.exit(1);
});
