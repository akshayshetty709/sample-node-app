'use strict';
/**
 * PAYMENT SERVICE  (port 4005)  -  SANDBOX payment gateway simulator.
 *
 * It behaves like a real PSP (Razorpay/Stripe style): idempotent charges, declines,
 * refunds, cash-on-delivery - but NO real money moves. Card numbers are validated
 * (Luhn) and only the last 4 digits are ever stored. Never log or persist full card
 * numbers / CVV; in production use a hosted PCI-compliant checkout instead.
 *
 * Sandbox test instruments
 *   Cards : 4111 1111 1111 1111 -> success          4000 0000 0000 0002 -> declined
 *           4000 0000 0000 9995 -> insufficient funds   (any future expiry, any 3-digit CVV)
 *   UPI   : name@okhdfcbank -> success              anything containing "fail" -> declined
 *   COD   : allowed up to Rs 50,000
 *
 * Internal: POST /internal/payments  POST /internal/payments/:id/refund  POST /internal/payments/:id/collect
 *           GET /internal/payments/by-order/:orderId
 * Public:   GET /payments/order/:orderId   (owner or admin)
 */
const config = require('../../../common/config');
const { createApp } = require('../../../common/http');
const { authenticate, internalOnly } = require('../../../common/auth');
const { Collection, newId, now } = require('../../../common/store');
const { badRequest, notFound, conflict, forbidden } = require('../../../common/errors');
const v = require('../../../common/validate');

const cfg = config.load('payment-service');
const payments = new Collection(cfg.dataDir, 'payments');
const app = createApp(cfg);
const auth = authenticate(cfg);
const internal = internalOnly(cfg);

const MAX_COD_AMOUNT = 50000;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function luhn(num) {
  let sum = 0;
  let dbl = false;
  for (let i = num.length - 1; i >= 0; i--) {
    let d = Number(num[i]);
    if (dbl) {
      d *= 2;
      if (d > 9) d -= 9;
    }
    sum += d;
    dbl = !dbl;
  }
  return sum % 10 === 0;
}

function cardBrand(n) {
  if (/^4/.test(n)) return 'Visa';
  if (/^(5[1-5]|2[2-7])/.test(n)) return 'Mastercard';
  if (/^3[47]/.test(n)) return 'Amex';
  if (/^(60|65|81|82|508)/.test(n)) return 'RuPay';
  return 'Card';
}

function validateCard(m) {
  const number = String(m.cardNumber || '').replace(/[\s-]/g, '');
  if (!/^\d{13,19}$/.test(number) || !luhn(number)) throw badRequest('Card number is not valid');
  const exp = /^(0[1-9]|1[0-2])\/(\d{2})$/.exec(String(m.expiry || ''));
  if (!exp) throw badRequest('Card expiry must be in MM/YY format');
  const endOfMonth = new Date(2000 + Number(exp[2]), Number(exp[1]), 0, 23, 59, 59);
  if (endOfMonth < new Date()) throw badRequest('Card has expired');
  if (!/^\d{3,4}$/.test(String(m.cvv || ''))) throw badRequest('CVV must be 3 or 4 digits');
  v.string(m.cardName, 'cardName', { min: 2, max: 80 });
  return number;
}

/** Returns { status, failureReason?, details } without touching storage */
function process_(method, amount) {
  switch (method.type) {
    case 'card': {
      const number = validateCard(method);
      const details = { last4: number.slice(-4), brand: cardBrand(number) };
      if (number === '4000000000000002') return { status: 'FAILED', failureReason: 'Card declined by issuer', details };
      if (number === '4000000000009995') return { status: 'FAILED', failureReason: 'Insufficient funds', details };
      return { status: 'SUCCEEDED', details };
    }
    case 'upi': {
      const id = String(method.upiId || '').trim();
      if (!/^[\w.-]{2,}@[a-zA-Z]{2,}$/.test(id)) throw badRequest('UPI ID must look like name@bank');
      const details = { upiId: id };
      if (/fail/i.test(id)) return { status: 'FAILED', failureReason: 'UPI collect request was declined', details };
      return { status: 'SUCCEEDED', details };
    }
    case 'cod': {
      if (amount > MAX_COD_AMOUNT) {
        return {
          status: 'FAILED',
          failureReason: `Cash on delivery is not available above Rs ${MAX_COD_AMOUNT.toLocaleString('en-IN')}`,
          details: {},
        };
      }
      return { status: 'PENDING_COD', details: {} };
    }
    default:
      throw badRequest('Payment method must be one of: card, upi, cod');
  }
}

app.post('/internal/payments', internal, async (req, res) => {
  const orderId = v.string(req.body.orderId, 'orderId', { max: 60 });
  const userId = v.string(req.body.userId, 'userId', { max: 60 });
  const amount = v.integer(req.body.amount, 'amount', { min: 1, max: 10_000_000 });
  const currency = req.body.currency || 'INR';
  const method = req.body.method;
  if (!method || typeof method !== 'object') throw badRequest('method is required');
  const idempotencyKey = String(req.body.idempotencyKey || orderId);

  const existing = payments.findOne((p) => p.idempotencyKey === idempotencyKey);
  if (existing) return res.json({ payment: existing, replay: true });

  const outcome = process_(method, amount); // throws 400 for malformed instruments
  const payment = payments.insert({
    id: newId('pay'),
    orderId,
    userId,
    amount,
    currency,
    method: method.type,
    status: 'PROCESSING',
    idempotencyKey,
    ...outcome.details,
    createdAt: now(),
  });

  await sleep(250); // pretend to talk to a bank
  const final = payments.update(payment.id, {
    status: outcome.status,
    failureReason: outcome.failureReason || null,
    processedAt: now(),
  });
  res.json({ payment: final }, 201);
});

app.post('/internal/payments/:id/refund', internal, async (req, res) => {
  const p = payments.get(req.params.id);
  if (!p) throw notFound('Payment not found');
  if (p.status === 'REFUNDED' || p.status === 'CANCELLED') return res.json({ payment: p, replay: true });

  if (p.status === 'SUCCEEDED') {
    await sleep(150);
    return res.json({
      payment: payments.update(p.id, {
        status: 'REFUNDED',
        refundId: newId('rfd'),
        refundedAt: now(),
        refundReason: String(req.body.reason || 'Order cancelled').slice(0, 200),
      }),
    });
  }
  if (p.status === 'PENDING_COD') {
    // nothing was collected, so just void the pending cash payment
    return res.json({ payment: payments.update(p.id, { status: 'CANCELLED', cancelledAt: now() }) });
  }
  throw conflict(`A payment in status ${p.status} cannot be refunded`);
});

app.post('/internal/payments/:id/collect', internal, async (req, res) => {
  const p = payments.get(req.params.id);
  if (!p) throw notFound('Payment not found');
  if (p.status === 'SUCCEEDED') return res.json({ payment: p, replay: true });
  if (p.status !== 'PENDING_COD') throw conflict(`A payment in status ${p.status} cannot be collected`);
  res.json({ payment: payments.update(p.id, { status: 'SUCCEEDED', processedAt: now() }) });
});

app.get('/internal/payments/by-order/:orderId', internal, async (req, res) => {
  const p = payments.findOne((x) => x.orderId === req.params.orderId);
  if (!p) throw notFound('No payment for this order');
  res.json({ payment: p });
});

app.get('/payments/order/:orderId', auth, async (req, res) => {
  const p = payments.findOne((x) => x.orderId === req.params.orderId);
  if (!p) throw notFound('No payment for this order');
  if (p.userId !== req.user.id && req.user.role !== 'admin') throw forbidden('Not your payment');
  res.json({ payment: p });
});

app.listen().catch((e) => {
  console.error(e);
  process.exit(1);
});
