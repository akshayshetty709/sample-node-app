'use strict';
/**
 * API GATEWAY  (port 8080)  -  the ONLY service exposed to the outside world.
 *
 *  - serves the web frontend (static files from /frontend)
 *  - routes /api/<resource>/... to the owning microservice
 *  - never forwards /internal/* and strips any client-supplied X-Internal-Key
 *  - per-IP rate limiting (stricter on login/register)
 *  - security headers, request ids, aggregated health check
 *
 * Route table:
 *   /api/auth, /api/users           -> user-service
 *   /api/products, /api/categories  -> product-service
 *   /api/cart                       -> cart-service
 *   /api/orders                     -> order-service
 *   /api/payments                   -> payment-service
 *   /api/notifications              -> notification-service
 */
const fs = require('fs');
const http = require('http');
const path = require('path');
const config = require('../../../common/config');
const { createApp } = require('../../../common/http');

const cfg = config.load('api-gateway');
const app = createApp(cfg, { cors: cfg.corsOrigin || undefined });

const ROUTES = [
  ['/api/auth', cfg.urls.user],
  ['/api/users', cfg.urls.user],
  ['/api/products', cfg.urls.product],
  ['/api/categories', cfg.urls.product],
  ['/api/cart', cfg.urls.cart],
  ['/api/orders', cfg.urls.order],
  ['/api/payments', cfg.urls.payment],
  ['/api/notifications', cfg.urls.notification],
];

// ---- rate limiting (fixed window, in memory) -------------------------------------
const WINDOW_MS = 60_000;
const hits = new Map(); // key -> { count, resetAt }

function clientIp(req) {
  if (cfg.trustProxy && req.headers['x-forwarded-for']) {
    return String(req.headers['x-forwarded-for']).split(',')[0].trim();
  }
  return req.socket.remoteAddress || 'unknown';
}

function limited(req, res, bucket, max) {
  const key = `${bucket}:${clientIp(req)}`;
  const t = Date.now();
  let h = hits.get(key);
  if (!h || h.resetAt <= t) {
    h = { count: 0, resetAt: t + WINDOW_MS };
    hits.set(key, h);
  }
  h.count += 1;
  if (h.count > max) {
    res.setHeader('Retry-After', Math.ceil((h.resetAt - t) / 1000));
    res.json({ error: { status: 429, message: 'Too many requests, please slow down', requestId: req.id } }, 429);
    return true;
  }
  return false;
}
setInterval(() => {
  const t = Date.now();
  for (const [k, h] of hits) if (h.resetAt <= t) hits.delete(k);
}, WINDOW_MS).unref();

// ---- security headers --------------------------------------------------------------
app.intercept((req, res) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader(
    'Content-Security-Policy',
    "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'; frame-ancestors 'none'"
  );
  return false;
});

// ---- aggregated health ---------------------------------------------------------------
app.get('/api/health', async (req, res) => {
  const targets = {
    'user-service': cfg.urls.user,
    'product-service': cfg.urls.product,
    'cart-service': cfg.urls.cart,
    'order-service': cfg.urls.order,
    'payment-service': cfg.urls.payment,
    'notification-service': cfg.urls.notification,
  };
  const results = await Promise.all(
    Object.entries(targets).map(async ([name, url]) => {
      try {
        const r = await fetch(`${url}/health`, { signal: AbortSignal.timeout(2000) });
        return [name, r.ok ? 'up' : `down (${r.status})`];
      } catch {
        return [name, 'down'];
      }
    })
  );
  const services = Object.fromEntries(results);
  const healthy = Object.values(services).every((s) => s === 'up');
  res.json({ status: healthy ? 'ok' : 'degraded', services }, healthy ? 200 : 503);
});

// ---- reverse proxy ---------------------------------------------------------------------
function proxy(req, res, target) {
  const u = new URL(target);
  const upstreamPath = req.url.replace(/^\/api/, '');
  const headers = { ...req.headers };
  delete headers.host;
  delete headers['x-internal-key']; // clients must never be able to call internal APIs
  headers['x-request-id'] = req.id;
  headers['x-forwarded-for'] = clientIp(req);

  const upstream = http.request(
    { hostname: u.hostname, port: u.port, path: upstreamPath, method: req.method, headers, timeout: 15_000 },
    (up) => {
      res.writeHead(up.statusCode, up.headers);
      up.pipe(res);
    }
  );
  upstream.on('timeout', () => upstream.destroy(new Error('upstream timeout')));
  upstream.on('error', (e) => {
    if (res.headersSent) return res.destroy();
    res.json(
      { error: { status: 502, message: 'The service is temporarily unavailable', detail: e.message, requestId: req.id } },
      502
    );
  });
  req.pipe(upstream);
}

app.intercept((req, res) => {
  if (!req.path.startsWith('/api/') || req.path === '/api/health') return false;
  if (req.method === 'OPTIONS') return false;

  const isAuth = req.path.startsWith('/api/auth/');
  if (limited(req, res, isAuth ? 'auth' : 'api', isAuth ? cfg.authRateLimitMax : cfg.rateLimitMax)) return true;

  if (req.path.includes('..') || /%2e%2e/i.test(req.url)) {
    res.json({ error: { status: 400, message: 'Bad path', requestId: req.id } }, 400);
    return true;
  }
  const match = ROUTES.find(([prefix]) => req.path === prefix || req.path.startsWith(`${prefix}/`));
  if (!match) {
    res.json({ error: { status: 404, message: `No route for ${req.path}`, requestId: req.id } }, 404);
    return true;
  }
  proxy(req, res, match[1]);
  return true;
});

// ---- static frontend -------------------------------------------------------------------
const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.json': 'application/json; charset=utf-8',
};

app.intercept((req, res) => {
  if (req.method !== 'GET' && req.method !== 'HEAD') return false;
  if (req.path.startsWith('/api/')) return false;
  let rel;
  try {
    rel = decodeURIComponent(req.path);
  } catch {
    return false;
  }
  if (rel === '/') rel = '/index.html';
  const root = cfg.frontendDir;
  const file = path.join(root, path.normalize(rel));
  if (!file.startsWith(root + path.sep)) return false; // path traversal guard
  let stat;
  try {
    stat = fs.statSync(file);
  } catch {
    return false;
  }
  if (!stat.isFile()) return false;

  const ext = path.extname(file).toLowerCase();
  res.writeHead(200, {
    'Content-Type': MIME[ext] || 'application/octet-stream',
    'Content-Length': stat.size,
    'Cache-Control': rel.startsWith('/images/') ? 'public, max-age=86400' : 'no-cache',
  });
  if (req.method === 'HEAD') res.end();
  else fs.createReadStream(file).pipe(res);
  return true;
});

app.listen().catch((e) => {
  console.error(e);
  process.exit(1);
});
