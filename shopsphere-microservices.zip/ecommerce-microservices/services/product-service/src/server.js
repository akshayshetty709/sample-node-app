'use strict';
/**
 * PRODUCT SERVICE  (port 4002)
 * Catalog (search / filter / sort / paginate), categories and stock reservation.
 *
 * Public:   GET /products  GET /products/:id  GET /categories
 * Admin:    POST /products  PUT /products/:id  PATCH /products/:id/stock
 * Internal: GET /internal/products?ids=a,b
 *           POST /internal/stock/reserve   (all-or-nothing, idempotent per reservationId)
 *           POST /internal/stock/release   (idempotent)
 */
const fs = require('fs');
const path = require('path');
const config = require('../../../common/config');
const { createApp } = require('../../../common/http');
const { authenticate, requireRole, internalOnly } = require('../../../common/auth');
const { Collection, now } = require('../../../common/store');
const { badRequest, notFound, conflict } = require('../../../common/errors');
const v = require('../../../common/validate');

const cfg = config.load('product-service');
const products = new Collection(cfg.dataDir, 'products');
const categories = new Collection(cfg.dataDir, 'categories');
const reservations = new Collection(cfg.dataDir, 'reservations');
const app = createApp(cfg);
const auth = authenticate(cfg);
const admin = requireRole('admin');
const internal = internalOnly(cfg);

function seed() {
  const catalog = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'seed', 'catalog.json'), 'utf8'));
  if (categories.count() === 0) {
    categories.insertMany(catalog.categories.map((c) => ({ id: c.slug, ...c })));
  }
  if (products.count() === 0) {
    const t = now();
    products.insertMany(catalog.products.map((p) => ({ ...p, createdAt: t, updatedAt: t })));
    console.log(`[product-service] seeded ${catalog.products.length} products`);
  }
}
seed();

const slugify = (s) =>
  s
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 80);

// ---- public -------------------------------------------------------------------
app.get('/categories', async (req, res) => {
  const all = products.all();
  res.json({
    items: categories
      .all()
      .map((c) => ({ slug: c.slug, name: c.name, icon: c.icon, count: all.filter((p) => p.category === c.slug).length })),
  });
});

app.get('/products', async (req, res) => {
  const { q, category, brand, sort = 'relevance' } = req.query;
  const page = v.integer(req.query.page ?? 1, 'page', { min: 1, max: 10000 });
  const limit = v.integer(req.query.limit ?? 12, 'limit', { min: 1, max: 48 });
  const minPrice = v.integer(req.query.minPrice, 'minPrice', { min: 0, optional: true });
  const maxPrice = v.integer(req.query.maxPrice, 'maxPrice', { min: 0, optional: true });

  let items = products.all();
  if (q) {
    const terms = String(q).toLowerCase().split(/\s+/).filter(Boolean);
    items = items.filter((p) => {
      const hay = [p.name, p.brand, p.description, p.category, ...(p.tags || [])].join(' ').toLowerCase();
      return terms.every((t) => hay.includes(t));
    });
  }
  if (category) items = items.filter((p) => p.category === category);
  if (brand) items = items.filter((p) => p.brand.toLowerCase() === String(brand).toLowerCase());
  if (minPrice !== undefined) items = items.filter((p) => p.price >= minPrice);
  if (maxPrice !== undefined) items = items.filter((p) => p.price <= maxPrice);
  if (req.query.inStock === 'true') items = items.filter((p) => p.stock > 0);

  const discount = (p) => (p.mrp - p.price) / p.mrp;
  const sorters = {
    price_asc: (a, b) => a.price - b.price,
    price_desc: (a, b) => b.price - a.price,
    rating: (a, b) => b.rating - a.rating || b.ratingCount - a.ratingCount,
    discount: (a, b) => discount(b) - discount(a),
    popular: (a, b) => b.ratingCount - a.ratingCount,
    relevance: (a, b) => b.ratingCount * b.rating - a.ratingCount * a.rating,
  };
  if (!sorters[sort]) throw badRequest(`sort must be one of: ${Object.keys(sorters).join(', ')}`);
  items.sort(sorters[sort]);

  const total = items.length;
  res.json({
    items: items.slice((page - 1) * limit, page * limit),
    page,
    limit,
    total,
    totalPages: Math.max(1, Math.ceil(total / limit)),
  });
});

app.get('/products/:id', async (req, res) => {
  const p = products.get(req.params.id);
  if (!p) throw notFound('Product not found');
  res.json({ product: p });
});

// ---- admin --------------------------------------------------------------------
function validateProductInput(b, partial = false) {
  const out = {};
  const need = (key, fn) => {
    if (b[key] !== undefined || !partial) out[key] = fn(b[key]);
  };
  need('name', (x) => v.string(x, 'name', { min: 3, max: 140 }));
  need('brand', (x) => v.string(x, 'brand', { max: 60 }));
  need('category', (x) => {
    const c = v.string(x, 'category', { max: 40 });
    if (!categories.get(c)) throw badRequest(`Unknown category "${c}"`);
    return c;
  });
  need('price', (x) => v.integer(x, 'price', { min: 1, max: 10_000_000 }));
  need('mrp', (x) => v.integer(x, 'mrp', { min: 1, max: 10_000_000 }));
  need('stock', (x) => v.integer(x, 'stock', { min: 0, max: 1_000_000 }));
  need('description', (x) => v.string(x, 'description', { max: 1000 }));
  if (b.image !== undefined) out.image = v.string(b.image, 'image', { max: 300 });
  if (b.specs !== undefined) {
    if (typeof b.specs !== 'object' || Array.isArray(b.specs)) throw badRequest('specs must be an object');
    out.specs = b.specs;
  }
  if (b.tags !== undefined) {
    if (!Array.isArray(b.tags)) throw badRequest('tags must be an array');
    out.tags = b.tags.map(String).slice(0, 20);
  }
  return out;
}

app.post('/products', auth, admin, async (req, res) => {
  const data = validateProductInput(req.body);
  if (data.mrp < data.price) throw badRequest('mrp must be greater than or equal to price');
  const id = slugify(data.name);
  if (products.get(id)) throw conflict('A product with this name already exists');
  const t = now();
  const product = products.insert({
    rating: 0,
    ratingCount: 0,
    image: '/images/placeholder.svg',
    specs: {},
    tags: [],
    ...data,
    id,
    createdAt: t,
    updatedAt: t,
  });
  res.json({ product }, 201);
});

app.put('/products/:id', auth, admin, async (req, res) => {
  const data = validateProductInput(req.body, true);
  const current = products.get(req.params.id);
  if (!current) throw notFound('Product not found');
  const price = data.price ?? current.price;
  const mrp = data.mrp ?? current.mrp;
  if (mrp < price) throw badRequest('mrp must be greater than or equal to price');
  res.json({ product: products.update(req.params.id, { ...data, updatedAt: now() }) });
});

app.patch('/products/:id/stock', auth, admin, async (req, res) => {
  const stock = v.integer(req.body.stock, 'stock', { min: 0, max: 1_000_000 });
  const product = products.update(req.params.id, { stock, updatedAt: now() });
  if (!product) throw notFound('Product not found');
  res.json({ product });
});

// ---- internal -----------------------------------------------------------------
app.get('/internal/products', internal, async (req, res) => {
  const ids = String(req.query.ids || '')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);
  if (ids.length > 100) throw badRequest('Too many ids');
  const set = new Set(ids);
  res.json({ items: products.filter((p) => set.has(p.id)) });
});

app.post('/internal/stock/reserve', internal, async (req, res) => {
  const reservationId = v.string(req.body.reservationId, 'reservationId', { max: 80 });
  const items = req.body.items;
  if (!Array.isArray(items) || !items.length) throw badRequest('items must be a non-empty array');

  // idempotent: same reservationId => same result
  const existing = reservations.get(reservationId);
  if (existing && existing.status === 'reserved') return res.json({ reservation: existing, replay: true });
  if (existing) throw conflict(`Reservation ${reservationId} was already ${existing.status}`);

  const wanted = new Map();
  for (const it of items) {
    const qty = v.integer(it.quantity, 'quantity', { min: 1, max: 100 });
    wanted.set(it.productId, (wanted.get(it.productId) || 0) + qty);
  }

  // 1) check everything first ...
  for (const [productId, qty] of wanted) {
    const p = products.docs.find((x) => x.id === productId);
    if (!p) throw notFound(`Product ${productId} not found`);
    if (p.stock < qty) {
      throw conflict(`Only ${p.stock} unit(s) of ${p.name} in stock`, { productId, available: p.stock });
    }
  }
  // 2) ... then mutate (single-threaded + synchronous => atomic all-or-nothing)
  for (const [productId, qty] of wanted) {
    const p = products.docs.find((x) => x.id === productId);
    p.stock -= qty;
    p.updatedAt = now();
  }
  products.save();
  const reservation = reservations.insert({
    id: reservationId,
    status: 'reserved',
    items: [...wanted].map(([productId, quantity]) => ({ productId, quantity })),
    createdAt: now(),
  });
  res.json({ reservation }, 201);
});

app.post('/internal/stock/release', internal, async (req, res) => {
  const reservationId = v.string(req.body.reservationId, 'reservationId', { max: 80 });
  const r = reservations.get(reservationId);
  if (!r) throw notFound('Reservation not found');
  if (r.status === 'released') return res.json({ reservation: r, replay: true });

  for (const it of r.items) {
    const p = products.docs.find((x) => x.id === it.productId);
    if (p) {
      p.stock += it.quantity;
      p.updatedAt = now();
    }
  }
  products.save();
  res.json({ reservation: reservations.update(reservationId, { status: 'released', releasedAt: now() }) });
});

app.listen().catch((e) => {
  console.error(e);
  process.exit(1);
});
