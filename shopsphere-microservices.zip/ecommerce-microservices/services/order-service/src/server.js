'use strict';
/**
 * ORDER SERVICE  (port 4004)  -  the checkout orchestrator.
 *
 * Checkout flow (a "saga" with compensation):
 *   1. read the user's cart               (cart-service)
 *   2. re-price every line from catalog   (product-service)      <- never trust client prices
 *   3. snapshot the delivery address      (user-service)
 *   4. reserve stock, all-or-nothing      (product-service)
 *   5. create the order as PENDING_PAYMENT
 *   6. charge the customer                (payment-service)
 *        - declined / error  -> release stock, mark PAYMENT_FAILED, keep the cart
 *        - success           -> mark CONFIRMED, clear the cart, send notification
 *
 * Public:  POST /orders/quote  POST /orders  GET /orders  GET /orders/:id
 *          POST /orders/:id/cancel   POST /orders/:id/advance (admin: ship / deliver)
 */
const { randomBytes } = require('crypto');
const config = require('../../../common/config');
const { createApp } = require('../../../common/http');
const { authenticate, requireRole } = require('../../../common/auth');
const { Collection, now } = require('../../../common/store');
const { bind } = require('../../../common/client');
const { badRequest, notFound, conflict, forbidden } = require('../../../common/errors');
const v = require('../../../common/validate');

const cfg = config.load('order-service');
const orders = new Collection(cfg.dataDir, 'orders');
const app = createApp(cfg);
const auth = authenticate(cfg);
const admin = requireRole('admin');

const cartApi = bind(cfg.urls.cart, cfg.internalKey);
const productApi = bind(cfg.urls.product, cfg.internalKey);
const userApi = bind(cfg.urls.user, cfg.internalKey);
const paymentApi = bind(cfg.urls.payment, cfg.internalKey);
const notifyApi = bind(cfg.urls.notification, cfg.internalKey);

// ---- pricing rules (integers = whole rupees, so no floating point money bugs) ----
const FREE_SHIPPING_MIN = 999;
const SHIPPING_FEE = 49;
const COUPONS = {
  WELCOME10: {
    description: '10% off (max Rs 500) on orders of Rs 500 or more',
    minSubtotal: 500,
    discount: (s) => Math.min(Math.round(s * 0.1), 500),
  },
  SAVE200: {
    description: 'Flat Rs 200 off on orders of Rs 2,000 or more',
    minSubtotal: 2000,
    discount: () => 200,
  },
  FREESHIP: {
    description: 'Free shipping on any order',
    minSubtotal: 0,
    freeShipping: true,
    discount: () => 0,
  },
};

function priceOrder(lines, couponCode) {
  const subtotal = lines.reduce((n, l) => n + l.lineTotal, 0);
  let discount = 0;
  let freeShipping = subtotal >= FREE_SHIPPING_MIN;
  let applied = null;
  if (couponCode) {
    const code = String(couponCode).trim().toUpperCase();
    const c = COUPONS[code];
    if (!c) throw badRequest('Invalid coupon code');
    if (subtotal < c.minSubtotal) {
      throw badRequest(`Coupon ${code} needs a minimum order of Rs ${c.minSubtotal.toLocaleString('en-IN')}`);
    }
    discount = Math.min(c.discount(subtotal), subtotal);
    freeShipping = freeShipping || Boolean(c.freeShipping);
    applied = code;
  }
  const shipping = freeShipping ? 0 : SHIPPING_FEE;
  return {
    subtotal,
    discount,
    shipping,
    total: subtotal - discount + shipping,
    currency: 'INR',
    couponCode: applied,
  };
}

function newOrderId() {
  const d = new Date().toISOString().slice(0, 10).replace(/-/g, '');
  return `ORD-${d}-${randomBytes(3).toString('hex').toUpperCase()}`;
}

/** Cart + live catalog data -> validated order lines */
async function buildLines(userId, requestId) {
  const cart = await cartApi(`/internal/cart/${encodeURIComponent(userId)}`, { requestId });
  if (!cart.items.length) throw badRequest('Your cart is empty');

  const ids = cart.items.map((i) => encodeURIComponent(i.productId)).join(',');
  const catalog = await productApi(`/internal/products?ids=${ids}`, { requestId });
  const byId = new Map(catalog.items.map((p) => [p.id, p]));

  return cart.items.map((i) => {
    const p = byId.get(i.productId);
    if (!p) throw conflict('An item in your cart is no longer available', { productId: i.productId });
    if (p.stock < i.quantity) {
      throw conflict(`Only ${p.stock} unit(s) of ${p.name} in stock`, { productId: p.id, available: p.stock });
    }
    return {
      productId: p.id,
      name: p.name,
      brand: p.brand,
      image: p.image,
      unitPrice: p.price,
      quantity: i.quantity,
      lineTotal: p.price * i.quantity,
    };
  });
}

function notify(order, type, subject, body) {
  notifyApi('/internal/notifications', {
    method: 'POST',
    body: { userId: order.userId, to: order.customer.email, type, subject, body, meta: { orderId: order.id } },
  }).catch((e) => console.error(`[order-service] notification failed: ${e.message}`));
}

async function releaseStock(orderId, requestId) {
  try {
    await productApi('/internal/stock/release', { method: 'POST', body: { reservationId: orderId }, requestId });
  } catch (e) {
    // Needs manual/automatic reconciliation in a real system - log loudly.
    console.error(`[order-service] STOCK RELEASE FAILED for ${orderId}: ${e.message}`);
  }
}

function setStatus(orderId, status, note, extra = {}) {
  return orders.update(orderId, (o) => {
    o.status = status;
    o.updatedAt = now();
    o.timeline.push({ status, at: o.updatedAt, note });
    Object.assign(o, extra);
  });
}

const paymentSummary = (p) => ({
  id: p.id,
  method: p.method,
  status: p.status,
  last4: p.last4 || null,
  brand: p.brand || null,
  upiId: p.upiId || null,
  failureReason: p.failureReason || null,
});

const money = (n) => `Rs ${Number(n).toLocaleString('en-IN')}`;

// ---- quote ---------------------------------------------------------------------
app.post('/orders/quote', auth, async (req, res) => {
  const lines = await buildLines(req.user.id, req.id);
  res.json({ items: lines, pricing: priceOrder(lines, req.body.couponCode), coupons: couponList() });
});

const couponList = () =>
  Object.entries(COUPONS).map(([code, c]) => ({ code, description: c.description }));

// ---- checkout ------------------------------------------------------------------
const inflight = new Set();

app.post('/orders', auth, async (req, res) => {
  const user = req.user;
  const idemKey = req.headers['idempotency-key'] ? String(req.headers['idempotency-key']).slice(0, 100) : null;

  if (idemKey) {
    const prior = orders.findOne((o) => o.userId === user.id && o.idempotencyKey === idemKey);
    if (prior) return res.json({ order: prior, replay: true });
    if (inflight.has(`${user.id}:${idemKey}`)) throw conflict('A request with this Idempotency-Key is already in progress');
    inflight.add(`${user.id}:${idemKey}`);
  }
  try {
    await checkout(req, res, idemKey);
  } finally {
    if (idemKey) inflight.delete(`${user.id}:${idemKey}`);
  }
});

async function checkout(req, res, idemKey) {
  const user = req.user;
  const addressId = v.string(req.body.addressId, 'addressId', { max: 60 });
  const method = req.body.paymentMethod;
  if (!method || !['card', 'upi', 'cod'].includes(method.type)) {
    throw badRequest('paymentMethod.type must be one of: card, upi, cod');
  }

  // 1-3: gather + validate everything BEFORE touching stock
  const lines = await buildLines(user.id, req.id);
  const pricing = priceOrder(lines, req.body.couponCode);
  const profile = (await userApi(`/internal/users/${encodeURIComponent(user.id)}`, { requestId: req.id })).user;
  const address = profile.addresses.find((a) => a.id === addressId);
  if (!address) throw badRequest('Delivery address not found');

  // 4: reserve stock (all-or-nothing). The order id doubles as the reservation id.
  const orderId = newOrderId();
  await productApi('/internal/stock/reserve', {
    method: 'POST',
    requestId: req.id,
    body: { reservationId: orderId, items: lines.map((l) => ({ productId: l.productId, quantity: l.quantity })) },
  });

  // 5: persist the order
  const t = now();
  orders.insert({
    id: orderId,
    userId: user.id,
    customer: { name: profile.name, email: profile.email, phone: address.phone },
    status: 'PENDING_PAYMENT',
    items: lines,
    address,
    pricing,
    payment: null,
    timeline: [{ status: 'PENDING_PAYMENT', at: t, note: 'Order created and stock reserved' }],
    idempotencyKey: idemKey,
    createdAt: t,
    updatedAt: t,
  });

  // 6: charge
  let payment;
  try {
    payment = (
      await paymentApi('/internal/payments', {
        method: 'POST',
        requestId: req.id,
        timeoutMs: 10_000,
        body: {
          orderId,
          userId: user.id,
          amount: pricing.total,
          currency: pricing.currency,
          method,
          idempotencyKey: orderId,
        },
      })
    ).payment;
  } catch (e) {
    // The call may have timed out AFTER the charge went through - reconcile before compensating.
    let reconciled = null;
    if (e.status >= 500) {
      try {
        reconciled = (await paymentApi(`/internal/payments/by-order/${orderId}`, { requestId: req.id })).payment;
      } catch {
        /* no payment record */
      }
    }
    if (reconciled && ['SUCCEEDED', 'PENDING_COD'].includes(reconciled.status)) {
      payment = reconciled;
    } else {
      await releaseStock(orderId, req.id);
      if (e.status >= 400 && e.status < 500) {
        // malformed payment details (e.g. bad card number): nothing was attempted, so leave no order behind
        orders.remove(orderId);
      } else {
        setStatus(orderId, 'PAYMENT_FAILED', `Payment could not be processed: ${e.message}`);
      }
      throw e;
    }
  }

  if (payment.status === 'FAILED') {
    await releaseStock(orderId, req.id);
    const failed = setStatus(orderId, 'PAYMENT_FAILED', payment.failureReason, { payment: paymentSummary(payment) });
    notify(
      failed,
      'payment_failed',
      `Payment failed for order ${orderId}`,
      `Hi ${profile.name},\n\nYour payment of ${money(pricing.total)} could not be completed (${payment.failureReason}). ` +
        `No money was taken and your cart is still saved - you can try again.\n\nShopSphere`
    );
    return res.json(
      { error: { status: 402, code: 'PAYMENT_FAILED', message: `Payment failed: ${payment.failureReason}` }, order: failed },
      402
    );
  }

  const cod = payment.status === 'PENDING_COD';
  const confirmed = setStatus(
    orderId,
    'CONFIRMED',
    cod ? 'Order confirmed - pay on delivery' : 'Payment received, order confirmed',
    { payment: paymentSummary(payment) }
  );

  try {
    await cartApi(`/internal/cart/${encodeURIComponent(user.id)}`, { method: 'DELETE', requestId: req.id });
  } catch (e) {
    console.error(`[order-service] could not clear cart for ${user.id}: ${e.message}`);
  }

  notify(
    confirmed,
    'order_confirmed',
    `Order ${orderId} confirmed`,
    `Hi ${profile.name},\n\nThanks for shopping with ShopSphere! Your order ${orderId} is confirmed.\n` +
      confirmed.items.map((i) => `  - ${i.quantity} x ${i.name}`).join('\n') +
      `\n\nTotal: ${money(pricing.total)} (${cod ? 'pay on delivery' : 'paid'})\n` +
      `Delivering to: ${address.fullName}, ${address.line1}, ${address.city} ${address.pincode}\n\nShopSphere`
  );
  res.json({ order: confirmed }, 201);
}

// ---- read ----------------------------------------------------------------------
app.get('/orders', auth, async (req, res) => {
  const all = req.query.all === 'true' && req.user.role === 'admin';
  const items = orders
    .filter((o) => all || o.userId === req.user.id)
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  res.json({ items });
});

function loadOwned(req) {
  const order = orders.get(req.params.id);
  if (!order) throw notFound('Order not found');
  if (order.userId !== req.user.id && req.user.role !== 'admin') throw forbidden('Not your order');
  return order;
}

app.get('/orders/:id', auth, async (req, res) => {
  res.json({ order: loadOwned(req) });
});

// ---- cancel --------------------------------------------------------------------
app.post('/orders/:id/cancel', auth, async (req, res) => {
  const order = loadOwned(req);
  if (order.status !== 'CONFIRMED') {
    throw conflict(`Orders with status ${order.status} cannot be cancelled`);
  }

  // refund first: if it fails, nothing else has changed and the customer can retry
  let payment = order.payment;
  if (payment && payment.id) {
    const refunded = (
      await paymentApi(`/internal/payments/${encodeURIComponent(payment.id)}/refund`, {
        method: 'POST',
        body: { reason: 'Cancelled by customer' },
        requestId: req.id,
      })
    ).payment;
    payment = paymentSummary(refunded);
  }
  await releaseStock(order.id, req.id);
  const cancelled = setStatus(order.id, 'CANCELLED', 'Order cancelled', { payment });
  notify(
    cancelled,
    'order_cancelled',
    `Order ${order.id} cancelled`,
    `Hi ${order.customer.name},\n\nYour order ${order.id} was cancelled.` +
      (payment && payment.status === 'REFUNDED' ? ` A refund of ${money(order.pricing.total)} has been initiated.` : '') +
      '\n\nShopSphere'
  );
  res.json({ order: cancelled });
});

// ---- fulfilment (admin) ----------------------------------------------------------
const NEXT = { CONFIRMED: 'SHIPPED', SHIPPED: 'DELIVERED' };

app.post('/orders/:id/advance', auth, admin, async (req, res) => {
  const order = orders.get(req.params.id);
  if (!order) throw notFound('Order not found');
  const next = NEXT[order.status];
  if (!next) throw conflict(`Orders with status ${order.status} cannot be advanced`);

  let extra = {};
  if (next === 'DELIVERED' && order.payment && order.payment.status === 'PENDING_COD') {
    const collected = (
      await paymentApi(`/internal/payments/${encodeURIComponent(order.payment.id)}/collect`, {
        method: 'POST',
        requestId: req.id,
      })
    ).payment;
    extra = { payment: paymentSummary(collected) };
  }
  const updated = setStatus(
    order.id,
    next,
    next === 'SHIPPED' ? 'Handed over to the courier' : 'Delivered to the customer',
    extra
  );
  notify(
    updated,
    `order_${next.toLowerCase()}`,
    `Order ${order.id} ${next === 'SHIPPED' ? 'has shipped' : 'was delivered'}`,
    `Hi ${order.customer.name},\n\nYour order ${order.id} ${next === 'SHIPPED' ? 'is on its way.' : 'has been delivered. Enjoy!'}\n\nShopSphere`
  );
  res.json({ order: updated });
});

app.listen().catch((e) => {
  console.error(e);
  process.exit(1);
});
