'use strict';
/**
 * CART SERVICE  (port 4003)
 * One cart per user. Prices are NOT stored in the cart - they are always read from the
 * product service so the customer sees current prices and stock.
 *
 * Public:   GET /cart  POST /cart/items  PUT /cart/items/:productId  DELETE /cart/items/:productId  DELETE /cart
 * Internal: GET /internal/cart/:userId   DELETE /internal/cart/:userId
 */
const config = require('../../../common/config');
const { createApp } = require('../../../common/http');
const { authenticate, internalOnly } = require('../../../common/auth');
const { Collection, now } = require('../../../common/store');
const { bind } = require('../../../common/client');
const { notFound, conflict } = require('../../../common/errors');
const v = require('../../../common/validate');

const cfg = config.load('cart-service');
const carts = new Collection(cfg.dataDir, 'carts'); // document id == userId
const app = createApp(cfg);
const auth = authenticate(cfg);
const internal = internalOnly(cfg);
const productApi = bind(cfg.urls.product, cfg.internalKey);

const MAX_PER_ITEM = 10;
const MAX_LINES = 30;

async function fetchProducts(ids, requestId) {
  if (!ids.length) return new Map();
  const data = await productApi(`/internal/products?ids=${ids.map(encodeURIComponent).join(',')}`, { requestId });
  return new Map(data.items.map((p) => [p.id, p]));
}

function getCart(userId) {
  return carts.get(userId) || { id: userId, items: [], updatedAt: now() };
}

function saveCart(cart) {
  cart.updatedAt = now();
  if (carts.get(cart.id)) carts.update(cart.id, { items: cart.items, updatedAt: cart.updatedAt });
  else carts.insert(cart);
}

async function present(cart, requestId) {
  const byId = await fetchProducts(cart.items.map((i) => i.productId), requestId);
  const items = cart.items.map((i) => {
    const p = byId.get(i.productId);
    if (!p) return { productId: i.productId, quantity: i.quantity, unavailable: true, name: 'Unavailable product', lineTotal: 0 };
    return {
      productId: p.id,
      name: p.name,
      brand: p.brand,
      image: p.image,
      price: p.price,
      mrp: p.mrp,
      quantity: i.quantity,
      stock: p.stock,
      lineTotal: p.price * i.quantity,
      outOfStock: p.stock < i.quantity, // customer must fix before checkout
    };
  });
  return {
    items,
    itemCount: items.reduce((n, i) => n + i.quantity, 0),
    subtotal: items.reduce((n, i) => n + i.lineTotal, 0),
    currency: 'INR',
    updatedAt: cart.updatedAt,
  };
}

app.get('/cart', auth, async (req, res) => {
  res.json(await present(getCart(req.user.id), req.id));
});

app.post('/cart/items', auth, async (req, res) => {
  const productId = v.string(req.body.productId, 'productId', { max: 100 });
  const quantity = v.integer(req.body.quantity ?? 1, 'quantity', { min: 1, max: MAX_PER_ITEM });

  const byId = await fetchProducts([productId], req.id);
  const product = byId.get(productId);
  if (!product) throw notFound('Product not found');
  if (product.stock === 0) throw conflict(`${product.name} is out of stock`);

  const cart = getCart(req.user.id);
  const line = cart.items.find((i) => i.productId === productId);
  const newQty = (line ? line.quantity : 0) + quantity;
  const limit = Math.min(MAX_PER_ITEM, product.stock);
  if (newQty > limit) {
    throw conflict(`You can buy at most ${limit} unit(s) of ${product.name}`, { limit });
  }
  if (line) line.quantity = newQty;
  else {
    if (cart.items.length >= MAX_LINES) throw conflict('Cart is full');
    cart.items.push({ productId, quantity });
  }
  saveCart(cart);
  res.json(await present(cart, req.id), 201);
});

app.put('/cart/items/:productId', auth, async (req, res) => {
  const quantity = v.integer(req.body.quantity, 'quantity', { min: 0, max: MAX_PER_ITEM });
  const cart = getCart(req.user.id);
  const idx = cart.items.findIndex((i) => i.productId === req.params.productId);
  if (idx === -1) throw notFound('Item is not in your cart');

  if (quantity === 0) cart.items.splice(idx, 1);
  else {
    const product = (await fetchProducts([req.params.productId], req.id)).get(req.params.productId);
    if (!product) throw notFound('Product not found');
    const limit = Math.min(MAX_PER_ITEM, product.stock);
    if (quantity > limit) throw conflict(`You can buy at most ${limit} unit(s) of ${product.name}`, { limit });
    cart.items[idx].quantity = quantity;
  }
  saveCart(cart);
  res.json(await present(cart, req.id));
});

app.delete('/cart/items/:productId', auth, async (req, res) => {
  const cart = getCart(req.user.id);
  cart.items = cart.items.filter((i) => i.productId !== req.params.productId);
  saveCart(cart);
  res.json(await present(cart, req.id));
});

app.delete('/cart', auth, async (req, res) => {
  const cart = getCart(req.user.id);
  cart.items = [];
  saveCart(cart);
  res.json(await present(cart, req.id));
});

// ---- internal -----------------------------------------------------------------
app.get('/internal/cart/:userId', internal, async (req, res) => {
  res.json({ items: getCart(req.params.userId).items });
});

app.delete('/internal/cart/:userId', internal, async (req, res) => {
  const cart = getCart(req.params.userId);
  cart.items = [];
  saveCart(cart);
  res.json({ ok: true });
});

app.listen().catch((e) => {
  console.error(e);
  process.exit(1);
});
