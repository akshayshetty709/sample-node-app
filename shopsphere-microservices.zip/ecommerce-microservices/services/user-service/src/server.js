'use strict';
/**
 * USER SERVICE  (port 4001)
 * Registration, login (JWT), profile and saved delivery addresses.
 *
 * Public (via gateway):  POST /auth/register  POST /auth/login
 *                        GET|PUT /users/me   POST /users/me/addresses   DELETE /users/me/addresses/:id
 * Internal:              GET /internal/users/:id
 */
const config = require('../../../common/config');
const { createApp } = require('../../../common/http');
const { authenticate, internalOnly } = require('../../../common/auth');
const { sign } = require('../../../common/jwt');
const { hashPassword, verifyPassword } = require('../../../common/password');
const { Collection, newId, now } = require('../../../common/store');
const { unauthorized, conflict, notFound, badRequest } = require('../../../common/errors');
const v = require('../../../common/validate');

const cfg = config.load('user-service');
const users = new Collection(cfg.dataDir, 'users');
const app = createApp(cfg);
const auth = authenticate(cfg);
const internal = internalOnly(cfg);

const MAX_ADDRESSES = 5;
let DUMMY_HASH; // used to keep login timing similar for unknown emails

const publicUser = (u) => ({
  id: u.id,
  email: u.email,
  name: u.name,
  phone: u.phone || null,
  role: u.role,
  addresses: u.addresses,
  createdAt: u.createdAt,
});

const issueToken = (u) =>
  sign({ sub: u.id, email: u.email, name: u.name, role: u.role }, cfg.jwtSecret, cfg.jwtTtlSeconds);

app.post('/auth/register', async (req, res) => {
  const email = v.email(req.body.email);
  const password = v.password(req.body.password);
  const name = v.string(req.body.name, 'name', { min: 2, max: 80 });
  const phone = req.body.phone ? v.phone(req.body.phone) : null;

  const passwordHash = await hashPassword(password);
  // check + insert happen synchronously (no await in between) => no duplicate-email race
  if (users.findOne((u) => u.email === email)) {
    throw conflict('An account with this email already exists');
  }
  const user = users.insert({
    id: newId('usr'),
    email,
    name,
    phone,
    role: 'customer',
    passwordHash,
    addresses: [],
    createdAt: now(),
  });
  res.json({ user: publicUser(user), token: issueToken(user) }, 201);
});

app.post('/auth/login', async (req, res) => {
  const email = v.email(req.body.email);
  const password = typeof req.body.password === 'string' ? req.body.password : '';
  const user = users.findOne((u) => u.email === email);
  const ok = await verifyPassword(password, user ? user.passwordHash : DUMMY_HASH);
  if (!user || !ok) throw unauthorized('Invalid email or password');
  res.json({ user: publicUser(user), token: issueToken(user) });
});

app.get('/users/me', auth, async (req, res) => {
  const user = users.get(req.user.id);
  if (!user) throw notFound('User not found');
  res.json({ user: publicUser(user) });
});

app.put('/users/me', auth, async (req, res) => {
  const patch = {};
  if (req.body.name !== undefined) patch.name = v.string(req.body.name, 'name', { min: 2, max: 80 });
  if (req.body.phone !== undefined) patch.phone = v.phone(req.body.phone);
  if (!Object.keys(patch).length) throw badRequest('Nothing to update');
  const user = users.update(req.user.id, patch);
  if (!user) throw notFound('User not found');
  res.json({ user: publicUser(user) });
});

app.post('/users/me/addresses', auth, async (req, res) => {
  const b = req.body;
  const address = {
    id: newId('adr'),
    fullName: v.string(b.fullName, 'fullName', { min: 2, max: 80 }),
    phone: v.phone(b.phone),
    line1: v.string(b.line1, 'line1', { max: 120 }),
    line2: v.string(b.line2, 'line2', { max: 120, optional: true }) || '',
    city: v.string(b.city, 'city', { max: 60 }),
    state: v.string(b.state, 'state', { max: 60 }),
    pincode: v.pincode(b.pincode),
    isDefault: Boolean(b.isDefault),
  };
  const current = users.get(req.user.id);
  if (!current) throw notFound('User not found');
  if (current.addresses.length >= MAX_ADDRESSES) {
    throw conflict(`You can save at most ${MAX_ADDRESSES} addresses`);
  }
  const user = users.update(req.user.id, (u) => {
    if (address.isDefault || u.addresses.length === 0) {
      u.addresses.forEach((a) => (a.isDefault = false));
      address.isDefault = true;
    }
    u.addresses.push(address);
  });
  res.json({ address, user: publicUser(user) }, 201);
});

app.delete('/users/me/addresses/:id', auth, async (req, res) => {
  const current = users.get(req.user.id);
  if (!current || !current.addresses.some((a) => a.id === req.params.id)) {
    throw notFound('Address not found');
  }
  const user = users.update(req.user.id, (u) => {
    u.addresses = u.addresses.filter((a) => a.id !== req.params.id);
    if (u.addresses.length && !u.addresses.some((a) => a.isDefault)) u.addresses[0].isDefault = true;
  });
  res.json({ user: publicUser(user) });
});

// ---- internal (service-to-service) --------------------------------------------
app.get('/internal/users/:id', internal, async (req, res) => {
  const user = users.get(req.params.id);
  if (!user) throw notFound('User not found');
  res.json({ user: publicUser(user) });
});

// ---- start --------------------------------------------------------------------
async function seedDemoUsers() {
  if (!cfg.seedDemoData || users.count() > 0) return;
  const mk = async (email, name, role, password, addresses = []) => ({
    id: newId('usr'),
    email,
    name,
    phone: '9876543210',
    role,
    passwordHash: await hashPassword(password),
    addresses,
    createdAt: now(),
  });
  users.insertMany([
    await mk('admin@shopsphere.test', 'Store Admin', 'admin', 'Admin@12345'),
    await mk('demo@shopsphere.test', 'Demo Customer', 'customer', 'Demo@12345', [
      {
        id: newId('adr'),
        fullName: 'Demo Customer',
        phone: '9876543210',
        line1: '221, MG Road',
        line2: 'Near Trinity Metro Station',
        city: 'Bengaluru',
        state: 'Karnataka',
        pincode: '560001',
        isDefault: true,
      },
    ]),
  ]);
  console.log('[user-service] seeded demo users (admin@shopsphere.test, demo@shopsphere.test)');
}

(async () => {
  DUMMY_HASH = await hashPassword('not-a-real-password-1');
  await seedDemoUsers();
  await app.listen();
})().catch((e) => {
  console.error(e);
  process.exit(1);
});
