package com.bikerz.qa.pages;

import io.qameta.allure.Step;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/** Page object for the model details dialog. */
public class DetailPage {
    private final WebDriver driver;
    private final WebDriverWait wait;

    public DetailPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(20));
    }

    public DetailPage waitUntilOpen() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#modal:not([hidden]) #mTitle")));
        return this;
    }

    public String title() {
        return driver.findElement(By.id("mTitle")).getText();
    }

    public int versionCount() {
        return driver.findElements(By.cssSelector(".versions-wrap tbody tr")).size();
    }

    public List<String> versionPrices() {
        return driver.findElements(By.cssSelector(".versions-wrap td.price-cell")).stream()
                .map(WebElement::getText).collect(Collectors.toList());
    }

    public int specCount() {
        return driver.findElements(By.cssSelector("table.specs tbody tr")).size();
    }

    /** Value of a specification row, matched case-insensitively (the label is shown in capitals). */
    public Optional<String> spec(String label) {
        for (WebElement row : driver.findElements(By.cssSelector("table.specs tbody tr"))) {
            String key = row.findElement(By.tagName("th")).getText();
            if (key.equalsIgnoreCase(label)) {
                return Optional.of(row.findElement(By.tagName("td")).getText());
            }
        }
        return Optional.empty();
    }

    public boolean imageLoaded() {
        WebElement img = driver.findElement(By.cssSelector("#modalBody .detail-top img"));
        Object ok = ((JavascriptExecutor) driver).executeScript(
                "return arguments[0].complete && arguments[0].naturalWidth > 0;", img);
        return Boolean.TRUE.equals(ok);
    }

    @Step("Close the details dialog")
    public void close() {
        driver.findElement(By.id("closeModal")).click();
        wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("modal")));
    }

    public boolean isOpen() {
        return driver.findElement(By.id("modal")).isDisplayed();
    }
}
