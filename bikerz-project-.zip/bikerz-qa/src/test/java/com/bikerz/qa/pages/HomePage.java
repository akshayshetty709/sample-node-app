package com.bikerz.qa.pages;

import com.bikerz.qa.utils.Config;
import io.qameta.allure.Step;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/** Page object for the Bikerz catalogue (home) page. */
public class HomePage {
    private static final By CARDS = By.cssSelector("#grid .card");

    private final WebDriver driver;
    private final WebDriverWait wait;

    public HomePage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(20));
    }

    @Step("Open the Bikerz home page")
    public HomePage open() {
        driver.get(Config.baseUrl() + "/");
        return waitForCards();
    }

    public String title() {
        return driver.getTitle();
    }

    public HomePage waitForCards() {
        wait.until(ExpectedConditions.numberOfElementsToBeMoreThan(CARDS, 0));
        return this;
    }

    public HomePage waitForCardCount(int expected) {
        wait.until(ExpectedConditions.numberOfElementsToBe(CARDS, expected));
        return this;
    }

    public int cardCount() {
        return driver.findElements(CARDS).size();
    }

    /** The number shown on the "All (27)" brand button. */
    public int totalFromAllButton() {
        String text = driver.findElement(By.cssSelector(".brand-btn[data-brand='']")).getText();
        Matcher m = Pattern.compile("\\((\\d+)\\)").matcher(text);
        if (!m.find()) throw new IllegalStateException("No count in button text: " + text);
        return Integer.parseInt(m.group(1));
    }

    public int brandButtonCount() {
        // minus the "All" button
        return driver.findElements(By.cssSelector("#brandNav .brand-btn")).size() - 1;
    }

    @Step("Select brand {brandId}")
    public HomePage selectBrand(String brandId) {
        driver.findElement(By.cssSelector(".brand-btn[data-brand='" + brandId + "']")).click();
        return this;
    }

    @Step("Search for '{query}'")
    public HomePage search(String query) {
        WebElement box = driver.findElement(By.id("search"));
        box.clear();
        box.sendKeys(query);
        return this;
    }

    @Step("Choose type '{category}'")
    public HomePage selectCategory(String category) {
        new Select(driver.findElement(By.id("category"))).selectByVisibleText(category);
        return this;
    }

    @Step("Sort by {sortValue}")
    public HomePage sortBy(String sortValue) {
        new Select(driver.findElement(By.id("sort"))).selectByValue(sortValue);
        return this;
    }

    public List<String> cardNames() {
        return texts("#grid .card h3");
    }

    public List<String> cardBrands() {
        return texts("#grid .card .brandline");
    }

    public List<String> cardTypes() {
        return texts("#grid .card .chip:first-child");
    }

    /** Lowest ("from") price of every visible card, in rupees. */
    public List<Integer> cardPrices() {
        return driver.findElements(By.cssSelector("#grid .card .price b")).stream()
                .map(e -> Integer.parseInt(e.getText().replaceAll("[^0-9]", "")))
                .collect(Collectors.toList());
    }

    public boolean emptyMessageVisible() {
        return driver.findElement(By.id("empty")).isDisplayed();
    }

    public HomePage waitForEmptyMessage() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("empty")));
        return this;
    }

    public HomePage waitUntilPricesSorted(boolean ascending) {
        wait.until(d -> {
            List<Integer> p = cardPrices();
            if (p.size() < 2) return false;
            for (int i = 1; i < p.size(); i++) {
                if (ascending ? p.get(i) < p.get(i - 1) : p.get(i) > p.get(i - 1)) return false;
            }
            return true;
        });
        return this;
    }

    @Step("Open model details: {modelId}")
    public DetailPage openModel(String modelId) {
        WebElement card = wait.until(ExpectedConditions.elementToBeClickable(
                By.cssSelector(".card[data-id='" + modelId + "']")));
        card.click();
        return new DetailPage(driver).waitUntilOpen();
    }

    private List<String> texts(String css) {
        return driver.findElements(By.cssSelector(css)).stream()
                .map(WebElement::getText).collect(Collectors.toList());
    }
}
