package com.bikerz.qa.tests;

import com.bikerz.qa.utils.ApiClient;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import io.qameta.allure.Description;
import io.qameta.allure.Epic;
import io.qameta.allure.Feature;
import org.testng.annotations.Test;

import java.net.http.HttpResponse;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

@Epic("Bikerz")
@Feature("API")
public class ApiTest {

    @Test(description = "Health endpoint reports ok")
    @Description("GET /health must return HTTP 200 and status=ok (this is what the deploy pipeline checks)")
    public void healthIsOk() {
        HttpResponse<String> r = ApiClient.get("/health");
        assertEquals(r.statusCode(), 200);
        JsonObject body = ApiClient.json("/health").getAsJsonObject();
        assertEquals(body.get("status").getAsString(), "ok");
    }

    @Test(description = "All 9 brands are listed")
    public void brandsAreListed() {
        JsonArray brands = ApiClient.json("/api/brands").getAsJsonArray();
        assertEquals(brands.size(), 9, "Expected 9 brands");
        String all = brands.toString().toLowerCase();
        for (String id : new String[]{"royal-enfield", "jawa", "yezdi", "tvs", "apache", "yamaha", "bajaj", "ktm", "avenis"}) {
            assertTrue(all.contains("\"" + id + "\""), "Missing brand " + id);
        }
    }

    @Test(description = "Brand filter returns only that brand")
    public void brandFilterWorks() {
        JsonArray bikes = ApiClient.json("/api/bikes?brand=ktm").getAsJsonArray();
        assertTrue(bikes.size() > 0, "KTM should have models");
        bikes.forEach(e -> assertEquals(e.getAsJsonObject().get("brand").getAsString(), "ktm"));
    }

    @Test(description = "Every model has a positive price and an image path")
    public void everyModelHasPriceAndImage() {
        JsonArray bikes = ApiClient.json("/api/bikes").getAsJsonArray();
        assertTrue(bikes.size() >= 27, "Expected at least 27 models, got " + bikes.size());
        bikes.forEach(e -> {
            JsonObject b = e.getAsJsonObject();
            assertTrue(b.get("minPrice").getAsInt() > 0, b.get("id") + " has no price");
            assertTrue(b.get("image").getAsString().startsWith("/images/"), b.get("id") + " has no image");
        });
    }

    @Test(description = "Model detail contains versions and specifications")
    public void modelDetailHasVersionsAndSpecs() {
        JsonObject bike = ApiClient.json("/api/bikes/re-classic-350").getAsJsonObject();
        assertEquals(bike.get("name").getAsString(), "Classic 350");
        assertFalse(bike.getAsJsonArray("versions").isEmpty(), "No versions");
        assertTrue(bike.getAsJsonObject("specs").has("Engine"), "No Engine spec");
    }

    @Test(description = "Unknown model returns 404")
    public void unknownModelReturns404() {
        assertEquals(ApiClient.get("/api/bikes/does-not-exist").statusCode(), 404);
    }

    @Test(description = "Prices sort low to high")
    public void priceSortAscending() {
        JsonArray bikes = ApiClient.json("/api/bikes?sort=price-asc").getAsJsonArray();
        int previous = 0;
        for (var e : bikes) {
            int price = e.getAsJsonObject().get("minPrice").getAsInt();
            assertTrue(price >= previous, "Not sorted ascending at " + e.getAsJsonObject().get("id"));
            previous = price;
        }
    }
}
