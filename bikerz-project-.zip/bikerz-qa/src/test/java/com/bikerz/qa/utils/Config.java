package com.bikerz.qa.utils;

/** Test configuration, read from system properties (-DbaseUrl=... -Dheadless=true). */
public final class Config {
    private Config() {}

    public static String baseUrl() {
        String url = System.getProperty("baseUrl", "http://localhost:8090").trim();
        return url.endsWith("/") ? url.substring(0, url.length() - 1) : url;
    }

    public static boolean headless() {
        return Boolean.parseBoolean(System.getProperty("headless", "true"));
    }
}
