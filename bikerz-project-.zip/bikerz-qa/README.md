# Bikerz QA Automation

Selenium + TestNG + Allure test suite for the **Bikerz** site, run by the Jenkins job **`Sample-QA-Automation-Job`**.

- 7 API tests, 9 catalogue/UI tests, and 29 model-detail tests (one per model) = **about 45 test runs**
- Runs in **headless Chrome**
- Reads the application URL from the system property **`baseUrl`**
- After the run: **Allure report, HTML report, ZIP archive and e-mail notification**

```
Bikerz Jenkins job ──(build job, APP_URL)──► Sample-QA-Automation-Job
                                              │ 1. checkout bikerz-qa repo
                                              │ 2. check APP_URL/health
                                              │ 3. mvn clean test -DbaseUrl=APP_URL -Dheadless=true
                                              └ 4. Allure + HTML + ZIP + e-mail
```

## 0. Project layout

```
bikerz-qa/
├── Jenkinsfile                          # pipeline of Sample-QA-Automation-Job
├── pom.xml                              # dependencies, Surefire + Allure agent
└── src/test
    ├── resources/testng.xml             # which test classes run
    ├── resources/allure.properties
    └── java/com/bikerz/qa
        ├── utils/Config.java            # baseUrl / headless from -D properties
        ├── utils/ApiClient.java         # HTTP helper for API tests
        ├── pages/HomePage.java          # page object: catalogue page
        ├── pages/DetailPage.java        # page object: model details dialog
        └── tests/
            ├── BaseTest.java            # starts Chrome, screenshot on failure
            ├── ApiTest.java             # /health, /api/brands, /api/bikes...
            ├── HomePageTest.java        # brands, search, filter, sorting
            └── DetailTest.java          # versions, prices, specs, image (all models)
```

> These tests were written against the Bikerz site and their element selectors were checked against the running site in a browser. The Maven build itself (download of libraries and test run) could not be executed where the files were written, so **do the local run in step 2 first** and fix anything it reports before you create the Jenkins job.

Some tests expect the sample data (9 brands, 27+ models, KTM = 3 models, Classic 350 = 4 versions, Scooter type = 2 models). If you change `bikes.json` in the Bikerz project, update those numbers in `ApiTest`, `HomePageTest` and `DetailTest`.

---

## 1. Prerequisites (on the machine that runs the tests)

| Tool | Version | Check |
|------|---------|-------|
| JDK | 17 or newer | `java -version` |
| Maven | 3.8+ | `mvn -v` |
| Google Chrome | recent | `google-chrome --version` |
| Allure CLI (only for viewing locally) | 2.x | `allure --version` |

Chromedriver is **downloaded automatically** by Selenium (Selenium Manager), so you do not install it.

Ubuntu quick install:

```bash
sudo apt-get update
sudo apt-get install -y openjdk-17-jdk maven
wget -q https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb
sudo apt-get install -y ./google-chrome-stable_current_amd64.deb
```

---

## 2. Run the tests on your laptop first

1. Start Bikerz (either option):
   - `cd bikerz && docker compose up -d --build` → site at `http://localhost:8090`
   - or `cd bikerz/api && STATIC_DIR=../web node server.js` → site at `http://localhost:3000`
2. Run the tests:

   ```bash
   cd bikerz-qa
   mvn clean test -DbaseUrl=http://localhost:8090 -Dheadless=true
   ```
   (use `-Dheadless=false` to watch the browser)
3. Expected end of output:

   ```
   Tests run: 45, Failures: 0, Errors: 0, Skipped: 0
   BUILD SUCCESS
   ```
4. View the report (needs the Allure CLI):

   ```bash
   allure serve target/allure-results
   ```
5. Run one class only: `mvn test -Dtest=ApiTest` … note: with `testng.xml` configured, to run a single class temporarily use `mvn test -Dsurefire.suiteXmlFiles= -Dtest=ApiTest`.

If something fails here, fix it **before** continuing.

---

## 3. Put the QA project in GitHub

```bash
cd bikerz-qa
git init
git add .
git commit -m "Bikerz QA automation"
git branch -M main
git remote add origin git@github.com:<YOUR-GITHUB-ORG>/bikerz-qa.git
git push -u origin main
```
(Create the empty private repo `bikerz-qa` on GitHub first.)

---

## 4. Prepare Jenkins (one time)

### 4.1 Plugins
Manage Jenkins → Plugins → Available plugins. Install:

| Plugin | Used for |
|--------|----------|
| **Allure Jenkins Plugin** | Allure report |
| **HTML Publisher** | `publishHTML` step |
| **Pipeline Utility Steps** | `zip` step |
| **Email Extension** | `emailext` step |
| Git, Pipeline, Credentials | usually already installed |

Restart Jenkins if asked.

### 4.2 Allure tool
Manage Jenkins → **Tools** → **Allure Commandline** → *Add Allure Commandline*:
- Name: **`allure`** (must match the Jenkinsfile)
- Tick *Install automatically* and choose a 2.x version → **Save**.

### 4.3 E-mail (SMTP)
Manage Jenkins → **System** → *Extended E-mail Notification*:
- SMTP server / port / credentials of your mail service (for Gmail: `smtp.gmail.com`, port 465, SSL, an *app password*).
- Default recipients (optional) → **Save**.

### 4.4 The agent that runs the job
The Jenkins node that executes the job needs **JDK 17, Maven and Google Chrome** (step 1), and must be able to reach `http://3.133.28.120:8090`.

Quick test on that machine:

```bash
curl -fsS http://3.133.28.120:8090/health
```

---

## 5. Create the QA job

1. Jenkins home → **New Item**.
2. Name: **`Sample-QA-Automation-Job`** (exactly this, the Bikerz pipeline refers to it) → **Pipeline** → OK.
3. **Pipeline** section → *Pipeline script from SCM* → SCM **Git**.
4. Repository URL: `git@github.com:<YOUR-GITHUB-ORG>/bikerz-qa.git`; Credentials: the one that can read the repo; Branch: `*/main`.
5. Script Path: `Jenkinsfile` → **Save**.

---

## 6. First run of the QA job (manual)

1. Click **Build Now**. The first build only registers the parameters (`APP_URL`, `EMAIL_TO`), so it may use the defaults.
2. Click **Build with Parameters**:
   - `APP_URL` = `http://3.133.28.120:8090`
   - `EMAIL_TO` = your e-mail
3. Click **Build**. Stages:
   1. **Checkout**
   2. **Check application is reachable** (calls `/health`)
   3. **Run automation tests** (`mvn clean test -DbaseUrl=... -Dheadless=true`)
   4. Post actions: validate Allure results → Allure report → HTML publish → ZIP + archive → e-mail

---

## 7. Check the results

- Left menu of the build: **Allure Report** (graphs, failed tests with screenshots).
- Left menu of the job: **Allure HTML Report** (static copy).
- Build page → **Artifacts**: `allure-report.zip`.
- Your inbox: result e-mail with the ZIP attached.
- Console output: look for `Tests run: ..., Failures: 0`.

---

## 8. Connect it to the Bikerz deployment pipeline

Both jobs are on the same Jenkins, so the Bikerz pipeline uses the built-in `build job:` step.

1. Open the **Bikerz** deploy job → **Build with Parameters**.
2. Set:
   - `QA_JOB_NAME` = `Sample-QA-Automation-Job`
   - `APP_URL` = `http://3.133.28.120:8090`
   - `TRIGGER_QA` = ticked
   - `WAIT_FOR_QA` = ticked (optional: Bikerz turns UNSTABLE if QA fails)
3. After the deploy succeeds, a new `Sample-QA-Automation-Job` build appears automatically.
4. When happy, set the default of `TRIGGER_QA` to `true` in the Bikerz Jenkinsfile and push, so nobody has to tick it.

Full flow: **push code → Bikerz Jenkins deploys → health check OK → QA job starts → Allure report + e-mail.**

---

## 9. Troubleshooting

| Problem | Fix |
|---------|-----|
| `session not created` / Chrome not found | install Chrome on the Jenkins agent (step 1) |
| `chrome not reachable` / `DevToolsActivePort file doesn't exist` | the options `--no-sandbox` and `--disable-dev-shm-usage` are already set; make sure the agent has enough memory, and that Chrome is not the snap version |
| Selenium cannot download chromedriver | agent has no internet; allow access or install a matching chromedriver on the agent PATH |
| `Check application is reachable` fails | agent cannot reach `APP_URL`: firewall / security group for port 8090, or the site is down |
| Tests fail with count mismatches | `bikes.json` changed; update the expected numbers (see the note in section 0) |
| `No such DSL method 'allure'` | Allure Jenkins plugin missing (step 4.1) |
| `Allure commandline 'allure' not found` | tool name in Global Tool Configuration must be exactly `allure` (step 4.2) |
| `No such DSL method 'zip'` | install *Pipeline Utility Steps* |
| `No such DSL method 'emailext'` | install *Email Extension* |
| No e-mail received | check SMTP settings (step 4.3), spam folder and the Jenkins console for mail errors |
| Static *Allure HTML Report* shows a blank page | Jenkins blocks scripts in published HTML (Content-Security-Policy); use the **Allure Report** link instead, or relax CSP in *Script Console* (ask your admin) |
| Report empty / `no Allure result files` | the tests did not start; read the *Run automation tests* console output |
| `java.lang.UnsupportedClassVersionError` | JDK older than 17 on the agent |
| Allure `@Step` text missing in report | the AspectJ agent is wired in `pom.xml`; make sure Maven could download `aspectjweaver` |
