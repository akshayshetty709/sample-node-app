# Bikerz

A classic-styled motorcycle & scooter catalogue: **brands → models → versions**, with **images, prices and full specifications**.

Brands: **Royal Enfield, Jawa, Yezdi, TVS, Apache, Yamaha, Bajaj, KTM, Avenis** (27 models, 69 versions).

It is packaged with Docker and deploys with a Jenkins pipeline (same style as the RouteIQ pipeline: clone → build → swap → health check → automatic rollback), with an optional QA-automation trigger at the end.

```
Browser ──► nginx (web container, :8090) ──► /api, /health ──► Node API (api container, :3000)
                     │
                     └── serves the classic-style website + bike images
```

---

## 0. What is in the project

```
bikerz/
├── Jenkinsfile                  # Jenkins pipeline (deploy + optional QA trigger)
├── docker-compose.yml           # web + api containers
├── api/
│   ├── server.js                # REST API (no npm dependencies)
│   ├── package.json
│   ├── Dockerfile
│   └── data/bikes.json          # ALL brands, models, versions, specs, prices  <-- edit this
├── web/
│   ├── index.html               # the website
│   ├── css/style.css            # classic (parchment / burgundy / gold) design
│   ├── js/app.js
│   ├── images/bikes/*.svg       # one image per model
│   ├── nginx.conf
│   └── Dockerfile
└── scripts/
    ├── generate-images.js       # regenerates the SVG bike images
    └── setup-server.sh          # one-time server setup (Docker, git, GitHub host key)
```

### API endpoints

| Endpoint | Returns |
|----------|---------|
| `GET /health` | `{"status":"ok"}` – used by the pipeline health check |
| `GET /api/brands` | all brands with model counts |
| `GET /api/bikes?brand=ktm&q=duke&category=Naked&sort=price-asc` | model list (`sort`: `name`, `price-asc`, `price-desc`, `cc`) |
| `GET /api/bikes/<id>` | one model with all versions, colours, specs |

---

## 1. Prerequisites

On your laptop (for local testing):
- Node.js 18+ (or only Docker, see 2B)
- Git

On the deploy server (Ubuntu, `3.133.28.120`):
- Docker + Docker Compose plugin + git (installed by `scripts/setup-server.sh`, step 6)

In Jenkins (already used for RouteIQ):
- SSH Agent plugin, Pipeline plugin
- SSH credential with ID **`routeiq-backend`** (the same one the RouteIQ pipeline uses)

### 1.1 Check Jenkins is installed and running

1. Open your Jenkins URL in the browser (for example `http://<jenkins-server>:8080`) and log in.
2. If you do not have Jenkins yet, install it on a Linux server (Ubuntu):

   ```bash
   sudo apt-get update
   sudo apt-get install -y fontconfig openjdk-17-jre
   sudo wget -O /usr/share/keyrings/jenkins-keyring.asc https://pkg.jenkins.io/debian-stable/jenkins.io-2023.key
   echo "deb [signed-by=/usr/share/keyrings/jenkins-keyring.asc] https://pkg.jenkins.io/debian-stable binary/" | sudo tee /etc/apt/sources.list.d/jenkins.list
   sudo apt-get update && sudo apt-get install -y jenkins
   sudo systemctl enable --now jenkins
   sudo cat /var/lib/jenkins/secrets/initialAdminPassword
   ```
   Open `http://<server>:8080`, paste the password, choose **Install suggested plugins**, create the admin user.

### 1.2 Jenkins plugins needed for the deploy job

Manage Jenkins → **Plugins** → **Installed plugins** (search each name). Install any that are missing from **Available plugins**, then restart Jenkins:

| Plugin | Used for |
|--------|----------|
| **SSH Agent** | `sshagent([...])` in the Jenkinsfile |
| **Pipeline** | Pipeline jobs |
| **Git** | checkout of the Jenkinsfile |
| **Credentials / Credentials Binding** | stored SSH keys |

### 1.3 Make sure you can push to GitHub from your laptop

1. Check for an existing key: `ls ~/.ssh/id_ed25519.pub`
2. If it does not exist, create one (press Enter for defaults):

   ```bash
   ssh-keygen -t ed25519 -C "your-email@example.com"
   cat ~/.ssh/id_ed25519.pub
   ```
3. GitHub → your profile picture → **Settings → SSH and GPG keys → New SSH key** → paste the key → **Add SSH key**.
4. Test it: `ssh -T git@github.com` → you should see *"Hi <username>! You've successfully authenticated..."*

### 1.4 Make sure you can log in to the server

1. You need the `.pem` key file that belongs to the server (AWS key pair).
2. Restrict its permissions and test:

   ```bash
   chmod 400 ~/Downloads/your-key.pem
   ssh -i ~/Downloads/your-key.pem ubuntu@3.133.28.120
   ```
3. If you can log in, type `exit`. (This is the same key Jenkins stores as the `routeiq-backend` credential, with username `ubuntu`.)

---

## 2. Run it on your laptop first

### 2A. Without Docker (fastest)

```bash
cd bikerz/api
STATIC_DIR=../web node server.js
```

Open **http://localhost:3000**.
(`STATIC_DIR` makes the API also serve the website, so no nginx is needed locally.)

### 2B. With Docker (exactly like the server)

```bash
cd bikerz
docker compose up -d --build
```

Open **http://localhost:8090** and check **http://localhost:8090/health**.

Stop it with `docker compose down`.

---

## 3. Customise the data (prices, specs, versions, images)

Everything shown on the site comes from **`api/data/bikes.json`**.

> **Important:** the prices and specifications in the file are approximate, indicative ex-showroom figures (INR) entered as a starting point. They were **not** verified against the manufacturers' current price lists. Please check them against official brand websites / dealers before publishing.

### 3.1 Edit a price
Open `api/data/bikes.json`, find the model, change `"price"` of the version (number in rupees, no commas).

### 3.2 Add a new version
Inside the model's `"versions"` array add:

```json
{ "name": "Black Edition", "price": 195000,
  "colours": ["Matte Black"], "highlights": "Blacked-out styling, dual-channel ABS" }
```

### 3.3 Add a new model
Copy an existing model block in `"bikes"`, then change:
- `id` (unique, lowercase, dashes only, e.g. `ktm-250-duke`)
- `brand` (must match a brand `id` in the `"brands"` list)
- `name`, `category`, `tagline`, `cc`
- `specs` (any key/value pairs you want shown)
- `versions`
- `image` → `/images/bikes/<id>.svg`

### 3.4 Add a new brand
Add to the `"brands"` array: `id`, `name`, `country`, `founded`, `accent` (hex colour used on its illustrations) and `blurb`.

### 3.5 Images
The images are **vintage-style illustrations** (generated, so there are no copyright problems). To (re)generate the illustrations for every model after editing the data:

```bash
node scripts/generate-images.js
```

To use **real photos** instead:
1. Get photos you have the right to use (e.g. from the manufacturer's press/media kit or your own).
2. Save them as `web/images/bikes/<id>.jpg` (about 1200×750 px works well).
3. In `bikes.json` change the model's `"image"` to `"/images/bikes/<id>.jpg"`.

### 3.6 After any change
- Local: restart `node server.js` (data is read at start-up).
- Server: commit + push, then run the Jenkins job (step 9).

---

## 4. Put the project in GitHub

1. On GitHub create an **empty private repo** named `bikerz` (no README / .gitignore).
2. In your project folder:

   ```bash
   cd bikerz
   git init
   git add .
   git commit -m "Bikerz: initial version"
   git branch -M main
   git remote add origin git@github.com:<YOUR-GITHUB-ORG>/bikerz.git
   git push -u origin main
   ```
3. Open `Jenkinsfile` and replace the placeholder in:

   ```groovy
   REPO = 'git@github.com:<YOUR-GITHUB-ORG>/bikerz.git'
   ```

   Commit and push again:

   ```bash
   git commit -am "Set repo URL" && git push
   ```

---

## 5. Let Jenkins / the server read the new repo

The pipeline logs in to the server with Jenkins credential `routeiq-backend` and **forwards that SSH key** so the server can `git clone` your repo. So that key must have read access to `bikerz`.

1. Get the public key of the credential `routeiq-backend` (the `.pub` file of the private key you stored in Jenkins).
2. GitHub → repo `bikerz` → **Settings → Deploy keys → Add deploy key** → paste the key → leave "Allow write access" **unticked** → Add.
3. If GitHub says **"Key is already in use"** (a deploy key can only belong to one repo), choose one of:
   - add the key to a GitHub user/machine account that has read access to both repos (**Settings → SSH keys** of that account), **or**
   - create a new key (`ssh-keygen -t ed25519 -f bikerz_deploy`), add it as the deploy key of `bikerz`, create a new Jenkins credential for it (e.g. ID `bikerz-deploy`), and change `sshagent(['routeiq-backend'])` to `sshagent(['bikerz-deploy'])` in the Jenkinsfile (both stages). The key must also be allowed to log in to the server (`~/.ssh/authorized_keys` of the `ubuntu` user).

---

## 6. Prepare the server (one time)

1. Log in:

   ```bash
   ssh ubuntu@3.133.28.120
   ```
2. Copy `scripts/setup-server.sh` to the server (or paste it) and run:

   ```bash
   bash setup-server.sh
   ```

   It installs Docker, the Compose plugin and git, adds `ubuntu` to the `docker` group and trusts GitHub's host key.
3. **Log out and log in again** so the docker group takes effect, then test:

   ```bash
   docker ps
   ```
   (no `permission denied` = OK. Skip this whole step if Docker is already installed for RouteIQ.)
4. **Open the port.** AWS Console → EC2 → your instance → **Security** → security group → **Edit inbound rules** → add:

   | Type | Port | Source |
   |------|------|--------|
   | Custom TCP | **8090** | `0.0.0.0/0` (or your office IP range) |

5. **Port clash check.** RouteIQ's gateway uses port 8080 on the same server. Bikerz therefore uses **8090** (see `docker-compose.yml` and `HEALTH_URL`). Check it is free:

   ```bash
   sudo ss -ltnp | grep 8090 || echo "8090 is free"
   ```
   To use another port, change `BIKERZ_PORT` default in `docker-compose.yml`, the `HEALTH_URL` default in the Jenkinsfile and the security-group rule.

---

## 7. Prepare Jenkins (one time)

1. **Server host key** – on the machine that runs Jenkins (as the user that runs Jenkins):

   ```bash
   ssh-keyscan -H 3.133.28.120 >> ~/.ssh/known_hosts
   ```
   (The Jenkinsfile uses `StrictHostKeyChecking=yes`. If the RouteIQ pipeline already works, this is done.)
2. **Credential** `routeiq-backend` must exist: Manage Jenkins → Credentials → (global) → *SSH Username with private key*, username `ubuntu`. (Or your new `bikerz-deploy` from step 5.)
3. **Create the job**
   1. Jenkins home → **New Item** → name `bikerz-deploy` → **Pipeline** → OK.
   2. Under **Pipeline** choose **Pipeline script from SCM**.
   3. SCM: **Git**, Repository URL `git@github.com:<YOUR-GITHUB-ORG>/bikerz.git`, Credentials: a credential that can read the repo (the same SSH key), Branch: `*/main`.
   4. Script Path: `Jenkinsfile`.
   5. **Save**.

---

## 8. First deployment

1. Open the job → **Build Now** (the first run only registers the parameters; it works with defaults).
2. Then **Build with Parameters**:

   | Parameter | Value |
   |-----------|-------|
   | `BRANCH` | `main` |
   | `HEALTH_URL` | `http://localhost:8090/health` |
   | `TRIGGER_QA` | leave **unticked** for now (see step 11) |

3. Click **Build**. The pipeline does:

   | Stage | What happens on the server |
   |-------|----------------------------|
   | **Clone new release** | clones the branch into `/home/ubuntu/bikerz_new` and checks the files exist |
   | **Build and switch** | `docker compose config` + `docker compose build` (new version is built **before** touching the live one), stops the old stack, moves folders (`bikerz` → `bikerz_old`, `bikerz_new` → `bikerz`), starts the new stack, then calls `/health` for up to ~60 s |
   | **Health check failed?** | automatic **rollback**: stops the new stack, restores `bikerz_old`, rebuilds and starts it, and fails the build |
   | **Trigger QA Automation** | optional, only if `TRIGGER_QA` is ticked |

---

## 9. Verify

- Browser: **http://3.133.28.120:8090** → the Bikerz catalogue.
- Health: **http://3.133.28.120:8090/health** → `{"status":"ok", ...}`
- API: **http://3.133.28.120:8090/api/bikes?brand=ktm**
- On the server:

  ```bash
  cd /home/ubuntu/bikerz
  docker compose ps
  docker compose logs --tail=50
  ```

### Every later change
Edit → `git commit` → `git push` → Jenkins **Build with Parameters** → done (≈1–2 minutes).

---

## 10. Manual rollback

The previous release is kept in `/home/ubuntu/bikerz_old` (until the next deploy).

```bash
ssh ubuntu@3.133.28.120
cd /home/ubuntu/bikerz && docker compose down
mv /home/ubuntu/bikerz /home/ubuntu/bikerz_bad
mv /home/ubuntu/bikerz_old /home/ubuntu/bikerz
cd /home/ubuntu/bikerz && docker compose up -d --build
```

---

## 11. QA automation trigger (same Jenkins)

The QA project lives in the separate folder/repo **`bikerz-qa`** (see its own README for every step). The QA job `Sample-QA-Automation-Job` runs on the **same Jenkins** as this pipeline, so the trigger is the built-in `build job:` step: no API token, firewall or extra credential is needed.

Order of work:
1. Finish steps 1-9 (Bikerz deployed and working).
2. Create the QA job from `bikerz-qa` (follow `bikerz-qa/README.md`, steps 4-8) and run it once by hand.
3. In the Bikerz job → **Build with Parameters**:

   | Parameter | Value |
   |-----------|-------|
   | `QA_JOB_NAME` | `Sample-QA-Automation-Job` (exact name) |
   | `APP_URL` | `http://3.133.28.120:8090` |
   | `TRIGGER_QA` | ticked |
   | `WAIT_FOR_QA` | ticked if you want Bikerz to wait and turn **UNSTABLE** when QA fails; unticked to just start QA |

4. When it works every time, change `TRIGGER_QA` default to `true` in the Jenkinsfile (and commit) to make it fully automatic.

If the QA job is on a **different** Jenkins server, this `build job:` step cannot be used; use the Remote Build API method from the QA integration document instead.

---

## 12. Troubleshooting

| Problem | Fix |
|---------|-----|
| `Host key verification failed` (Jenkins → server) | run `ssh-keyscan -H 3.133.28.120 >> ~/.ssh/known_hosts` on the Jenkins machine |
| `Permission denied (publickey)` while cloning | the forwarded key has no access to the `bikerz` repo – see step 5 |
| `permission denied ... docker.sock` | `sudo usermod -aG docker ubuntu`, then log out/in |
| `docker: 'compose' is not a command` | `sudo apt-get install -y docker-compose-plugin` |
| `port is already allocated` | something else uses 8090 – see step 6.5 |
| Pipeline fails at *Health check* and rolls back | read the Jenkins console: the pipeline prints the last 50 container log lines before rolling back. Also confirm `HEALTH_URL` is `http://localhost:8090/health`, and test the same stack on your laptop with `docker compose up --build` |
| Site opens but is empty / "Could not reach the Bikerz API" | `docker compose logs api`; check `curl localhost:8090/api/bikes` on the server |
| Cannot open `http://3.133.28.120:8090` from your browser | security-group rule for 8090 missing (step 6.4) |
| Fonts look plain | the site loads Google Fonts; offline it falls back to Georgia/Times (still classic) |
| Changes to `bikes.json` not visible | you must redeploy (data is baked into the API image) |
| `No item named Sample-QA-Automation-Job found` | the job name in `QA_JOB_NAME` does not match the QA job exactly (check folders) |
| `Job ... is not parameterized` / APP_URL rejected | run the QA job once by hand so its `APP_URL` parameter is registered |

---

## 13. Notes

- No npm packages are needed: the API uses only Node's built-in modules, so builds are fast and there is nothing to patch.
- "Apache" is TVS's performance range and "Avenis" is Suzuki's scooter; they are listed as their own brands as requested.
- Prices change often (taxes, new model years). Treat the supplied prices as placeholders to verify.
- Brand names belong to their owners; the illustrations are generic drawings, not manufacturer artwork.
