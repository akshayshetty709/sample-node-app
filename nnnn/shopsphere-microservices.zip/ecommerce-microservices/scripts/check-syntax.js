#!/usr/bin/env node
'use strict';
/** CI "lint" stage: syntax-check every .js file and validate the catalog JSON. */
const { execFileSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const SKIP = new Set(['node_modules', 'data', '.git']);

function walk(dir, out = []) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    if (SKIP.has(e.name)) continue;
    const p = path.join(dir, e.name);
    if (e.isDirectory()) walk(p, out);
    else if (e.name.endsWith('.js')) out.push(p);
  }
  return out;
}

let bad = 0;
const files = walk(ROOT);
for (const f of files) {
  try {
    execFileSync(process.execPath, ['--check', f], { stdio: 'pipe' });
  } catch (e) {
    bad += 1;
    console.error(`SYNTAX ERROR in ${path.relative(ROOT, f)}\n${e.stderr}`);
  }
}
try {
  const c = JSON.parse(fs.readFileSync(path.join(ROOT, 'services/product-service/seed/catalog.json'), 'utf8'));
  const cats = new Set(c.categories.map((x) => x.slug));
  for (const p of c.products) {
    if (!cats.has(p.category)) throw new Error(`product ${p.id} has unknown category ${p.category}`);
    if (!fs.existsSync(path.join(ROOT, 'frontend', p.image))) throw new Error(`product ${p.id} image missing: ${p.image}`);
    if (p.mrp < p.price) throw new Error(`product ${p.id} mrp < price`);
  }
  console.log(`catalog OK (${c.products.length} products)`);
} catch (e) {
  bad += 1;
  console.error(`CATALOG ERROR: ${e.message}`);
}
console.log(`${files.length} JS files checked, ${bad} problem(s)`);
process.exit(bad ? 1 : 0);
